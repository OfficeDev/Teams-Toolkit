#!/usr/bin/env python3
"""
OCR-based precondition checker.

Compares the *expected* whole-screen OCR text (captured at record time) with the
*current* screen's OCR text and asks an LLM to judge whether the current screen is
consistent enough to execute the step. This is the primary precondition mechanism;
the legacy perceptual-hash path is retained as a transitional fallback in the executor.
"""

import time
from typing import Optional

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from openai import AsyncAzureOpenAI
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class OcrConsistencyResult(BaseModel):
    """Structured LLM verdict on OCR text consistency."""
    consistent: bool
    confidence: float
    reasoning: str


class OcrPreconditionPromptTemplate:
    """Prompts for the OCR precondition consistency judge."""

    AGENT_INSTRUCTIONS = """
You decide whether a UI automation step can run NOW. The step is about to be executed; the CURRENT
screen is the state BEFORE this step's action runs. Your job is to verify the screen is READY for
this step — NOT to check that the step has already been done.

You receive:
1. PREVIOUS STEP: what the automation just did (so you know what state the screen should now be in).
2. STEP DESCRIPTION: the action this step is ABOUT TO perform (and, if a click, its target x, y).
3. EXPECTED TEXT: text read from the screen when the step was RECORDED. IMPORTANT: this recording
   may show the state DURING or AFTER the action (e.g. text already typed, an item already selected/
   highlighted), so it can contain things this step itself produces. It may also be
   "(NONE ...)" — see EMPTY EXPECTED TEXT below.
4. CURRENT TEXT: text read from the screen right now, BEFORE the action.

How to judge readiness:
- Use PREVIOUS STEP + STEP DESCRIPTION to infer which screen / dialog / menu / list / input field
  must be present for this step to run, then check the CURRENT TEXT shows that context.
- CRITICAL: Do NOT require the OUTCOME of THIS step to already be present. If the step types text,
  selects an item, clicks an option, or opens something, that text/item/result will usually be
  ABSENT from the current screen — that is CORRECT and must NOT be judged inconsistent. For example,
  for "type 'Add Capability' into the command palette", an OPEN, EMPTY command palette is READY and
  consistent even though "Add Capability" is not yet shown.
- EMPTY EXPECTED TEXT: if EXPECTED TEXT is "(NONE ...)", no reference screenshot was recorded for
  this step. Do NOT treat the missing expected text as a failure. Judge readiness ONLY from
  PREVIOUS STEP + STEP DESCRIPTION + PRECONDITION INTENT, checking that the CURRENT TEXT positively
  shows a plausible screen/context for this step. Mark inconsistent only when the current screen is
  clearly a different/unrelated view, is empty of the needed context, or shows a blocking error.
- If a PRECONDITION INTENT is provided, treat it as the PRIMARY thing to verify.
- Verify the CONTAINER, not transient contents: judge whether the needed screen/dialog/menu/list/
  input is shown and in the right context. Ignore transient, hover-only or focus-only affordances
  (e.g. "Toggle all checkboxes", select-all toggles, tooltips, hover buttons, scrollbars); the
  action itself reveals those when the cursor moves to the target.
- Ignore benign / dynamic differences: randomized app or workspace names, GUIDs, timestamps, paths,
  usernames, versions, counters, cursor/focus, minor OCR noise, and reordering. Specifically, the
  app / agent under test is named `vscuse_app_<5 random chars><env>` (e.g. `vscuse_app_dxMFCdev`,
  `vscuse_app_uTuNTlocal`, and it may appear as just `vscuse_app_<5 random chars>`): the 5-character
  segment is randomized every run and the trailing environment segment reflects the current run
  (`local` for a Local Debug run, `dev` for a Remote Debug run). When a recorded and a current name
  differ ONLY in that random segment and/or the environment suffix, they refer to the SAME app/agent;
  do not, on that basis alone, judge the screen inconsistent or the wrong agent selected. This applies
  only to the app-name string — still verify the rest of the screen context normally.
- Treat as INCONSISTENT only when the screen is clearly the WRONG context: a different screen/view/
  dialog than expected, the required container/list is absent or empty, a blocking error/overlay is
  shown, or content indicates the app is on the wrong step (e.g. the previous step did not take
  effect). When clearly the wrong context, mark inconsistent so the runner keeps waiting.

Respond in the structured format:
- consistent: true if the current screen is READY to execute this step, else false
- confidence: 0.0-1.0 confidence in your judgement
- reasoning: one short sentence explaining the decision
"""

    QUERY_TEMPLATE = (
        "{prev_info}"
        "STEP DESCRIPTION (about to run): {description}\n"
        "{intent_info}"
        "{target_info}"
        "\n=== EXPECTED TEXT (recorded; may include this step's own result) ===\n{expected_text}\n"
        "\n=== CURRENT TEXT (now) ===\n{current_text}\n"
    )


class OcrPreconditionChecker:
    """LLM judge for whether current OCR text is consistent with expected OCR text."""

    def __init__(self):
        self._client: Optional[AsyncAzureOpenAI] = None
        self._agent: Optional[Agent] = None
        self._runner: Optional[Runner] = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        if self._client is None:
            azure_config = get_azure_openai_config()
            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)
            self._agent = Agent(
                name="OcrPreconditionChecker",
                instructions=OcrPreconditionPromptTemplate.AGENT_INSTRUCTIONS,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                ),
                output_type=OcrConsistencyResult,
            )
            self._runner = Runner()
            logger.info(f"OCR precondition checker initialized with model: {azure_config.model}")

    async def judge_consistency(
        self,
        expected_text: str,
        current_text: str,
        description: str = "",
        target_x: Optional[int] = None,
        target_y: Optional[int] = None,
        intent: Optional[str] = None,
        prev_description: Optional[str] = None,
    ) -> OcrConsistencyResult:
        """Ask the LLM whether the current screen is READY to execute this step.

        *intent* (from the ``precondition_intent:`` step tag) is an optional
        free-text hint stating what the precondition must verify. *prev_description*
        is the previous step's description, giving the judge context about what
        state the screen should now be in.

        Returns an :class:`OcrConsistencyResult`. On any error, returns a
        non-consistent result with confidence 0.0 so the caller keeps waiting.
        """
        try:
            await self._initialize_client()

            target_info = ""
            if target_x is not None and target_y is not None:
                target_info = f"CLICK TARGET: ({target_x}, {target_y})\n"

            intent_info = ""
            if intent:
                intent_info = f"PRECONDITION INTENT (verify this first): {intent}\n"

            prev_info = ""
            if prev_description:
                prev_info = f"PREVIOUS STEP (just completed): {prev_description}\n"

            # Render an explicit sentinel for a missing expected text so the judge
            # knows no reference screenshot was recorded (rather than the screen
            # having been genuinely blank at record time).
            has_expected = bool(expected_text and expected_text.strip())
            expected_render = (
                expected_text if has_expected
                else "(NONE — no reference screenshot was recorded for this step; "
                     "judge readiness from the description, previous step and intent)"
            )

            query = OcrPreconditionPromptTemplate.QUERY_TEMPLATE.format(
                description=description or "(no description)",
                intent_info=intent_info,
                target_info=target_info,
                prev_info=prev_info,
                expected_text=expected_render,
                current_text=current_text or "(empty)",
            )

            # Log the exact prompt sent to the LLM (helps diagnose precondition
            # decisions). Debug-level so it does not add noise to normal INFO runs.
            logger.debug("OCR precondition prompt sent to LLM:\n%s", query)

            start = time.time()
            result = await self._runner.run(self._agent, input=query)
            duration = time.time() - start

            verdict = result.final_output_as(OcrConsistencyResult, raise_if_incorrect_type=True)
            logger.info(
                f"OCR precondition judge: consistent={verdict.consistent} "
                f"confidence={verdict.confidence:.2f} ({duration:.2f}s) - {verdict.reasoning}"
            )
            # When the judge rejects the screen, log the compared texts so the
            # decision can be diagnosed from an INFO-level run.
            if not verdict.consistent:
                logger.info(
                    "OCR precondition INCONSISTENT - inputs were: description=%r intent=%r\n"
                    "--- EXPECTED TEXT (recorded, first 800 chars) ---\n%s\n"
                    "--- CURRENT TEXT (now, first 800 chars) ---\n%s",
                    description,
                    intent,
                    (expected_text or "")[:800],
                    (current_text or "")[:800],
                )
            return verdict
        except Exception as e:  # noqa: BLE001 - never let the judge crash the loop
            logger.warning(f"OCR precondition judge failed: {e}")
            return OcrConsistencyResult(
                consistent=False,
                confidence=0.0,
                reasoning=f"judge error: {e}",
            )
