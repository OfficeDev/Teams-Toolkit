#!/usr/bin/env python3
"""
Condition Agent for UI State Comparison using OpenAI Agents SDK

This agent compares current screenshots with recorded screenshots to determine
if UI conditions are met for step execution, providing fallback analysis when
automated condition checks fail.
"""

import base64
import io
import time
from typing import Optional, Tuple

import imagehash
from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from openai import AsyncAzureOpenAI
from PIL import Image, ImageDraw
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.core.schema import Step
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class ConditionAnalysisResult(BaseModel):
    """Structured result for condition analysis."""
    decision: str  # One of: EXECUTE, WAIT, SKIP, ABORT
    explanation: str


def is_valid_screenshot_data(screenshot: Optional[str]) -> bool:
    """Validate if screenshot data is a valid base64 data URI or file path.

    Args:
        screenshot: Screenshot data string to validate

    Returns:
        True if screenshot appears to be valid data, False otherwise
    """
    if not screenshot:
        return False

    # Check if it's a data URI with actual base64 content
    if screenshot.startswith('data:'):
        # Data URI should be at least: "data:image/jpeg;base64," + some data
        # Minimum valid data URI is around 30+ chars
        if len(screenshot) < 50:
            return False
        if ';base64,' not in screenshot:
            return False
        # Check there's actual content after base64,
        try:
            _, base64_data = screenshot.split(',', 1)
            return len(base64_data) > 100  # Minimum base64 content
        except ValueError:
            return False

    # Check if it's a file path that exists
    import os
    if os.path.isfile(screenshot):
        return True

    # If it's neither a data URI nor existing file, it's invalid
    return False


class ConditionPromptTemplate:
    """Template for generating condition analysis prompts."""

    AGENT_INSTRUCTIONS = """
You are a UI automation condition analyzer. Compare two screenshots to determine if the current UI state is suitable for executing an automation step.

Your task is to analyze:
1. Whether the current UI state matches or is compatible with the recorded state
2. If the intended UI element is present and clickable/interactable
3. Whether the step can be safely executed despite minor UI differences

Be MORE CONSERVATIVE about UI state differences. If there are active dropdowns, menus, overlays, or other UI elements that weren't present in the recorded state, prefer WAIT or SKIP over EXECUTE to avoid unintended interactions.

Dynamic app / agent names: the app-under-test is named `vscuse_app_<5 random chars><env>` (e.g. `vscuse_app_dxMFCdev`, `vscuse_app_uTuNTlocal`, and it may appear as just `vscuse_app_<5 random chars>` when the suffix is not shown). The 5-character segment is randomized on every run and the trailing environment segment reflects the current run (`local` for a Local Debug run, `dev` for a Remote Debug run). When a recorded name and a current name both look like `vscuse_app_<5 random chars><env>` and differ ONLY in that random segment and/or the environment suffix, treat them as the SAME logical app/agent; do NOT, on that basis alone, decide that the wrong agent/app is selected or that the UI state is incompatible. This normalization applies ONLY to the app-name string — keep evaluating the rest of the UI normally, and you may still WAIT/SKIP/ABORT when the active panel, visible controls, click/input target, page content, or workflow state differs materially.

Be practical and focused on whether the automation step can succeed, not perfect pixel matching.
"""

    CONDITION_ANALYSIS_PROMPT = """
Compare these two screenshots to determine if an automation step can be executed:

**RECORDED SCREENSHOT** (when step was originally recorded):
This shows the UI state when the step was successfully recorded.

**CURRENT SCREENSHOT** (current UI state):
This shows the current UI state where we want to execute the step.

**STEP TO EXECUTE:**
- Tool: {tool}
- Parameters: {parameters}
- Description: {description}

{coordinate_info}

**ANALYSIS REQUIRED:**
1. Is the target UI element visible and accessible in the current screenshot?
2. Are there any blocking overlays, dialogs, or UI changes that would prevent execution?
3. Is the current UI state fundamentally compatible with executing this step?

**DECISION OPTIONS:**
- EXECUTE: If the step can be safely executed
- WAIT: If the UI needs time to load/stabilize but execution should be possible soon
- SKIP: If the UI state is incompatible and step should be skipped
- ABORT: If there are serious UI issues that require manual intervention

Provide your analysis using the structured output format with 'decision' and 'explanation' fields.
"""

    STATE_ONLY_AGENT_INSTRUCTIONS = """
You are a UI automation PROGRESS checker. Your ONLY job is to decide whether the automation has reached the right point in the workflow to run the NEXT step: i.e. whether the previous action has taken effect and the current screen is the expected screen for this step.

You are NOT judging click-coordinate accuracy. Do NOT reason about whether any specific pixel or coordinate lands on the correct element, and do NOT treat controls being slightly moved, resized, or restyled as a problem. Coordinate targeting is handled by a separate mechanism. Ignore tooltips, hover highlights, cursor position, and minor layout shifts.

Compare the RECORDED screenshot (the expected UI state at this point in the recorded flow) with the CURRENT screenshot and choose:
- EXECUTE: the current screen is the expected screen for this step and the previous action's effect is visible (or the screen is otherwise ready). Prefer EXECUTE whenever the correct page/panel/app is shown, even if controls have moved or the layout changed.
- WAIT: the screen is still loading/transitioning, or a transient overlay/spinner/dialog is temporarily covering the expected screen and should clear on its own shortly.
- SKIP: the current screen is clearly the WRONG screen or a different workflow state (an unexpected page, an error page, or evidence that the previous step failed), so this step should not run here.
- ABORT: a serious or unrecoverable error requiring manual intervention.

Dynamic app / agent names: the app-under-test is named `vscuse_app_<5 random chars><env>` (e.g. `vscuse_app_dxMFCdev`, `vscuse_app_uTuNTlocal`, or just `vscuse_app_<5 random chars>`). The 5-character segment is randomized every run and the trailing environment segment (`local` or `dev`) reflects the current run. When a recorded name and a current name both look like `vscuse_app_<5 random chars><env>` and differ ONLY in that random segment and/or the environment suffix, treat them as the SAME logical app/agent; do NOT, on that basis alone, decide the UI state is wrong.

Focus only on workflow/screen state and readiness -- never on coordinate correctness or pixel-perfect matching.
"""

    STATE_ONLY_ANALYSIS_PROMPT = """
Determine whether the automation is ready to run the next step at this point in the workflow.

**RECORDED SCREENSHOT** (expected UI state at this point in the recorded flow).
**CURRENT SCREENSHOT** (current UI state).

**NEXT STEP (context only -- do NOT judge its click coordinate):**
- Tool: {tool}
- Description: {description}

**ANALYSIS REQUIRED:**
1. Is the current screen the expected screen for this point in the workflow (did the previous action take effect)?
2. Is any overlay/loading state transient (WAIT) or is this a genuine wrong-screen / workflow divergence (SKIP)?

Do NOT evaluate click-coordinate accuracy or whether a specific element sits under a particular pixel. Ignore moved/resized controls, tooltips, and cursor position.

Choose EXECUTE / WAIT / SKIP / ABORT and provide your analysis using the structured output format with 'decision' and 'explanation' fields.
"""

    @classmethod
    def format_analysis_prompt(
        cls,
        step: Step,
        has_coordinates: bool = False
    ) -> str:
        """Format the condition analysis prompt with step details.

        Args:
            step: Step object being analyzed
            has_coordinates: Whether the step has x,y coordinates

        Returns:
            Formatted prompt string
        """
        coordinate_info = ""
        if has_coordinates and step.parameters and hasattr(step.parameters, 'x') and hasattr(step.parameters, 'y'):
            coordinate_info = f"\n**TARGET COORDINATES:** ({step.parameters.x}, {step.parameters.y})\nA red crosshair will be drawn on both screenshots at these coordinates to show the intended interaction point."

        return cls.CONDITION_ANALYSIS_PROMPT.format(
            tool=step.tool,
            parameters=step.parameters.model_dump(exclude_none=True) if step.parameters else {},
            description=step.description or "No description",
            coordinate_info=coordinate_info
        )

    @classmethod
    def format_state_only_prompt(cls, step: Step) -> str:
        """Format the coordinate-blind, state-only analysis prompt.

        Deliberately excludes ``step.parameters`` (which carry x/y) so the judge
        cannot reason about click-coordinate accuracy -- only workflow/screen state.
        """
        return cls.STATE_ONLY_ANALYSIS_PROMPT.format(
            tool=step.tool,
            description=step.description or "No description",
        )


class ConditionAgent:
    """Agent for analyzing UI condition compatibility using vision comparison."""

    def __init__(self, state_only: bool = False):
        """Initialize the condition analysis agent.

        Args:
            state_only: When True, run in coordinate-blind mode -- no crosshair, no
                coordinate context, and a reframed prompt that judges only workflow/
                screen progress (did the previous action land / are we on the expected
                screen), never click-coordinate accuracy.
        """
        self._client: AsyncAzureOpenAI = None
        self._agent: Agent = None
        self._runner: Optional[Runner] = None
        self._use_azure_credential = False
        self._state_only = state_only
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        """Initialize the Azure OpenAI client and agent."""
        if self._client is None:
            # Get configuration from config manager
            azure_config = get_azure_openai_config()

            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)

            instructions = (
                ConditionPromptTemplate.STATE_ONLY_AGENT_INSTRUCTIONS
                if self._state_only
                else ConditionPromptTemplate.AGENT_INSTRUCTIONS
            )
            self._agent = Agent(
                name="ConditionStateAnalyzer" if self._state_only else "ConditionAnalyzer",
                instructions=instructions,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                ),
                output_type=ConditionAnalysisResult
            )

            self._runner = Runner()
            logger.info("Condition analysis agent initialized")

    def _convert_to_base64_with_crosshair(
        self,
        image_source: str,
        x: Optional[int] = None,
        y: Optional[int] = None,
        label: str = ""
    ) -> str:
        """Convert image source (data URI or file path) to base64 with optional crosshair overlay.

        Args:
            image_source: Data URI string (data:image/...;base64,...) or file path
            x: X coordinate for crosshair (optional)
            y: Y coordinate for crosshair (optional)
            label: Label for debugging/logging

        Returns:
            Base64 encoded data URL with crosshair if coordinates provided

        Raises:
            ValueError: If data URI format is invalid or image_source is not valid
            FileNotFoundError: If file doesn't exist
            IOError: If there's an error processing the image
        """
        try:
            # Validate image source before processing
            if not is_valid_screenshot_data(image_source):
                raise ValueError(
                    f"Invalid {label} screenshot data: '{image_source[:50]}...' "
                    f"(length: {len(image_source)}). Expected data URI or valid file path."
                )

            # Load image based on source type
            if image_source.startswith('data:'):
                # Parse data URI
                header, base64_data = image_source.split(',', 1)
                image_data = base64.b64decode(base64_data)
                image = Image.open(io.BytesIO(image_data))
            else:
                # Load from file path
                image = Image.open(image_source)

            with image:
                # Convert to RGB if needed
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Create a copy to avoid modifying original
                image_copy = image.copy()

                # Draw crosshair if coordinates provided
                if x is not None and y is not None:
                    draw = ImageDraw.Draw(image_copy)

                    # Draw crosshair (same style as core_agent.py)
                    crosshair_size = 8
                    line_width = 2

                    # White outline for visibility
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='white', width=line_width + 2)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='white', width=line_width + 2)

                    # Red crosshair on top
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='red', width=line_width)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='red', width=line_width)

                    logger.debug(f"Drew crosshair at ({x}, {y}) on {label} screenshot")

                # Convert to base64
                buffer = io.BytesIO()
                image_copy.save(buffer, format="JPEG", quality=95)
                encoded_string = base64.b64encode(buffer.getvalue()).decode("utf-8")

                return f"data:image/jpeg;base64,{encoded_string}"

        except FileNotFoundError:
            logger.error(f"Screenshot file not found: {image_source}")
            raise
        except Exception as e:
            logger.error(f"Error processing {label} screenshot: {e}")
            raise

    async def analyze_condition_compatibility(
        self,
        step: Step,
        current_screenshot_path: str
    ) -> Tuple[str, str]:
        """Analyze if current UI state is compatible with step execution.

        Args:
            step: Step object containing recorded screenshot and parameters
            current_screenshot_path: Path to current screenshot

        Returns:
            Tuple of (decision, explanation) where decision is one of:
            - "EXECUTE": Step can be safely executed
            - "WAIT": UI needs time to stabilize
            - "SKIP": UI state is incompatible
            - "ABORT": Serious UI issues require manual intervention

        Raises:
            ValueError: If step doesn't have required screenshot
            Exception: For API or processing errors
        """
        start_time = time.time()

        try:
            # Validate screenshot data exists and is valid
            if not step.screenshot:
                logger.warning(f"Step {step.step_id} has no recorded screenshot, allowing execution without comparison")
                return "EXECUTE", "No recorded screenshot available - allowing execution based on step definition only"

            if not is_valid_screenshot_data(step.screenshot):
                logger.warning(f"Step {step.step_id} has invalid screenshot data: '{step.screenshot[:50]}...', allowing execution without comparison")
                return "EXECUTE", f"Invalid recorded screenshot data (length: {len(step.screenshot)}) - allowing execution based on step definition only"

            logger.info(f"Analyzing condition compatibility for step {step.step_id}")

            # Perform preliminary pHash comparison to avoid unnecessary LLM calls
            try:
                # Load images for hash comparison (without crosshairs for accurate comparison)
                # Handle both data URI and file path for recorded screenshot
                if step.screenshot.startswith('data:'):
                    # Data URI format
                    _, base64_data = step.screenshot.split(',', 1)
                    recorded_image_data = base64.b64decode(base64_data)
                    recorded_img = Image.open(io.BytesIO(recorded_image_data))
                else:
                    # File path format
                    recorded_img = Image.open(step.screenshot)

                current_img = Image.open(current_screenshot_path)

                # Calculate perceptual hashes
                recorded_hash = imagehash.phash(recorded_img)
                current_hash = imagehash.phash(current_img)

                # Calculate Hamming distance
                hamming_distance = recorded_hash - current_hash

                logger.debug(f"pHash comparison - Hamming distance: {hamming_distance}")

                # If images are too different (Hamming distance > 40), skip LLM analysis.
                # In state-only mode a product UI redesign legitimately produces a large
                # pixel delta, so we must NOT early-SKIP -- let the LLM judge screen state.
                if hamming_distance > 40 and not self._state_only:
                    logger.info(f"Screenshots too different (Hamming distance: {hamming_distance} > 40), skipping LLM analysis")
                    return "SKIP", f"Screenshots significantly different (pHash Hamming distance: {hamming_distance} > 40). UI state incompatible with recorded state."

                logger.debug(f"pHash similarity acceptable (Hamming distance: {hamming_distance} <= 40), proceeding with LLM analysis")

            except Exception as e:
                logger.warning(f"pHash comparison failed: {e}. Proceeding with LLM analysis as fallback.")

            await self._initialize_client()

            # Check if step has coordinates for crosshair indication. In state-only
            # mode we never draw a crosshair or expose coordinates to the judge.
            has_coordinates = ((not self._state_only) and step.parameters and
                             hasattr(step.parameters, 'x') and hasattr(step.parameters, 'y') and
                             step.parameters.x is not None and step.parameters.y is not None)

            x_coord = step.parameters.x if has_coordinates else None
            y_coord = step.parameters.y if has_coordinates else None

            # Prepare images with crosshairs if coordinates exist
            # Recorded screenshot can be either data URI or file path
            recorded_image = self._convert_to_base64_with_crosshair(
                step.screenshot, x_coord, y_coord, "recorded"
            )

            # Current screenshot is always a file path
            current_image = self._convert_to_base64_with_crosshair(
                current_screenshot_path, x_coord, y_coord, "current"
            )

            # Prepare the analysis prompt
            if self._state_only:
                prompt = ConditionPromptTemplate.format_state_only_prompt(step=step)
            else:
                prompt = ConditionPromptTemplate.format_analysis_prompt(
                    step=step,
                    has_coordinates=has_coordinates
                )

            # Prepare input for the agent with clear image labels
            input_data = [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_text", "text": "**RECORDED SCREENSHOT** (when step was originally recorded):"},
                        {"type": "input_image", "image_url": recorded_image},
                        {"type": "input_text", "text": "**CURRENT SCREENSHOT** (current UI state):"},
                        {"type": "input_image", "image_url": current_image}
                    ]
                }
            ]

            # Execute analysis
            api_start = time.time()
            result = await self._runner.run(self._agent, input=input_data)
            api_duration = time.time() - api_start

            # Use structured output with validation
            try:
                analysis_result = result.final_output_as(ConditionAnalysisResult, raise_if_incorrect_type=True)
                decision = analysis_result.decision.upper()
                explanation = analysis_result.explanation
            except TypeError as e:
                logger.warning(f"Structured output validation failed: {str(e)}. Using fallback parsing.")
                # Fallback to string parsing if structured output fails
                response = str(result.final_output).strip()
                lines = response.split('\n', 1)
                decision = lines[0].strip().upper()
                explanation = lines[1].strip() if len(lines) > 1 else "No explanation provided"

            # Validate decision
            valid_decisions = ["EXECUTE", "WAIT", "SKIP", "ABORT"]
            if decision not in valid_decisions:
                logger.warning(f"Invalid decision '{decision}', defaulting to WAIT")
                decision = "WAIT"
                explanation = f"Invalid decision format. Decision: {decision}"

            # Log performance metrics
            total_duration = time.time() - start_time
            usage = result.context_wrapper.usage

            logger.info(f"Condition analysis for step {step.step_id}: {decision} ({total_duration:.2f}s, API: {api_duration:.2f}s, tokens: {usage.input_tokens}/{usage.output_tokens})")
            logger.debug(f"Analysis explanation: {explanation}")

            return decision, explanation

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Failed to analyze conditions for step {step.step_id} after {duration:.2f}s: {e}")
            # Return conservative decision on error
            return "WAIT", f"Condition analysis failed: {str(e)}"

    @classmethod
    async def check_step_compatibility(
        cls,
        step: Step,
        current_screenshot_path: str,
        state_only: bool = False
    ) -> Tuple[str, str]:
        """Convenience method to check step compatibility with current UI state.

        Args:
            step: Step object containing recorded screenshot and parameters
            current_screenshot_path: Path to current screenshot

        Returns:
            Tuple of (decision, explanation)
        """
        agent = cls(state_only=state_only)
        return await agent.analyze_condition_compatibility(
            step, current_screenshot_path
        )
