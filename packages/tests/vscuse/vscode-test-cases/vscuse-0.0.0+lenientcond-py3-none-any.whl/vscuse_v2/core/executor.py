#!/usr/bin/env python3
"""
Plan Executor

Executes executable plans using agent-based execution.
"""

import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import imagehash
from PIL import Image

from vscuse_v2.config import get_docker_config, get_execution_config
from vscuse_v2.config.config_manager import ExecutionConfig
from vscuse_v2.docker.docker_client import DockerClient
from vscuse_v2.utils.image_tool import detect_loading_stability
from vscuse_v2.utils.logger import setup_logger

from .agent_router import AgentRouter
from .condition_agent import ConditionAgent
from .fact_store import FactStore
from .models import PlanExecutionResult, StepExecutionResult
from .ocr_text import (
    OcrConfigError,
    extract_ocr_text,
    find_ocr_precondition,
    is_ocr_precondition,
    text_similarity,
)
from .reporter import Reporter
from .resolver import Resolver
from .schema import AgentType, ExecutablePlan, Step
from .tag_processor import TagProcessor
from .validator import parse_condition, validate_postconditions, validate_preconditions

logger = setup_logger(__name__)


class Executor:
    """Plan executor for executing steps using different agents."""

    def __init__(self, docker_server_url: str = None,
                 delay: float = None,
                 precondition_wait_timeout: float = None,
                 precondition_retry_interval: float = None,
                 generate_report: bool = True,
                 report_output_dir: str = "test_report"):

        # Load configuration
        docker_config = get_docker_config()
        execution_config = get_execution_config()

        # Set configuration with provided values or defaults
        self.docker_server_url = docker_server_url or docker_config.server_url
        self.delay = delay or execution_config.delay_between_steps
        self.precondition_wait_timeout = precondition_wait_timeout or execution_config.precondition_wait_timeout
        self.precondition_retry_interval = precondition_retry_interval or execution_config.precondition_retry_interval
        self.stop_on_error = execution_config.stop_on_error
        self.step_retry_timeout = execution_config.step_retry_timeout
        self.ocr_precondition_confidence_threshold = getattr(
            execution_config, "ocr_precondition_confidence_threshold", 0.7
        )
        self.ocr_precondition_text_similarity_threshold = getattr(
            execution_config, "ocr_precondition_text_similarity_threshold", 0.9
        )
        self.generate_report = generate_report
        self.report_output_dir = report_output_dir

        # Initialize components
        self._docker_client = DockerClient(docker_server_url=docker_server_url)
        self.reporter = Reporter(report_output_dir) if generate_report else None
        self.resolver = Resolver()
        self.tag_processor = TagProcessor()
        self.agent_router = AgentRouter(docker_server_url=self.docker_server_url)

        # Execution state
        self.execution_log = []
        self.step_results = {}
        # Human-readable reason for the most recent precondition failure
        # (LLM decision + explanation), surfaced in the step error / report.
        self._last_precondition_detail: Optional[str] = None
        # Per-step markers recording whether the new lenient OCR-retargeted precondition
        # mechanism was exercised on the step currently executing, surfaced in the report
        # so the team can count adoption of the new feature.
        self._used_new_precondition: bool = False
        self._ocr_retargeted: bool = False
        self._ocr_retarget_detail: Optional[str] = None
        self.current_plan = None
        self.current_plan_path = None

    async def execute_step(self, step: Step) -> StepExecutionResult:
        """Execute a step using the appropriate agent with retry logic based on timeout."""
        # Determine retry timeout: check for step_retry_timeout tag first, then use executor's default
        tag_retry_timeout = self.tag_processor.get_step_retry_timeout(step)
        retry_timeout = tag_retry_timeout if tag_retry_timeout is not None else self.step_retry_timeout

        last_result = None
        attempt = 0
        start_time = time.time()

        while True:
            attempt += 1
            elapsed = time.time() - start_time

            if attempt > 1:
                logger.info(f"[RETRY] Attempt {attempt} for step {step.step_id} (elapsed: {elapsed:.1f}s / timeout: {retry_timeout}s)")

            result = await self._execute_step_once(step)
            last_result = result

            if result.success:
                if attempt > 1:
                    logger.info(f"[RETRY SUCCESS] Step {step.step_id} succeeded on attempt {attempt} after {elapsed:.1f}s")
                return result

            # Check if we've exceeded the retry timeout
            elapsed = time.time() - start_time
            if elapsed >= retry_timeout:
                logger.error(f"[RETRY TIMEOUT] Step {step.step_id} failed after {attempt} attempts and {elapsed:.1f}s (timeout: {retry_timeout}s)")
                break

            # Calculate remaining time and decide if we should retry
            remaining = retry_timeout - elapsed
            if remaining > 0:
                # Brief delay between retries (but don't exceed timeout)
                delay = min(1.0, remaining)
                logger.warning(f"[RETRY] Step {step.step_id} failed, retrying in {delay:.1f}s... (remaining timeout: {remaining:.1f}s)")
                await asyncio.sleep(delay)
            else:
                break

        return last_result

    async def _execute_step_once(self, step: Step) -> StepExecutionResult:
        """Execute a step once (internal method used by retry logic)."""
        logger.info("=" * 60)
        logger.info(f"[EXECUTING] Step {step.step_id}: {step.description}")
        logger.info("=" * 60)

        start_time = time.time()
        before_screenshot = None
        after_screenshot = None
        # Reset the new-precondition usage markers for this step.
        self._used_new_precondition = False
        self._ocr_retargeted = False
        self._ocr_retarget_detail = None

        try:
            # Resolve environment variables in step parameters and description
            resolved_step = self.resolver.resolve_step_variables(step)

            # Use the resolved step for the rest of the execution
            step = resolved_step

            # Apply strict precondition tolerance for steps containing sensitive data
            if getattr(step, '_contains_sensitive', False) and step.preconditions:
                logger.info(f"Step {step.step_id} contains sensitive data, applying strict precondition checks...")
                step.preconditions = [self._adjust_precondition_tolerance(pc, 3) for pc in step.preconditions]

            # Check for delay tag and wait if specified
            delay_seconds = self.tag_processor.get_delay_seconds(step)
            if delay_seconds is not None:
                logger.info(f"Delay tag found for step {step.step_id}, waiting {delay_seconds} seconds...")
                await asyncio.sleep(delay_seconds)

            # Check for force_run tag to skip preconditions and postconditions
            force_run = self.tag_processor.should_force_run(step)
            if force_run:
                logger.info(f"Force run enabled for step {step.step_id}, skipping precondition and postcondition checks")
                logger.info(f"Waiting for stable screenshot for force run step {step.step_id}...")
                await self._wait_for_stable_screenshot(max_wait=60.0)

            # Check for precondition_wait_timeout tag and override step timeout if specified
            tag_timeout = self.tag_processor.get_precondition_wait_timeout(step)
            if tag_timeout is not None:
                logger.info(f"Precondition wait timeout tag found for step {step.step_id}, using {tag_timeout} seconds")
                step.precondition_wait_timeout = tag_timeout

            # Check preconditions (skip if force_run is enabled)
            if not force_run and not await self._check_preconditions(step):
                # Precondition failure: create error result with screenshot for debugging
                timeout = step.precondition_wait_timeout or self.precondition_wait_timeout
                # Take screenshot on precondition failure for debugging
                before_screenshot = self._docker_client.take_screenshot()
                execution_time = time.time() - start_time

                # Get retry information for better error message
                tag_retry_timeout = self.tag_processor.get_step_retry_timeout(step)
                retry_timeout = tag_retry_timeout if tag_retry_timeout is not None else self.step_retry_timeout
                retry_info = f" (will retry for up to {retry_timeout}s)" if retry_timeout > 0 else ""

                detail = getattr(self, "_last_precondition_detail", None)
                if detail and len(detail) > 800:
                    detail = detail[:800] + "..."
                detail_suffix = f" - {detail}" if detail else ""
                result = StepExecutionResult.from_step(
                    step, success=False,
                    error=f"Preconditions failed after {timeout}s timeout{retry_info}{detail_suffix}",
                    action="precondition_check_failed",
                    execution_time=execution_time
                )
                result.before_screenshot = before_screenshot
                result.after_screenshot = None
            else:
                # Normal execution path: preconditions passed, proceed with agent execution
                # Take before screenshot
                before_screenshot = self._docker_client.take_screenshot()
                logger.debug(f"Before screenshot taken for step {step.step_id}: {before_screenshot}")

                # Check for store_fact tag
                store_fact = self.tag_processor.get_store_fact(step)

                # Check for ocr:true tag and resolve x,y coordinates if requested
                if self.tag_processor.get_ocr_enabled(step):
                    step = await self._resolve_coordinates_via_ocr(step, before_screenshot)

                agent_result = await self.agent_router.execute_step_with_agent(step, store_fact=store_fact)

                # Take after screenshot
                after_screenshot = self._docker_client.take_screenshot()
                logger.debug(f"After screenshot taken for step {step.step_id}: {after_screenshot}")

                execution_time = time.time() - start_time

                # Check postconditions (skip for interaction agent or if force_run is enabled)
                postcondition_success = True
                final_error = agent_result.error

                if (agent_result.success and step.postconditions and
                    step.agent != AgentType.INTERACTION and not force_run):
                    if not self._check_postconditions(step):
                        postcondition_success = False
                        final_error = "Postcondition validation failed"

                # Create result with screenshots
                result = StepExecutionResult.from_step(
                    step,
                    success=agent_result.success and postcondition_success,
                    error=final_error,
                    result=agent_result.result,
                    action=agent_result.action,
                    execution_time=execution_time
                )

        except EnvironmentError as e:
            logger.error(f"Environment variable resolution failed for step {step.step_id}: {e}")
            execution_time = time.time() - start_time
            result = StepExecutionResult.from_step(
                step, success=False,
                error=str(e),
                action="env_var_resolution_failed",
                execution_time=execution_time
            )

        except asyncio.CancelledError:
            logger.info(f"Step {step.step_id} execution was cancelled")
            execution_time = time.time() - start_time
            result = StepExecutionResult.from_step(
                step, success=False,
                error="Step execution cancelled by user",
                action="cancelled",
                execution_time=execution_time
            )
            # Don't re-raise, return the cancelled result

        except Exception as e:
            execution_time = time.time() - start_time
            result = StepExecutionResult.from_step(
                step, success=False,
                error=f"Execution failed: {str(e)}",
                execution_time=execution_time
            )

        finally:
            # Apply sensitive data masking to the execution result
            result = self.resolver.apply_sensitive_data_masking(result, step)

        # Add screenshots to result
        result.before_screenshot = before_screenshot
        result.after_screenshot = after_screenshot

        # Record whether the new lenient OCR-retargeted precondition mechanism was used.
        result.new_precondition_applied = self._used_new_precondition
        result.ocr_retargeted = self._ocr_retargeted
        result.ocr_retarget_detail = self._ocr_retarget_detail

        self.step_results[step.step_id] = result
        status = "SUCCESS" if result.success else "FAILED"
        status_prefix = "[SUCCESS]" if result.success else "[FAILED]"
        logger.info(f"{status_prefix} Step {step.step_id} {status} ({execution_time:.2f}s)")
        logger.info("=" * 60)
        return result

    def _adjust_precondition_tolerance(self, precondition: str, max_tolerance: int) -> str:
        """
        Adjust precondition tolerance to be at most max_tolerance.

        Precondition format: hash_type:x:y:size:tolerance:hash_value

        Args:
            precondition: Precondition string to adjust
            max_tolerance: Maximum allowed tolerance value

        Returns:
            Adjusted precondition string
        """
        # OCR preconditions carry no spot tolerance; leave them untouched.
        if is_ocr_precondition(precondition):
            return precondition
        parts = precondition.split(':')
        if len(parts) == 6:
            try:
                current_tolerance = int(parts[4])
                if current_tolerance > max_tolerance:
                    parts[4] = str(max_tolerance)
                    logger.debug(f"Adjusted tolerance from {current_tolerance} to {max_tolerance}")
            except ValueError:
                logger.warning(f"Invalid tolerance value in precondition: {parts[4]}")
        return ':'.join(parts)

    async def _resolve_coordinates_via_ocr(self, step: Step, screenshot_path: Optional[str]) -> Step:
        """
        Use OCR to resolve x, y coordinates from the step description and update the step parameters.

        Takes a fresh screenshot if *screenshot_path* is not available, then calls
        OcrAgent to locate the UI element described in step.description.  The resolved
        coordinates are written back to step.parameters.x / step.parameters.y.

        Args:
            step: Step to update.
            screenshot_path: Path to an already-taken screenshot, or None.

        Returns:
            Step with updated x, y parameters (original step is not mutated).
        """
        # Lazy import: importing at module level triggers vscuse_v2.agent.__init__,
        # which has a pre-existing circular dependency with vscuse_v2.core.__init__.
        from vscuse_v2.core.ocr_agent import OcrAgent
        try:
            # Take a new screenshot if we don't have one yet
            if not screenshot_path:
                screenshot_path = self._docker_client.take_screenshot()
                logger.debug(f"OCR: took fresh screenshot at {screenshot_path}")

            orig_x = getattr(step.parameters, "x", None)
            orig_y = getattr(step.parameters, "y", None)

            ocr = OcrAgent()
            coord = await ocr.resolve_coordinates(step.description, screenshot_path)

            logger.info(
                f"OCR resolved coordinates for step {step.step_id}: "
                f"x={coord.x}, y={coord.y} (matched: '{coord.text}')"
            )

            # Mark when OCR actually moved the click target to a real new location.
            # Skip the (0,0) no-match fallback so a failed OCR lookup is not counted
            # as a successful re-target.
            if (coord.x, coord.y) != (orig_x, orig_y) and (coord.x, coord.y) != (0, 0):
                self._ocr_retargeted = True
                self._ocr_retarget_detail = (
                    f"({orig_x},{orig_y}) -> ({coord.x},{coord.y}) matched '{coord.text}'"
                )

            # Build an updated copy of the parameters with the resolved coordinates
            updated_params = step.parameters.model_copy(update={"x": coord.x, "y": coord.y})
            return step.model_copy(update={"parameters": updated_params})

        except Exception as e:
            logger.error(
                f"OCR coordinate resolution failed for step {step.step_id}: {e}. "
                "Proceeding with original parameters."
            )
            return step


    def _is_lenient_coord_click(self, step: Step) -> bool:
        """True for ``ocr:true`` coordinate-click steps guarded only by legacy dhash spots.

        This is the class of steps that break when a product UI redesign moves a
        hardcoded click target: the legacy dhash spot check fails and the vision
        ConditionAgent hard-SKIPs on the now-stale coordinate, blocking the step before
        the downstream OCR re-target can correct it. For this class the precondition
        should gate on screen stability only, not on exact coordinate accuracy. Steps
        carrying a new ``ocr:v1:`` payload are excluded (their OCR text judge is already
        position-agnostic).
        """
        if not self.tag_processor.get_ocr_enabled(step):
            return False
        x = getattr(step.parameters, "x", None)
        y = getattr(step.parameters, "y", None)
        if x is None or y is None:
            return False
        if find_ocr_precondition(step.preconditions) is not None:
            return False
        return True

    async def _check_preconditions(self, step: Step) -> bool:
        """Check if preconditions are met, with retry mechanism.

        OCR is the default precondition mechanism. Resolution order per step:
          1. ``precondition:old`` tag -> legacy perceptual-hash conditions only
             (skip + warn if the step has none).
          2. Lenient OCR-retargeted coordinate click (``ocr:true`` + hardcoded x,y,
             no ``ocr:v1:`` payload) -> wait for screen stability and allow; the
             stale coordinate is re-resolved downstream instead of hard-SKIPping here.
          3. An ``ocr:v1:`` payload -> OCR + AI consistency check (default). If OCR
             is unavailable at runtime, fall back to any legacy hash conditions;
             otherwise skip + warn (never silently drop protection when hash exists).
          4. Legacy ``dhash:`` spot conditions -> perceptual-hash validation.
          5. Preconditions present but none recognized -> skip (allow, warn).
        """
        self._last_precondition_detail = None

        if not step.preconditions:
            return True

        hash_conditions = [c for c in step.preconditions if not is_ocr_precondition(c)]

        # Legacy opt-out: `precondition:old` forces the perceptual-hash mechanism
        # and ignores any OCR payload on the step.
        if self.tag_processor.should_use_legacy_precondition(step):
            if hash_conditions:
                return await self._wait_for_conditions(hash_conditions, step, "preconditions")
            logger.warning(
                f"Step {step.step_id} is tagged precondition:old but has no legacy hash "
                "conditions; skipping precondition check (allowing execution)."
            )
            return True

        # Lenient handling for OCR-retargeted coordinate clicks. These steps carry
        # ``ocr:true`` + a hardcoded click coordinate protected only by legacy dhash
        # spots. When a product UI redesign shifts the target, the dhash fails and the
        # vision ConditionAgent hard-SKIPs on the now-stale coordinate, blocking the step
        # before the downstream OCR re-target can fix it. The precondition's real job here
        # is only to wait for the previous action's UI to settle -- not to validate the
        # exact click coordinate. So wait for a stable screen and allow execution; the
        # click target is re-resolved from the live screenshot by _resolve_coordinates_via_ocr.
        if self._is_lenient_coord_click(step):
            # Record adoption as soon as this path is taken, before the (best-effort)
            # stability wait, so a step that used the lenient path is counted regardless
            # of the wait or downstream outcome.
            self._used_new_precondition = True
            wait_timeout = step.precondition_wait_timeout or self.precondition_wait_timeout
            await self._wait_for_stable_screenshot(max_wait=min(wait_timeout, 60.0))
            logger.info(
                f"Lenient precondition for ocr:true coordinate-click step {step.step_id}: "
                "waited for screen stability and allowing execution (coordinate drift is "
                "tolerated at the precondition layer; click target re-resolved downstream)."
            )
            return True

        # Default: OCR precondition when present.
        ocr_payload = find_ocr_precondition(step.preconditions)
        if ocr_payload is not None:
            try:
                return await self._wait_for_ocr_precondition(step, ocr_payload)
            except OcrConfigError as e:
                if hash_conditions:
                    logger.warning(
                        f"OCR unavailable for step {step.step_id} ({e}); "
                        "falling back to legacy hash preconditions."
                    )
                    return await self._wait_for_conditions(hash_conditions, step, "preconditions")
                logger.warning(
                    f"OCR unavailable for step {step.step_id} ({e}) and no hash fallback; "
                    "skipping precondition check (allowing execution)."
                )
                return True

        if hash_conditions:
            return await self._wait_for_conditions(hash_conditions, step, "preconditions")

        logger.warning(
            f"Step {step.step_id} has preconditions but no usable OCR/hash condition; "
            "skipping precondition check (allowing execution)."
        )
        return True

    def _screenshot_phash(self, screenshot_path: str) -> Optional[imagehash.ImageHash]:
        """Compute a perceptual hash of a screenshot for change detection."""
        try:
            with Image.open(screenshot_path) as img:
                return imagehash.phash(img)
        except Exception as e:  # noqa: BLE001 - best-effort dedup
            logger.debug(f"Failed to compute screenshot phash: {e}")
            return None

    async def _wait_for_ocr_precondition(self, step: Step, payload: Dict) -> bool:
        """OCR-based precondition check with a cost-safe retry loop.

        Compares the recorded expected screen text (from *payload*) against the
        current screen text. A distinct screen state is OCR'd at most once; an
        obvious textual match passes without an LLM call, otherwise the LLM judges
        consistency once per distinct stabilized screen. Retries until the screen
        becomes consistent or ``precondition_wait_timeout`` is reached.

        When the expected text is empty (the step had no recorded screenshot), the
        deterministic fast-path is skipped and the LLM readiness judge is always
        consulted; it reasons from the step description, previous step, and any
        ``precondition_intent:`` hint.

        Raises:
            OcrConfigError: if Azure Vision is not configured, so the caller can
                fall back to legacy hash conditions or skip.
        """
        expected_text = payload.get("full_text", "") or ""
        prev_description = payload.get("prev_description")

        wait_timeout = self.precondition_wait_timeout
        retry_interval = self.precondition_retry_interval
        if step.precondition_wait_timeout is not None:
            wait_timeout = step.precondition_wait_timeout
        if step.precondition_retry_interval is not None:
            retry_interval = step.precondition_retry_interval

        target_x = getattr(step.parameters, "x", None)
        target_y = getattr(step.parameters, "y", None)
        intent = self.tag_processor.get_precondition_intent(step)

        checker = None  # lazily created OcrPreconditionChecker
        last_judged_phash: Optional[imagehash.ImageHash] = None
        last_verdict = None
        start_time = asyncio.get_event_loop().time()
        attempts = 0

        while True:
            attempts += 1
            elapsed = asyncio.get_event_loop().time() - start_time

            # Hover to the target before capturing, mirroring the hash precondition
            # loop, so hover/focus-driven UI settles before the screenshot.
            if target_x is not None and target_y is not None:
                try:
                    self._docker_client.hover({"x": target_x, "y": target_y})
                    await asyncio.sleep(0.3)
                except Exception as e:  # noqa: BLE001 - hover is best-effort
                    logger.debug(f"Hover before OCR precondition failed: {e}")

            screenshot_path = self._docker_client.take_screenshot()
            cur_phash = self._screenshot_phash(screenshot_path)

            # Skip re-OCR / re-judging if the screen hasn't meaningfully changed
            # since the last screen we already judged inconsistent.
            unchanged = (
                last_judged_phash is not None
                and cur_phash is not None
                and (cur_phash - last_judged_phash) <= 2
            )

            if not unchanged:
                try:
                    current_text = await asyncio.to_thread(extract_ocr_text, screenshot_path)
                except OcrConfigError:
                    # Vision is not configured; let the caller decide whether to
                    # fall back to legacy hash conditions or skip the check.
                    raise
                except Exception as e:  # noqa: BLE001 - transient OCR error; retry
                    logger.warning(
                        f"OCR of current screen failed for step {step.step_id} "
                        f"(attempt {attempts}): {e}"
                    )
                    current_text = None

                if current_text is not None:
                    # Only take the deterministic text-match fast-path when we have
                    # recorded expected text. An empty expected (no recorded
                    # screenshot) must always defer to the LLM readiness judge,
                    # which reasons from the description / previous step / intent.
                    if expected_text.strip():
                        similarity = text_similarity(expected_text, current_text)
                        if similarity >= self.ocr_precondition_text_similarity_threshold:
                            logger.debug(
                                f"OCR precondition for step {step.step_id} passed by text "
                                f"similarity {similarity:.2f} after {attempts} attempts ({elapsed:.2f}s)"
                            )
                            return True

                    # Ask the LLM once for this distinct screen state.
                    if checker is None:
                        from vscuse_v2.core.ocr_precondition import OcrPreconditionChecker
                        checker = OcrPreconditionChecker()

                    verdict = await checker.judge_consistency(
                        expected_text=expected_text,
                        current_text=current_text,
                        description=step.description,
                        target_x=target_x,
                        target_y=target_y,
                        intent=intent,
                        prev_description=prev_description,
                    )
                    last_verdict = verdict
                    if verdict.consistent and verdict.confidence >= self.ocr_precondition_confidence_threshold:
                        logger.info(
                            f"OCR precondition for step {step.step_id} passed by AI "
                            f"(confidence {verdict.confidence:.2f}) after {attempts} attempts ({elapsed:.2f}s)"
                        )
                        return True

                    # Cache this screen as "already judged" only for a genuine
                    # verdict (confidence > 0). A judge error returns confidence
                    # 0.0; caching it would suppress re-judging of an unchanged
                    # screen and turn one transient failure into a full timeout.
                    if verdict.confidence > 0.0:
                        last_judged_phash = cur_phash

            if elapsed >= wait_timeout:
                logger.warning(
                    f"OCR precondition timeout for step {step.step_id} after "
                    f"{attempts} attempts ({elapsed:.2f}s)"
                )
                if last_verdict is not None and last_verdict.confidence > 0.0:
                    self._last_precondition_detail = (
                        f"AI OCR readiness judged not ready (confidence "
                        f"{last_verdict.confidence:.2f}): {last_verdict.reasoning}"
                    )
                elif last_verdict is not None:
                    self._last_precondition_detail = (
                        f"AI OCR readiness judge could not complete: {last_verdict.reasoning}"
                    )
                else:
                    self._last_precondition_detail = (
                        "AI OCR readiness check timed out before any screen could be judged"
                    )
                return False

            await asyncio.sleep(retry_interval)

    def _check_postconditions(self, step: Step) -> bool:
        """Check if postconditions are met."""
        if not step.postconditions:
            return True

        screenshot_path = Path(self._docker_client.take_screenshot())
        logger.debug(f"Postcondition screenshot taken: {screenshot_path}")
        results = validate_postconditions(step.postconditions, screenshot_path)
        failures = [r for r in results if not r.success]

        if failures:
            logger.warning(f"Step {step.step_id}: {len(failures)} postcondition failures")
            return False
        return True

    async def _wait_for_stable_screenshot(self, max_wait: float = 10.0) -> str:
        """Wait for screenshot to stabilize before proceeding.

        Ensures the page/application is not loading or waiting for responses
        by detecting when the UI content has stopped changing significantly.

        Args:
            max_wait: Maximum time to wait for stability (seconds, capped at 10s)

        Returns:
            str: Path to the stable screenshot
        """
        stability_checks = 3    # Need 3 consecutive stable screenshots
        check_interval = 1.5   # Check every 1.5 seconds

        start_time = time.time()
        stable_count = 0
        previous_screenshot_path = None

        logger.debug(f"Waiting for UI stability - detecting loading/response states (max {max_wait}s)")

        while time.time() - start_time < max_wait:
            try:
                # Take screenshot
                screenshot_path = self._docker_client.take_screenshot()

                # Compare with previous screenshot
                if previous_screenshot_path is not None:
                    stability_ratio = detect_loading_stability(previous_screenshot_path, screenshot_path)

                    # More appropriate threshold for loading detection (90% instead of 99.9%)
                    # This ignores cursor blinks but catches loading spinners, content changes, etc.
                    if stability_ratio >= 0.95:
                        stable_count += 1
                        logger.debug(f"UI stable - no loading detected ({stable_count}/{stability_checks}, stability: {stability_ratio:.3f})")

                        if stable_count >= stability_checks:
                            elapsed = time.time() - start_time
                            logger.debug(f"UI stabilized - ready for interaction after {elapsed:.2f}s")
                            return screenshot_path
                    else:
                        # Significant UI changes detected - likely loading/processing
                        stable_count = 0
                        logger.debug(f"UI changing - loading/processing detected (stability: {stability_ratio:.3f})")

                previous_screenshot_path = screenshot_path
                await asyncio.sleep(check_interval)

            except Exception as e:
                logger.warning(f"Error during stability check: {str(e)}")
                # Fallback to basic screenshot if comparison fails
                return self._docker_client.take_screenshot()

        # Timeout reached - assume UI is stable enough
        elapsed = time.time() - start_time
        logger.debug(f"UI stability timeout after {elapsed:.2f}s - proceeding with last capture")
        return self._docker_client.take_screenshot()

    async def _wait_for_conditions(self, conditions: List[str], step: Step, condition_type: str) -> bool:
        """Wait for conditions to be met with retry mechanism."""
        if not conditions:
            return True

        wait_timeout = self.precondition_wait_timeout
        retry_interval = self.precondition_retry_interval

        if step and step.precondition_wait_timeout is not None:
            wait_timeout = step.precondition_wait_timeout
        if step and step.precondition_retry_interval is not None:
            retry_interval = step.precondition_retry_interval

        last_llm_detail = None
        start_time = asyncio.get_event_loop().time()
        attempts = 0

        while True:
            attempts += 1
            elapsed = asyncio.get_event_loop().time() - start_time

            # Extract hover coordinates from conditions if available
            hover_x, hover_y = None, None
            for condition in conditions:
                parsed = parse_condition(condition, "precondition")
                if parsed.success and parsed.coordinates is not None:
                    hover_x, hover_y = parsed.coordinates
                    condition_format = parsed.condition_format.value if parsed.condition_format else "unknown"
                    logger.debug(f"Get hover coordinates from {condition_format} condition: ({hover_x}, {hover_y})")
                    break  # Use the first valid condition with coordinates found

            # Apply hover pattern if coordinates are available
            if hover_x is not None and hover_y is not None:
                import random

                # Generate random hover coordinates within 1024x768 resolution
                random_hover_x = random.randint(50, 974)  # Leave 50px margin from edges
                random_hover_y = random.randint(50, 718)  # Leave 50px margin from edges

                logger.debug(f"Attempt {attempts}: hovering at random coordinates ({random_hover_x}, {random_hover_y})")

                # Always hover at random coordinates first to reset UI state
                random_hover_data = {"x": random_hover_x, "y": random_hover_y}
                self._docker_client.hover(random_hover_data)
                await asyncio.sleep(0.1)

                # On odd attempts (1, 3, 5...), also hover to the actual target
                if attempts % 2 != 0:
                    logger.debug(f"Odd attempt {attempts}: hovering to target ({hover_x}, {hover_y})")
                    interaction_data = {"x": hover_x, "y": hover_y}
                    self._docker_client.hover(interaction_data)
                    # Wait for UI to settle after hover action to ensure consistent screenshot validation
                    # This prevents hash calculation inconsistencies caused by hover effects and animations
                    await asyncio.sleep(0.3)
                else:
                    logger.debug(f"Even attempt {attempts}: skipping target hover")

            # Validate conditions
            screenshot_path = Path(self._docker_client.take_screenshot())
            logger.debug(f"Precondition screenshot taken: {screenshot_path}")
            result = validate_preconditions(conditions, screenshot_path)

            if result.success:
                logger.debug(f"{condition_type.title()} met after {attempts} attempts ({elapsed:.2f}s) - {result.reason}")
                return True

            # If automated validation failed and we're near timeout, try LLM-based condition analysis
            if elapsed >= wait_timeout * 0.9:  # Use LLM when 90% of timeout is reached
                logger.info(f"Automated {condition_type} validation failed after {elapsed:.2f}s, trying LLM analysis...")

                try:
                    # Use condition agent to analyze compatibility via visual comparison
                    decision, explanation = await ConditionAgent.check_step_compatibility(
                        step=step,
                        current_screenshot_path=str(screenshot_path)
                    )

                    logger.info(f"LLM condition analysis result: {decision} - {explanation}")
                    last_llm_detail = f"AI(condition_agent) {decision}: {explanation}"

                    if decision == "EXECUTE":
                        logger.info(f"LLM recommends proceeding despite failed {condition_type} - {explanation}")
                        return True
                    elif decision == "ABORT":
                        logger.error(f"LLM recommends aborting due to serious UI issues - {explanation}")
                        self._last_precondition_detail = last_llm_detail
                        return False
                    elif decision == "SKIP":
                        logger.warning(f"LLM recommends skipping due to incompatible UI state - {explanation}")
                        self._last_precondition_detail = last_llm_detail
                        return False
                    # For "WAIT" or unknown decisions, continue with normal retry logic
                    else:
                        logger.info(f"LLM recommends waiting for UI to stabilize - {explanation}")

                except Exception as llm_error:
                    logger.error(f"LLM condition analysis failed: {llm_error}")
                    # Continue with normal timeout behavior on LLM failure

            if elapsed >= wait_timeout:
                logger.warning(f"{condition_type.title()} timeout after {attempts} attempts ({elapsed:.2f}s) - {result.reason}")
                self._last_precondition_detail = last_llm_detail or (
                    f"automated {condition_type} validation failed: {result.reason}"
                )
                return False

            await asyncio.sleep(retry_interval)

    async def execute_plan(self, plan: ExecutablePlan,
                          start_index: int = 0,
                          end_index: Optional[int] = None) -> PlanExecutionResult:
        """Execute a complete executable plan using execution_order for step sequencing."""
        # Validate all variables before starting execution (env, secret, var)
        validation = self.resolver.validate_variables(plan)
        if not validation['valid']:
            error_details = []

            if validation.get('missing_env_vars'):
                error_details.append(f"Missing required environment variables: {', '.join(validation['missing_env_vars'])}")

            if validation.get('rule_violations'):
                error_details.append(f"Validation rule violations: {'; '.join(validation['rule_violations'])}")

            error_msg = ". ".join(error_details) + ". Please fix these issues before executing the plan."
            logger.error(error_msg)

            execution_result = PlanExecutionResult.from_plan(plan, 0, 0, 0)
            execution_result.exception = error_msg
            execution_result.end_time = datetime.now().isoformat()
            return execution_result
        else:
            logger.info("✅ All variable validations passed (env, secret, var)")

        # Reset fact store at the start of plan execution
        fact_store = FactStore()
        fact_store.reset_facts()
        logger.debug("Fact store reset for new plan execution")

        execution_order = plan.plan_metadata.execution_order
        if not execution_order:
            error_msg = "No execution_order specified in plan metadata. Execution order is required for proper step sequencing."
            logger.error(error_msg)
            execution_result = PlanExecutionResult.from_plan(plan, 0, 0, 0)
            execution_result.exception = error_msg
            execution_result.end_time = datetime.now().isoformat()
            return execution_result

        total_items = len(execution_order)
        end_index = min(end_index or total_items, total_items)
        start_index = max(0, start_index)

        # Create a lookup dictionary for steps by step_id for efficient access
        step_lookup = {step.step_id: step for step in plan.steps}

        # Expand group references in execution_order and collect group steps into step_lookup
        expanded_execution_order = await self._expand_group_references(execution_order, step_lookup)
        execution_order = expanded_execution_order

        # Update total items and end_index based on expanded execution order
        total_items = len(execution_order)
        end_index = min(end_index or total_items, total_items)

        # Update configuration from plan metadata if available
        self._update_config_from_plan(plan)

        # Initialize execution result
        execution_result = PlanExecutionResult.from_plan(plan, start_index, end_index, total_items)

        logger.info(f"Executing plan: {plan.plan_metadata.name}")
        logger.info(f"Range: {start_index} to {end_index} ({end_index - start_index} items)")
        logger.info(f"Execution order: {execution_order[start_index:end_index]}")
        logger.info("=" * 60)

        self.current_plan = plan

        try:
            # Execute steps according to execution_order
            for i in range(start_index, end_index):
                step_id = execution_order[i]
                step = step_lookup.get(step_id)

                if not step:
                    error_msg = f"Step {step_id} in execution_order not found in plan steps"
                    logger.error(error_msg)
                    execution_result.error_count += 1
                    execution_result.errors.append({
                        "item_index": i,
                        "step_id": step_id,
                        "error": error_msg
                    })
                    if self.stop_on_error:
                        logger.info(f"Stopping execution due to missing step {step_id}")
                        break
                    continue

                execution_result.executed_count += 1

                try:
                    # Store original step description before execution (may be modified by variable resolution)
                    original_description = step.description
                    step_execution_result = await self.execute_step(step)
                    # Restore original description in execution result
                    step_execution_result.description = original_description
                    execution_result.step_execution_results.append(step_execution_result)

                    # Check if step execution was cancelled
                    if step_execution_result.action == "cancelled":
                        logger.info(f"Plan execution cancelled during step {step.step_id}")
                        break

                    # Update counters and handle errors
                    if step_execution_result.success:
                        execution_result.success_count += 1
                    else:
                        execution_result.error_count += 1
                        execution_result.errors.append({
                            "item_index": i,
                            "step_id": step.step_id,
                            "error": step_execution_result.error
                        })

                        if self.stop_on_error:
                            logger.info(f"Stopping execution due to error in step {step.step_id}")
                            break

                except asyncio.CancelledError:
                    logger.info(f"Plan execution cancelled during step {step.step_id}")
                    # Don't re-raise, let plan complete gracefully
                    break

                # Delay between steps
                if i < end_index - 1 and self.delay > 0:
                    await asyncio.sleep(self.delay)

        except KeyboardInterrupt:
            logger.info("Execution interrupted by user")
            execution_result.interrupted = True
        except asyncio.CancelledError:
            logger.info(f"Plan {plan.plan_id} execution was cancelled")
            execution_result.interrupted = True
        except Exception as e:
            logger.error(f"Execution failed: {e}")
            execution_result.exception = str(e)

        execution_result.end_time = datetime.now().isoformat()

        # Capture runtime variables from resolver
        execution_result.runtime_variables = self.resolver.get_runtime_variables()

        self._log_execution_summary(execution_result)

        # Generate test report if enabled
        if self.reporter and self.current_plan:
            self._generate_report(execution_result)

        self.execution_log.append(execution_result)
        return execution_result

    async def _expand_group_references(self, execution_order: List[str], step_lookup: Optional[Dict[str, Step]] = None) -> List[str]:
        """Expand group plan references in execution_order.

        Items starting with 'plan_' are treated as group references and expanded
        to their constituent steps. Group steps are also added to step_lookup
        so they can be found during execution.
        """
        expanded_order = []

        for item in execution_order:
            if item.startswith('plan_'):
                # This is a group reference, load and expand it
                try:
                    group_plan = await self._load_group_plan(item)
                    if group_plan and group_plan.plan_metadata.execution_order:
                        # Add group steps to step_lookup so executor can find them
                        if step_lookup is not None:
                            for step in group_plan.steps:
                                step_lookup[step.step_id] = step

                        # Recursively expand in case group plans reference other groups
                        group_expanded = await self._expand_group_references(
                            group_plan.plan_metadata.execution_order, step_lookup
                        )
                        expanded_order.extend(group_expanded)
                        logger.info(f"Expanded group '{item}' to {len(group_expanded)} steps")
                    else:
                        logger.warning(f"Group plan '{item}' has no execution_order, skipping")
                except Exception as e:
                    logger.error(f"Failed to expand group reference '{item}': {e}")
                    # Continue with other items even if one group fails
                    continue
            else:
                # Regular step reference, add as-is
                expanded_order.append(item)

        return expanded_order

    async def _load_group_plan(self, group_reference: str) -> Optional[ExecutablePlan]:
        """Load a group plan from the plans directory.

        Args:
            group_reference: Group reference like 'plan_login_flow'

        Returns:
            ExecutablePlan if found and has "group" tag, None otherwise
        """
        # Convert plan_xyz to plan_xyz.json filename
        plan_filename = f"{group_reference}.json"

        # Look for the plan file in the plans directory
        # Use relative path from current working directory
        plan_path = Path("plans") / plan_filename

        if not plan_path.exists():
            logger.error(f"Group plan file not found: {plan_path}")
            return None

        try:
            logger.debug(f"Loading group plan from: {plan_path}")
            with open(plan_path, 'r', encoding='utf-8') as f:
                plan_data = json.load(f)

            plan = ExecutablePlan.parse_obj(plan_data)

            # Validate that this plan has the "group" tag
            if "group" not in plan.plan_metadata.tags:
                logger.error(f"Plan {group_reference} does not have 'group' tag - not a valid group plan")
                return None

            return plan
        except Exception as e:
            logger.error(f"Failed to load group plan from {plan_path}: {e}")
            return None

    def _update_config_from_plan(self, plan: ExecutablePlan):
        """Update configuration from plan metadata."""
        # Only override if the plan explicitly sets these values (not just schema defaults)
        # We can detect this by checking if the values are different from the ExecutionConfig defaults
        execution_defaults = ExecutionConfig()
        exec_context = plan.plan_metadata.execution_context

        if exec_context.precondition_wait_timeout != execution_defaults.precondition_wait_timeout:
            self.precondition_wait_timeout = exec_context.precondition_wait_timeout

        if exec_context.precondition_retry_interval != execution_defaults.precondition_retry_interval:
            self.precondition_retry_interval = exec_context.precondition_retry_interval

        if exec_context.delay_between_steps != execution_defaults.delay_between_steps:
            self.delay = exec_context.delay_between_steps

        if exec_context.stop_on_error != execution_defaults.stop_on_error:
            self.stop_on_error = exec_context.stop_on_error

        if exec_context.step_retry_timeout != execution_defaults.step_retry_timeout:
            self.step_retry_timeout = exec_context.step_retry_timeout

    def _generate_report(self, execution_result: PlanExecutionResult):
        """Generate test report if reporting is enabled."""
        try:
            report_path = self.reporter.generate_report(
                plan=self.current_plan,
                execution_result=execution_result,
                plan_path=self.current_plan_path
            )
            logger.info(f"✅ Test report generated: {report_path}")
            # Convert Windows path to proper file URL format
            file_url = report_path.absolute().as_uri()
            logger.info(f"🌐 Open in browser: {file_url}")
        except Exception as e:
            logger.error(f"Failed to generate test report: {e}")
            logger.debug("Report generation error details:", exc_info=True)

    def _log_execution_summary(self, result: PlanExecutionResult) -> None:
        """Log execution summary."""
        logger.info("=" * 60)
        logger.info("[SUMMARY] EXECUTION SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Plan: {result.plan_id}")
        logger.info(f"Items executed: {result.executed_count}")
        logger.info(f"Successful: {result.success_count}")
        logger.info(f"Errors: {result.error_count}")

        if result.executed_count > 0:
            success_rate = result.success_count / result.executed_count * 100
            logger.info(f"Success rate: {success_rate:.1f}%")
        logger.info("=" * 60)

    def load_plan(self, plan_path: Path) -> ExecutablePlan:
        """Load plan from JSON file."""
        with open(plan_path, 'r', encoding='utf-8') as f:
            plan_data = json.load(f)
        return ExecutablePlan.parse_obj(plan_data)

    async def execute_from_file(self, plan_path: Path, **kwargs) -> PlanExecutionResult:
        """Load and execute a plan from file."""
        plan = self.load_plan(plan_path)
        return await self.execute_plan(plan, **kwargs)

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        # Currently no cleanup needed, but this allows for future resource management
        pass
