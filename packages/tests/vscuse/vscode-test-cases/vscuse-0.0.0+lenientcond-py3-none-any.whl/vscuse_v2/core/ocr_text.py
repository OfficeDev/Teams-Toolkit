#!/usr/bin/env python3
"""
OCR text utilities.

Shared, dependency-light helpers for extracting text from a screenshot using
Azure Computer Vision (READ) and for comparing two OCR text blobs. These are used
by both the planner (to precompute the *expected* screen text at record time) and
the executor (to OCR the *current* screen at runtime for precondition checking).

Kept separate from ``ocr_agent`` so it can be imported without pulling in the
OpenAI Agents SDK. ``OcrAgent`` reuses ``extract_ocr_blocks`` from here.
"""

import base64
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError

from vscuse_v2.config import get_azure_vision_config
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)

# Number of times to retry an Azure Vision call when the service throttles (429),
# and the base backoff (seconds) between attempts.
_VISION_MAX_RETRIES = 5
_VISION_RETRY_BASE_DELAY = 1.0

# Identifier for the OCR engine used, stored alongside expected text so future
# changes to the engine can be detected during comparison.
OCR_ENGINE = "azure-vision-read"

# Prefix for the structured, versioned OCR precondition payload stored inside a
# step's ``preconditions`` list, e.g. ``ocr:v1:<base64url(json)>``.
OCR_PRECONDITION_PREFIX = "ocr:v1:"

_vision_client: Optional[ImageAnalysisClient] = None


class OcrConfigError(RuntimeError):
    """Raised when Azure Vision is not configured for OCR."""


def _get_vision_client() -> ImageAnalysisClient:
    """Lazily build a shared Azure Vision client from configuration."""
    global _vision_client
    if _vision_client is None:
        cfg = get_azure_vision_config()
        if not cfg.endpoint or cfg.endpoint.startswith("${"):
            raise OcrConfigError(
                "AZURE_VISION_ENDPOINT is not configured. It is required for OCR-based preconditions."
            )
        if not cfg.api_key or cfg.api_key.startswith("${"):
            raise OcrConfigError(
                "AZURE_VISION_KEY is not configured. It is required for OCR-based preconditions."
            )
        _vision_client = ImageAnalysisClient(
            endpoint=cfg.endpoint,
            credential=AzureKeyCredential(cfg.api_key),
        )
    return _vision_client


def _read_image_bytes(image_source: Union[str, bytes, Path]) -> bytes:
    """Resolve an image source (raw bytes, data URI, or file path) to bytes."""
    if isinstance(image_source, bytes):
        return image_source
    if isinstance(image_source, Path):
        return image_source.read_bytes()
    if isinstance(image_source, str):
        if image_source.startswith("data:"):
            _, b64 = image_source.split(",", 1)
            return base64.b64decode(b64)
        return Path(image_source).read_bytes()
    raise TypeError(f"Unsupported image source type: {type(image_source)!r}")


def _analyze_with_retry(image_data: bytes):
    """Call Azure Vision READ, retrying on 429 throttling with backoff.

    Honors the ``Retry-After`` header when present, otherwise uses exponential
    backoff. Re-raises the last error if all retries are exhausted, or any
    non-429 error immediately.
    """
    client = _get_vision_client()
    last_error: Optional[Exception] = None
    for attempt in range(1, _VISION_MAX_RETRIES + 1):
        try:
            return client.analyze(image_data=image_data, visual_features=[VisualFeatures.READ])
        except HttpResponseError as e:
            if getattr(e, "status_code", None) != 429 or attempt == _VISION_MAX_RETRIES:
                raise
            last_error = e
            retry_after = None
            try:
                retry_after = float(e.response.headers.get("Retry-After", ""))
            except (AttributeError, TypeError, ValueError):
                retry_after = None
            delay = retry_after if retry_after and retry_after > 0 else _VISION_RETRY_BASE_DELAY * attempt
            logger.warning(
                f"Azure Vision throttled (429), attempt {attempt}/{_VISION_MAX_RETRIES}; "
                f"retrying in {delay:.1f}s"
            )
            time.sleep(delay)
    if last_error:
        raise last_error


def extract_ocr_blocks(image_source: Union[str, bytes, Path]) -> List[Dict]:
    """Run Azure Vision READ and return a flat list of ``{text, bbox}`` line dicts.

    Args:
        image_source: Raw image bytes, a ``data:`` URI, or a file path.

    Returns:
        List of ``{"text": str, "bbox": [x1, y1, x2, y2]}``. Empty if no text.
    """
    image_data = _read_image_bytes(image_source)
    result = _analyze_with_retry(image_data)

    blocks: List[Dict] = []
    if not result.read or not result.read.blocks:
        return blocks

    for block in result.read.blocks:
        for line in block.lines:
            polygon = line.bounding_polygon
            if not polygon:
                continue
            if hasattr(polygon[0], "x"):
                xs = [p.x for p in polygon]
                ys = [p.y for p in polygon]
            else:
                xs = [p[0] for p in polygon]
                ys = [p[1] for p in polygon]
            bbox = [int(min(xs)), int(min(ys)), int(max(xs)), int(max(ys))]
            blocks.append({"text": line.text, "bbox": bbox})

    return blocks


def extract_ocr_text(image_source: Union[str, bytes, Path]) -> str:
    """Extract all readable text from an image as a newline-joined string.

    Lines are ordered top-to-bottom, then left-to-right, so the result is stable
    across runs regardless of the order Azure returns blocks in.
    """
    blocks = extract_ocr_blocks(image_source)
    # Sort by vertical position first (with a small band tolerance), then horizontal.
    blocks.sort(key=lambda b: (b["bbox"][1] // 10, b["bbox"][0]))
    return "\n".join(b["text"] for b in blocks if b.get("text"))


_WS_RE = re.compile(r"\s+")
_NONWORD_RE = re.compile(r"[^\w]+", re.UNICODE)


def normalize_text(text: str) -> str:
    """Normalize OCR text for robust comparison: lowercase, collapse whitespace."""
    if not text:
        return ""
    return _WS_RE.sub(" ", text.strip().lower())


def _tokenize(text: str) -> List[str]:
    if not text:
        return []
    return [t for t in _NONWORD_RE.split(text.lower()) if t]


def text_similarity(expected: str, current: str) -> float:
    """Token-set Jaccard similarity between two texts.

    Returns a value in ``[0.0, 1.0]``. Two empty texts are treated as identical
    (1.0); one empty and one non-empty is 0.0.
    """
    exp_tokens = set(_tokenize(expected))
    cur_tokens = set(_tokenize(current))
    if not exp_tokens and not cur_tokens:
        return 1.0
    if not exp_tokens or not cur_tokens:
        return 0.0
    intersection = len(exp_tokens & cur_tokens)
    union = len(exp_tokens | cur_tokens)
    return intersection / union if union else 0.0


def get_image_viewport(image_source: Union[str, bytes, Path]) -> Optional[Dict[str, int]]:
    """Return ``{"width": w, "height": h}`` for an image, or None on failure."""
    try:
        import io

        from PIL import Image

        with Image.open(io.BytesIO(_read_image_bytes(image_source))) as img:
            return {"width": img.width, "height": img.height}
    except Exception as e:  # noqa: BLE001 - best-effort metadata
        logger.debug(f"Could not determine image viewport: {e}")
        return None


# ---------------------------------------------------------------------------
# Structured precondition payload codec: ``ocr:v1:<base64url(json)>``
# ---------------------------------------------------------------------------


def encode_ocr_precondition(
    full_text: str,
    viewport: Optional[Dict[str, int]] = None,
    target: Optional[Dict[str, int]] = None,
    engine: str = OCR_ENGINE,
    prev_description: Optional[str] = None,
) -> str:
    """Build the versioned ``ocr:v1:<base64url(json)>`` precondition string.

    Args:
        full_text: The expected whole-screen OCR text.
        viewport: Recorded viewport ``{"width", "height"}`` (optional).
        target: Recorded click target ``{"x", "y"}`` (optional).
        engine: OCR engine identifier.
        prev_description: Description of the previous step (optional), used as
            context by the runtime LLM readiness judge.

    Returns:
        A single precondition string suitable for storing in ``step.preconditions``.
    """
    payload: Dict[str, Any] = {
        "version": 1,
        "engine": engine,
        "full_text": full_text or "",
        "norm_text": normalize_text(full_text),
    }
    if viewport:
        payload["viewport"] = viewport
    if target:
        payload["target"] = target
    if prev_description:
        payload["prev_description"] = prev_description

    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    b64 = base64.urlsafe_b64encode(raw).decode("ascii")
    return f"{OCR_PRECONDITION_PREFIX}{b64}"


def is_ocr_precondition(condition: str) -> bool:
    """True if *condition* is a structured OCR precondition string."""
    return isinstance(condition, str) and condition.startswith(OCR_PRECONDITION_PREFIX)


def parse_ocr_precondition(condition: str) -> Optional[Dict[str, Any]]:
    """Decode an ``ocr:v1:`` precondition string into its payload dict.

    Returns None if the string is not a valid OCR precondition payload.
    """
    if not is_ocr_precondition(condition):
        return None
    try:
        b64 = condition[len(OCR_PRECONDITION_PREFIX):]
        raw = base64.urlsafe_b64decode(b64.encode("ascii"))
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict):
            return None
        return payload
    except Exception as e:  # noqa: BLE001 - tolerate malformed payloads
        logger.warning(f"Failed to parse OCR precondition payload: {e}")
        return None


def find_ocr_precondition(preconditions: Optional[List[str]]) -> Optional[Dict[str, Any]]:
    """Return the decoded payload of the first ``ocr:v1:`` entry, or None."""
    for condition in preconditions or []:
        payload = parse_ocr_precondition(condition)
        if payload is not None:
            return payload
    return None
