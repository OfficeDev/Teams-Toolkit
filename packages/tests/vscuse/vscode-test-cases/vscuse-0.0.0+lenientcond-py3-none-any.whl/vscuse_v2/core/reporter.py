#!/usr/bin/env python3
"""
Test Report Generator for VSC-Use v2

Generates static HTML reports from execution results.
"""

import base64
import html
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel

from vscuse_v2.utils.logger import setup_logger

from .models import PlanExecutionResult, StepExecutionResult, StepReportData
from .schema import ExecutablePlan

logger = setup_logger(__name__)


class Reporter:
    """Generates HTML test reports from execution results."""

    def __init__(self, output_dir: str = "test_report"):
        self.output_dir = Path(output_dir)
        self.screenshot_cache = {}

    def generate_report(
        self,
        plan: ExecutablePlan,
        execution_result: PlanExecutionResult,
        plan_path: Optional[Path] = None
    ) -> Path:
        """Generate a complete test report from execution results."""
        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Collect screenshots from step execution results and plan expected screenshots
        step_screenshots = self._collect_step_screenshots(execution_result.step_execution_results, plan)

        # Generate HTML content
        html_content = self._generate_html_report(plan, execution_result, plan_path, step_screenshots)

        # Save report
        report_path = self.output_dir / "test_report.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        screenshot_count = sum(len(screenshots) for screenshots in step_screenshots.values())
        logger.info(f"Test report generated: {report_path}")
        logger.info(f"Screenshots embedded: {screenshot_count}")

        return report_path

    def _collect_step_screenshots(self, step_results: List[StepExecutionResult], plan: Optional[ExecutablePlan] = None) -> Dict[str, List[Dict]]:
        """Collect screenshots from step execution results and plan expected screenshots."""
        step_screenshots = {}

        # Build step lookup for expected screenshot resolution
        plan_screenshots = getattr(plan, 'screenshots', None) or {}
        step_lookup = {step.step_id: step for step in plan.steps} if plan else {}

        for step_result in step_results:
            # step_result is now a StepExecutionResult object, not a dict
            screenshots = []

            # Get expected screenshot from plan only for failed steps
            step = step_lookup.get(step_result.step_id)
            if step and step.screenshot and not step_result.success:
                expected_data_url = None
                screenshot_ref = step.screenshot
                if screenshot_ref.startswith('data:'):
                    expected_data_url = screenshot_ref
                elif isinstance(plan_screenshots, dict):
                    expected_data_url = plan_screenshots.get(screenshot_ref)

                if expected_data_url and expected_data_url.startswith('data:'):
                    screenshots.append({
                        'path': '',
                        'filename': f'expected_{step_result.step_id}',
                        'base64': expected_data_url,
                        'size': len(expected_data_url),
                        'type': 'expected',
                        'label': 'Expected'
                    })

            # Get before screenshot if available
            if step_result.before_screenshot:
                screenshot_data = self._convert_image_to_base64(Path(step_result.before_screenshot))
                if screenshot_data:
                    screenshot_data['type'] = 'before'
                    screenshot_data['label'] = 'Before Execution'
                    screenshots.append(screenshot_data)

            # Get after screenshot if available
            if step_result.after_screenshot:
                screenshot_data = self._convert_image_to_base64(Path(step_result.after_screenshot))
                if screenshot_data:
                    screenshot_data['type'] = 'after'
                    screenshot_data['label'] = 'After Execution'
                    screenshots.append(screenshot_data)

            if screenshots:
                step_screenshots[step_result.step_id] = screenshots
                logger.debug(f"Step {step_result.step_id}: Collected {len(screenshots)} screenshots")

        return step_screenshots

    def _convert_image_to_base64(self, image_path: Path) -> Optional[Dict]:
        """Convert image file to base64 data with metadata."""
        try:
            if not image_path.exists():
                return None

            # Check cache first
            cache_key = str(image_path)
            if cache_key in self.screenshot_cache:
                return self.screenshot_cache[cache_key]

            # Read and encode image
            with open(image_path, 'rb') as img_file:
                img_data = img_file.read()

            # Determine MIME type
            mime_type = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp'
            }.get(image_path.suffix.lower(), 'image/jpeg')

            # Create base64 data URL
            base64_str = base64.b64encode(img_data).decode('utf-8')
            data_url = f"data:{mime_type};base64,{base64_str}"

            # Create screenshot data object
            screenshot_data = {
                'path': str(image_path),
                'filename': image_path.name,
                'base64': data_url,
                'size': len(img_data)
            }

            # Cache the result
            self.screenshot_cache[cache_key] = screenshot_data
            return screenshot_data

        except Exception as e:
            logger.warning(f"Failed to convert image {image_path}: {e}")
            return None

    def _format_execution_result(self, result_data: Any, compact: bool = True) -> str:
        """Format execution result for better display - simple and generic for all agent types.

        Args:
            result_data: The result data to format
            compact: If True, use compact format for timeline. If False, use detailed format for modal.
        """
        if not result_data:
            return '<p class="text-muted mb-0">No result data available</p>' if compact else '<p class="text-muted">No result data available</p>'

        # If it's a string that looks like JSON, try to parse it
        if isinstance(result_data, str):
            try:
                result_data = json.loads(result_data)
            except (json.JSONDecodeError, ValueError):
                # If it's not JSON, display as formatted text
                text = str(result_data)
                if compact:
                    # Show full text with wrapping for timeline (no truncation)
                    return f'<pre class="text-result-wrapped small mb-0">{html.escape(text)}</pre>'
                else:
                    return f'<div class="text-result"><pre class="bg-light p-3 rounded border">{html.escape(text)}</pre></div>'

        # Handle dictionary results - simple key-value display
        if isinstance(result_data, dict):
            return self._format_simple_dict_result(result_data, compact=compact)

        # Handle other data types
        try:
            json_str = json.dumps(self._serialize_for_json(result_data), indent=2)
            if compact:
                # Show wrapped JSON for timeline
                return f'<pre class="json-result-wrapped small mb-0"><code>{html.escape(json_str)}</code></pre>'
            else:
                return f'<div class="json-result"><pre class="bg-light p-3 rounded border small"><code>{html.escape(json_str)}</code></pre></div>'
        except Exception:
            text = str(result_data)
            if compact:
                return f'<pre class="text-result-wrapped small mb-0">{html.escape(text)}</pre>'
            else:
                return f'<div class="text-result"><pre class="bg-light p-3 rounded border">{html.escape(text)}</pre></div>'

    def _format_simple_dict_result(self, result_data: Dict, compact: bool = True) -> str:
        """Format dictionary results in a simple, generic way.

        Args:
            result_data: Dictionary to format
            compact: If True, use compact badge format for timeline. If False, use detailed format for modal.
        """
        if not result_data:
            return '<p class="text-muted mb-0">Empty result</p>'

        html_parts = ['<div class="d-flex flex-wrap gap-2">']

        for key, value in result_data.items():
            if value is not None:
                # Format the key nicely
                display_key = key.replace('_', ' ').title()
                display_value = str(value)

                # Truncate based on format
                max_length = 80 if compact else 150
                if len(display_value) > max_length:
                    display_value = display_value[:max_length-3] + '...'

                html_parts.append(f'''
                    <span class="badge bg-light text-dark border">
                        <strong>{html.escape(display_key)}:</strong> {html.escape(display_value)}
                    </span>''')

        html_parts.append('</div>')
        return ''.join(html_parts)

    def _serialize_for_json(self, obj: Any) -> Any:
        """Convert objects to JSON-serializable format."""
        if isinstance(obj, BaseModel):
            return obj.model_dump()
        elif isinstance(obj, dict):
            return {k: self._serialize_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._serialize_for_json(item) for item in obj]
        elif hasattr(obj, '__dict__'):
            try:
                return {k: self._serialize_for_json(v) for k, v in obj.__dict__.items()}
            except Exception:
                return str(obj)
        elif hasattr(obj, 'model_dump'):
            try:
                return obj.model_dump()
            except Exception:
                return str(obj)
        else:
            try:
                json.dumps(obj)  # Test if it's already JSON serializable
                return obj
            except (TypeError, ValueError):
                return str(obj)

    def _resolve_group_context(self, plan_path: Optional[Path]) -> Tuple[Dict[str, Dict[str, str]], Dict[str, str]]:
        """Resolve group metadata and step-to-group mapping from plan/group files."""
        group_metadata: Dict[str, Dict[str, str]] = {}
        step_group_map: Dict[str, str] = {}

        if not plan_path:
            return group_metadata, step_group_map

        try:
            with open(plan_path, 'r', encoding='utf-8') as pf:
                original_plan_data = json.load(pf)

            execution_order = original_plan_data.get('plan_metadata', {}).get('execution_order', [])
            group_refs = [item for item in execution_order if isinstance(item, str) and item.startswith('plan_')]
            if not group_refs:
                return group_metadata, step_group_map

            groups_dir = plan_path.parent.parent / 'groups'
            if not groups_dir.exists():
                return group_metadata, step_group_map

            group_ids = set(group_refs)
            for group_file in groups_dir.glob('*.json'):
                try:
                    with open(group_file, 'r', encoding='utf-8') as gf:
                        group_data = json.load(gf)

                    metadata = group_data.get('plan_metadata', {})
                    group_id = metadata.get('plan_id')
                    if not group_id or group_id not in group_ids:
                        continue

                    group_name = metadata.get('name') or 'Unnamed Group'
                    group_metadata[group_id] = {
                        'id': group_id,
                        'name': group_name,
                        'path': str(group_file),
                    }

                    group_execution_order = metadata.get('execution_order', [])
                    if group_execution_order:
                        for step_id in group_execution_order:
                            if isinstance(step_id, str):
                                step_group_map[step_id] = group_id
                    else:
                        for step in group_data.get('steps', []):
                            step_id = step.get('step_id') if isinstance(step, dict) else None
                            if isinstance(step_id, str):
                                step_group_map[step_id] = group_id

                except Exception as e:
                    logger.warning(f"Failed to parse group context from {group_file}: {e}")

        except Exception as e:
            logger.warning(f"Failed to resolve group context from plan file: {e}")

        return group_metadata, step_group_map

    def _generate_html_report(
        self,
        plan: ExecutablePlan,
        execution_result: PlanExecutionResult,
        plan_path: Optional[Path] = None,
        step_screenshots: Dict[str, List[Dict]] = None
    ) -> str:
        """Generate the complete HTML report."""
        step_screenshots = step_screenshots or {}

        # Calculate summary statistics - now using object properties directly
        total_steps = execution_result.total_items
        executed_steps = execution_result.executed_count
        successful_steps = execution_result.success_count
        failed_steps = execution_result.error_count
        success_rate = (successful_steps / executed_steps * 100) if executed_steps > 0 else 0

        # Adoption counts for the new lenient OCR-retargeted precondition mechanism.
        new_precond_count = sum(
            1 for r in execution_result.step_execution_results
            if getattr(r, "new_precondition_applied", False)
        )
        # Of the steps that used the lenient precondition, how many actually had their
        # click coordinate moved by the downstream OCR re-target.
        ocr_retarget_count = sum(
            1 for r in execution_result.step_execution_results
            if getattr(r, "new_precondition_applied", False)
            and getattr(r, "ocr_retargeted", False)
        )

        total_duration = sum(
            r.execution_time for r in execution_result.step_execution_results
        )

        group_metadata, step_group_map = self._resolve_group_context(plan_path)

        # Create step lookup for getting original step data
        step_lookup = {step.step_id: step for step in plan.steps}

        # Generate timeline section with steps - combine execution results with step metadata.
        # If group context is available, steps are segmented by group with group headers.
        timeline_items = []
        grouped_timeline_parts: List[str] = []
        current_group_id: Optional[str] = None
        current_group_items: List[str] = []

        def flush_group_segment(group_id: Optional[str], items: List[str], segment_index: int) -> str:
            if not items:
                return ''

            # Steps not belonging to a group keep original rendering without a group container.
            if not group_id:
                return ''.join(items)

            group_info = group_metadata.get(group_id, {'id': group_id, 'name': 'Unknown Group'})
            safe_group_id = html.escape(str(group_info.get('id', group_id)))
            safe_group_name = html.escape(str(group_info.get('name', 'Unknown Group')))
            safe_group_path = html.escape(str(group_info.get('path', '')))

            return f'''
            <div class="group-section" data-group-id="{safe_group_id}">
                <div class="group-section-header" onclick="toggleGroupSteps(this)">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <input type="checkbox" class="form-check-input me-2" id="group-check-{segment_index}" onclick="event.stopPropagation()">
                            <i class="bi bi-chevron-down group-chevron me-2"></i>
                            <span class="group-title-label">Group: {safe_group_id} - </span>
                            <span class="group-name-copy" data-path="{safe_group_path}" onclick="event.stopPropagation(); copyGroupPath(this)" title="Click to copy path">{safe_group_name}</span>
                        </div>
                    </div>
                </div>
                <div class="group-steps">
                    {''.join(items)}
                </div>
            </div>'''

        for i, execution_result_item in enumerate(execution_result.step_execution_results):
            # Check if previous step had sensitive data - if so, we need to hide "before" screenshot
            hide_before_screenshot = False
            if i > 0:
                prev_step_result = execution_result.step_execution_results[i - 1]
                if prev_step_result.contains_sensitive_data:
                    hide_before_screenshot = True

            # Get the original step data
            original_step = step_lookup.get(execution_result_item.step_id)
            if original_step:
                # Create combined report data
                step_report_data = StepReportData.from_execution_and_step(execution_result_item, original_step)
                timeline_item_html = self._generate_timeline_item(step_report_data, i, step_screenshots, hide_before_screenshot)
            else:
                # Fallback: use just execution result (shouldn't happen in normal operation)
                timeline_item_html = self._generate_timeline_item_fallback(execution_result_item, i, step_screenshots, hide_before_screenshot)

            timeline_items.append(timeline_item_html)

            step_group_id = step_group_map.get(execution_result_item.step_id)
            if step_group_id != current_group_id:
                grouped_timeline_parts.append(
                    flush_group_segment(current_group_id, current_group_items, len(grouped_timeline_parts))
                )
                current_group_id = step_group_id
                current_group_items = []

            current_group_items.append(timeline_item_html)

        grouped_timeline_parts.append(
            flush_group_segment(current_group_id, current_group_items, len(grouped_timeline_parts))
        )

        timeline_html = ''.join(grouped_timeline_parts) if group_metadata else ''.join(timeline_items)

        # Generate error summary if needed
        error_summary = self._generate_error_summary(execution_result.errors)

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VSC-Use Test Report - {plan.plan_metadata.name}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    {self._generate_css_styles()}
</head>
<body class="bg-light">
    <div class="container-fluid py-4">
        {self._generate_header_section(plan, execution_result, total_steps, executed_steps, total_duration)}
        {self._generate_metrics_section(total_steps, executed_steps, successful_steps, failed_steps, success_rate, new_precond_count, ocr_retarget_count)}
        {self._generate_plan_info_section(plan, plan_path)}

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-play-circle me-2"></i>
                            Execution Timeline
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="execution-timeline">
                            {timeline_html}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {error_summary}
        {self._generate_details_section(execution_result, total_steps, executed_steps, total_duration)}
    </div>
    {self._generate_replay_modal(execution_result, step_lookup, step_screenshots)}
    {self._generate_modal_and_scripts(execution_result, step_lookup, step_screenshots, plan, plan_path)}
</body>
</html>'''

    def _generate_timeline_item(self, report_data: StepReportData, index: int, step_screenshots: Dict[str, List[Dict]], hide_before_screenshot: bool = False) -> str:
        """Generate a single timeline item for a step result with full step metadata."""
        # Use properties from the combined report data
        step_id = report_data.step_id
        success = report_data.success
        description = report_data.description
        execution_time = report_data.execution_time
        error = report_data.error
        tags = report_data.tags
        new_precond_badge = self._new_precondition_badge(report_data.execution_result)

        status_class = 'success' if success else 'failed'
        status_badge_class = 'status-success' if success else 'status-failed'
        status_text = 'SUCCESS' if success else 'FAILED'

        # Generate tags HTML
        tags_html = ''
        if tags:
            tag_badges = []
            for tag in tags:
                tag_badges.append(f'<span class="badge bg-secondary me-1">{tag}</span>')
            tags_html = f'''
            <div class="mt-2">
                <small class="text-muted me-2"><i class="bi bi-tags me-1"></i>Tags:</small>
                {''.join(tag_badges)}
            </div>'''

        # Generate screenshots HTML
        screenshots_html = ''
        if step_id in step_screenshots and step_screenshots[step_id]:
            screenshots = step_screenshots[step_id]
            screenshots_html = f'''
            <div class="mt-3">
                <h6><i class="bi bi-camera me-1"></i>Screenshots ({len(screenshots)})</h6>
                <div class="screenshot-grid">'''

            for screenshot in screenshots:
                screenshot_label = screenshot.get('label', screenshot['filename'])
                screenshot_type = screenshot.get('type', '')
                type_class = f"screenshot-{screenshot_type}" if screenshot_type else ""

                # Replace "after" screenshots with privacy message for steps with sensitive data
                if (screenshot_type == 'after' and
                    report_data.contains_sensitive_data):
                    screenshots_html += f'''
                    <div class="screenshot-item {type_class}">
                        <div class="screenshot-label small fw-bold mb-1">After Execution</div>
                        <div class="screenshot-placeholder d-flex flex-column align-items-center justify-content-center bg-light rounded border"
                             style="height: 200px; min-height: 150px;">
                            <i class="bi bi-shield-lock fs-1 text-muted mb-2"></i>
                            <p class="text-muted mb-1 fw-bold">Screenshot Hidden for Privacy</p>
                            <small class="text-muted text-center">Contains sensitive information</small>
                        </div>
                        <div class="small text-muted mt-1">Privacy protected</div>
                        <div class="small text-muted">(Sensitive data detected)</div>
                    </div>'''
                    continue

                # Replace "before" screenshots with privacy message if previous step had sensitive data
                if (screenshot_type == 'before' and hide_before_screenshot):
                    screenshots_html += f'''
                    <div class="screenshot-item {type_class}">
                        <div class="screenshot-label small fw-bold mb-1">Before Execution</div>
                        <div class="screenshot-placeholder d-flex flex-column align-items-center justify-content-center bg-light rounded border"
                             style="height: 200px; min-height: 150px;">
                            <i class="bi bi-shield-lock fs-1 text-muted mb-2"></i>
                            <p class="text-muted mb-1 fw-bold">Screenshot Hidden for Privacy</p>
                            <small class="text-muted text-center">Previous step contained sensitive information</small>
                        </div>
                        <div class="small text-muted mt-1">Privacy protected</div>
                        <div class="small text-muted">(Previous step was secure)</div>
                    </div>'''
                    continue

                screenshots_html += f'''
                    <div class="screenshot-item {type_class}">
                        <div class="screenshot-label small fw-bold mb-1">{screenshot_label}</div>
                        <img src="{screenshot['base64']}"
                             alt="Screenshot {screenshot['filename']}"
                             onclick="showFullscreen(this.src)">
                        <div class="small text-muted mt-1">{screenshot['filename']}</div>
                        <div class="small text-muted">({screenshot['size']:,} bytes)</div>
                    </div>'''

            screenshots_html += '''
                </div>
            </div>'''

        # Format execution result - use compact format for timeline
        result_html = self._format_execution_result(report_data.execution_result.result, compact=True)

        # Format error if present
        error_html = ''
        if error:
            error_html = f'''
            <div class="error-details">
                <h6 class="text-danger mb-2">
                    <i class="bi bi-exclamation-triangle me-1"></i>
                    Error Details
                </h6>
                <p class="mb-0">{html.escape(str(error))}</p>
            </div>'''

        return f'''
        <div class="timeline-item {status_class}">
            <div class="card step-card {status_class}">
                <div class="card-body">
                    <div class="step-header">
                        <h5 class="card-title mb-0">{step_id}</h5>
                        <span class="status-badge {status_badge_class}">{status_text}</span>
                        <span class="status-badge duration-badge">{execution_time:.2f}s</span>
                        {new_precond_badge}
                    </div>
                    <p class="card-text text-muted">{description}</p>
                    {tags_html}

                    {screenshots_html}

                    <div class="mt-2">
                        <div class="text-muted small mb-1">
                            <i class="bi bi-info-circle me-1"></i>Result:
                        </div>
                        <div class="result-compact">
                            {result_html}
                        </div>
                    </div>

                    {error_html}
                </div>
            </div>
        </div>'''

    def _generate_timeline_item_fallback(self, result: StepExecutionResult, index: int, step_screenshots: Dict[str, List[Dict]], hide_before_screenshot: bool = False) -> str:
        """Generate a timeline item using only execution result (fallback when step metadata is not available)."""
        # Use execution result directly (no step metadata available)
        step_id = result.step_id
        success = result.success
        description = result.description
        execution_time = result.execution_time
        error = result.error
        new_precond_badge = self._new_precondition_badge(result)

        status_class = 'success' if success else 'failed'
        status_badge_class = 'status-success' if success else 'status-failed'
        status_text = 'SUCCESS' if success else 'FAILED'

        # No tags in fallback mode
        tags_html = '<div class="mt-2"><small class="text-muted"><i class="bi bi-exclamation-triangle me-1"></i>Step metadata not available</small></div>'

        # Generate screenshots HTML (simplified for fallback)
        screenshots_html = ''
        if step_id in step_screenshots and step_screenshots[step_id]:
            screenshots = step_screenshots[step_id]
            screenshots_html = f'<div class="mt-3"><h6><i class="bi bi-camera me-1"></i>Screenshots ({len(screenshots)})</h6></div>'

        # Format execution result - use compact format for timeline
        result_html = self._format_execution_result(result.result, compact=True)

        # Format error if present
        error_html = ''
        if error:
            error_html = f'''
            <div class="error-details">
                <h6 class="text-danger mb-2">
                    <i class="bi bi-exclamation-triangle me-1"></i>
                    Error Details
                </h6>
                <p class="mb-0">{html.escape(str(error))}</p>
            </div>'''

        return f'''
        <div class="timeline-item {status_class}">
            <div class="card step-card {status_class}">
                <div class="card-body">
                    <div class="step-header">
                        <h5 class="card-title mb-0">{step_id}</h5>
                        <span class="status-badge {status_badge_class}">{status_text}</span>
                        <span class="status-badge duration-badge">{execution_time:.2f}s</span>
                        {new_precond_badge}
                    </div>
                    <p class="card-text text-muted">{description}</p>
                    {tags_html}

                    {screenshots_html}

                    <div class="mt-2">
                        <div class="text-muted small mb-1">
                            <i class="bi bi-info-circle me-1"></i>Result:
                        </div>
                        <div class="result-compact">
                            {result_html}
                        </div>
                    </div>

                    {error_html}
                </div>
            </div>
        </div>'''

    def _generate_error_summary(self, errors: List[Dict]) -> str:
        """Generate error summary section if there are errors."""
        if not errors:
            return ''

        error_rows = []
        for error in errors:
            error_rows.append(f'''
            <tr>
                <td>{error.get('step_id', 'Unknown')}</td>
                <td>{error.get('item_index', 'N/A')}</td>
                <td class="text-danger">{html.escape(str(error.get('error', 'Unknown error')))}</td>
            </tr>''')

        return f'''
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Error Summary ({len(errors)} errors)
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Step ID</th>
                                        <th>Item Index</th>
                                        <th>Error Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {''.join(error_rows)}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>'''

    def _generate_header_section(self, plan: ExecutablePlan, execution_result: PlanExecutionResult, total_steps: int, executed_steps: int, total_duration: float) -> str:
        """Generate the header section of the report."""
        from vscuse_v2 import __version__
        return f'''
        <div class="row mb-4">
            <div class="col-12">
                <div class="summary-card p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h1 class="h2 mb-0">
                                <i class="bi bi-clipboard-check me-2"></i>
                                VSC-Use Test Report
                                <span class="badge bg-secondary fs-6 ms-2 align-middle">v{__version__}</span>
                            </h1>
                        </div>
                        <button class="btn btn-light btn-lg" onclick="openReplayModal()">
                            <i class="bi bi-play-circle me-2"></i>
                            Replay Execution
                        </button>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="h4 mb-2">{plan.plan_metadata.name}</h3>
                            <div class="mt-2">
                                <small class="opacity-75">
                                    Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} |
                                    Plan: {plan.plan_metadata.plan_id} |
                                    Execution: {execution_result.execution_id}
                                </small>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="d-flex justify-content-end gap-2">
                                <span class="badge bg-light text-dark fs-6 px-3 py-2">
                                    <i class="bi bi-list-ol me-1"></i>
                                    {total_steps} Total
                                </span>
                                <span class="badge bg-info text-white fs-6 px-3 py-2">
                                    <i class="bi bi-play me-1"></i>
                                    {executed_steps} Executed
                                </span>
                                <span class="badge bg-light text-dark fs-6 px-3 py-2">
                                    <i class="bi bi-clock me-1"></i>
                                    {total_duration:.1f}s
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>'''

    def _new_precondition_badge(self, result: StepExecutionResult) -> str:
        """Badge marking a step that used the new lenient OCR-retargeted precondition."""
        if not getattr(result, 'new_precondition_applied', False):
            return ''
        label = 'new precondition'
        title = (
            'This step used the new lenient precondition for OCR-retargeted coordinate '
            'clicks: the precondition only waits for screen stability and the click target '
            'is re-resolved from the live screenshot downstream (coordinate drift tolerated).'
        )
        if getattr(result, 'ocr_retargeted', False):
            label += ' \u00b7 OCR re-targeted'
            detail = getattr(result, 'ocr_retarget_detail', None)
            if detail:
                title += f' OCR moved the click target: {detail}'
        return (
            f'<span class="status-badge new-precond-badge" title="{html.escape(title)}">'
            f'<i class="bi bi-stars me-1"></i>{html.escape(label)}</span>'
        )

    def _generate_metrics_section(self, total_steps: int, executed_steps: int, successful_steps: int, failed_steps: int, success_rate: float, new_precond_count: int = 0, ocr_retarget_count: int = 0) -> str:
        """Generate the metrics section of the report."""
        return f'''
        <div class="row mb-4">
            <div class="col-md-2 col-6">
                <div class="metric-card">
                    <div class="metric-value text-primary">{total_steps}</div>
                    <div class="metric-label">Total Steps</div>
                </div>
            </div>
            <div class="col-md-2 col-6">
                <div class="metric-card">
                    <div class="metric-value text-info">{executed_steps}</div>
                    <div class="metric-label">Executed</div>
                </div>
            </div>
            <div class="col-md-2 col-6">
                <div class="metric-card">
                    <div class="metric-value text-success">{successful_steps}</div>
                    <div class="metric-label">Successful</div>
                </div>
            </div>
            <div class="col-md-2 col-6">
                <div class="metric-card">
                    <div class="metric-value text-danger">{failed_steps}</div>
                    <div class="metric-label">Failed</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="metric-card">
                    <div class="metric-value text-warning">{success_rate:.1f}%</div>
                    <div class="metric-label">Success Rate</div>
                </div>
            </div>
            <div class="col-md-2 col-6">
                <div class="metric-card">
                    <div class="metric-value new-precond-value">{new_precond_count}</div>
                    <div class="metric-label">New Precondition</div>
                    <div class="metric-subnote">{ocr_retarget_count} OCR re-targeted</div>
                </div>
            </div>
        </div>'''

    def _generate_plan_info_section(self, plan: ExecutablePlan, plan_path: Optional[Path]) -> str:
        """Generate the plan information section."""
        # Generate second row for plan file and tags
        second_row_html = ''
        if plan_path or plan.plan_metadata.tags:
            plan_file_content = f'<strong>Plan File:</strong> {plan_path}' if plan_path else ''

            # Format tags as badges for better visual presentation
            tags_content = ''
            if plan.plan_metadata.tags:
                tag_badges = ' '.join([f'<span class="badge bg-primary me-1">{tag}</span>' for tag in plan.plan_metadata.tags])
                tags_content = f'<strong>Plan Tags:</strong> {tag_badges}'

            second_row_html = f'''
                        <div class="row mt-2">
                            <div class="col-md-6">
                                {plan_file_content}
                            </div>
                            <div class="col-md-6">
                                {tags_content}
                            </div>
                        </div>'''

        # Generate third row for owner, workitem, and other fields
        third_row_html = ''
        # Access description fields - handle both PlanDescription object and None
        description = plan.plan_metadata.description
        owner = description.owner if description else ''
        workitem = description.workitem if description else ''
        other = description.other if description else ''

        if owner or workitem:
            owner_content = f'<strong>Owner:</strong> {owner}' if owner else '<strong>Owner:</strong>'
            workitem_content = f'<strong>Work Item:</strong> {workitem}' if workitem else '<strong>Work Item:</strong>'

            third_row_html = f'''
                        <div class="row mt-2">
                            <div class="col-md-6">
                                {owner_content}
                            </div>
                            <div class="col-md-6">
                                {workitem_content}
                            </div>
                        </div>'''

        # Generate fourth row for other field if present
        fourth_row_html = ''
        if other:
            fourth_row_html = f'''
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <strong>Other:</strong> {other}
                            </div>
                        </div>'''

        return f'''
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-info-circle me-2"></i>
                            Plan Information
                        </h5>
                    </div>
                    <div class="card-body plan-info">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>Plan ID:</strong> {plan.plan_metadata.plan_id}
                            </div>
                            <div class="col-md-6">
                                <strong>Version:</strong> {getattr(plan.plan_metadata, 'version', 'N/A')}
                            </div>
                        </div>{second_row_html}{third_row_html}{fourth_row_html}
                    </div>
                </div>
            </div>
        </div>'''

    def _generate_details_section(self, execution_result: PlanExecutionResult, total_steps: int, executed_steps: int, total_duration: float) -> str:
        """Generate the execution details section."""
        return f'''
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-info-square me-2"></i>
                            Execution Details
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>Start Time:</strong> {execution_result.start_time}<br>
                                <strong>End Time:</strong> {execution_result.end_time or 'N/A'}<br>
                                <strong>Total Duration:</strong> {total_duration:.2f}s<br>
                                <strong>Average Step Time:</strong> {(total_duration / executed_steps if executed_steps > 0 else 0):.2f}s
                            </div>
                            <div class="col-md-6">
                                <strong>Total Steps:</strong> {total_steps}<br>
                                <strong>Executed Steps:</strong> {executed_steps}<br>
                                <strong>Executed Range:</strong> {execution_result.executed_range}<br>
                                <strong>Interrupted:</strong> {'Yes' if execution_result.interrupted else 'No'}<br>
                                <strong>Exception:</strong> {execution_result.exception or 'None'}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>'''

    def _generate_css_styles(self) -> str:
        """Generate CSS styles for the report."""
        return '''
    <style>
        .step-card {
            transition: all 0.2s ease;
            margin-bottom: 1rem;
            border-left: 4px solid transparent;
        }
        .step-card.success { border-left-color: #28a745; }
        .step-card.failed { border-left-color: #dc3545; }
        .step-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .replay-modal {
            position: fixed;
            inset: 0;
            z-index: 1050;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 0, 0, 0.75);
        }
        .replay-modal-content {
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            max-width: 95vw;
            width: 95%;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .replay-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1.5rem;
            border-bottom: 1px solid #dee2e6;
            background: white;
        }
        .replay-content {
            flex: 1 1 auto;
            min-height: 0;
            overflow-y: overlay;
            overflow-x: hidden;
            padding: 1.5rem;
            background: #f8f9fa;
        }

        /* Fallback for browsers that don't support overlay */
        @supports not (overflow-y: overlay) {
            .replay-content {
                overflow-y: auto;
            }
        }

        /* Firefox - thin scrollbar that doesn't take up space */
        .replay-content {
            scrollbar-width: thin;
            scrollbar-color: rgba(136, 136, 136, 0.5) transparent;
        }

        /* Webkit browsers - overlay scrollbar */
        .replay-content::-webkit-scrollbar {
            width: 6px;
        }
        .replay-content::-webkit-scrollbar-track {
            background: transparent;
            margin: 4px;
        }
        .replay-content::-webkit-scrollbar-thumb {
            background: rgba(136, 136, 136, 0.3);
            border-radius: 3px;
        }
        .replay-content::-webkit-scrollbar-thumb:hover {
            background: rgba(85, 85, 85, 0.6);
        }
        .replay-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem 1.5rem;
            border-top: 1px solid #dee2e6;
            background: white;
        }
        .btn-close-replay {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: #6c757d;
            cursor: pointer;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: all 0.2s;
        }
        .btn-close-replay:hover {
            background: #e9ecef;
            color: #000;
        }
        .replay-step-content {
            max-width: 100%;
        }
        .replay-two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            align-items: start;
        }
        @media (max-width: 992px) {
            .replay-two-column {
                grid-template-columns: 1fr;
            }
        }
        .replay-column {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .cursor-pointer {
            cursor: pointer;
        }
        .bg-purple {
            background-color: #6f42c1 !important;
            color: white !important;
        }
        .crosshair-overlay {
            position: absolute;
            pointer-events: none;
            transform: translate(-50%, -50%);
        }
        .crosshair-v {
            position: absolute;
            width: 3px;
            height: 24px;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #dc3545;
            box-shadow: 0 0 4px rgba(255, 255, 255, 0.9);
        }
        .crosshair-h {
            position: absolute;
            width: 24px;
            height: 3px;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #dc3545;
            box-shadow: 0 0 4px rgba(255, 255, 255, 0.9);
        }
        .crosshair-center {
            position: absolute;
            width: 8px;
            height: 8px;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #dc3545;
            border-radius: 50%;
            box-shadow: 0 0 4px rgba(255, 255, 255, 0.9);
        }
        .screenshot-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 10px;
        }
        .screenshot-item {
            text-align: center;
            background: #f8f9fa;
            border-radius: 8px;
            padding: 10px;
        }
        .screenshot-item img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
            cursor: pointer;
            transition: transform 0.2s ease;
            max-height: 150px;
        }
        .screenshot-item img:hover { transform: scale(1.05); }
        .screenshot-before { border-left: 3px solid #ffc107; }
        .screenshot-after { border-left: 3px solid #28a745; }
        .screenshot-expected { border-left: 3px solid #6f42c1; }
        .screenshot-label {
            color: #495057;
            text-align: center;
            background: rgba(0,0,0,0.05);
            padding: 2px 8px;
            border-radius: 4px;
        }
        .step-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }
        .status-badge {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.25rem 0.5rem;
            border-radius: 0.375rem;
        }
        .status-success {
            background-color: #d1f2eb;
            color: #0d7d56;
        }
        .status-failed {
            background-color: #f8d7da;
            color: #721c24;
        }
        .duration-badge {
            background-color: #e7f3ff;
            color: #0969da;
        }
        .new-precond-badge {
            background-color: #f3e8ff;
            color: #6f42c1;
        }
        .new-precond-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: #6f42c1;
        }
        .metric-subnote {
            font-size: 0.75rem;
            color: #6c757d;
            margin-top: 0.25rem;
        }
        .modal-fullscreen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.9);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            cursor: pointer;
        }
        .modal-fullscreen.show { display: flex; }
        .modal-fullscreen img {
            max-width: 95vw;
            max-height: 95vh;
            object-fit: contain;
        }
        .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
        }
        .metric-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 8px;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .metric-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        .metric-label {
            font-size: 0.9rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .plan-info {
            background: #f8f9fa;
            border-left: 4px solid #0969da;
            border-radius: 0 8px 8px 0;
        }
        .execution-timeline {
            position: relative;
            padding-left: 2rem;
        }
        .execution-timeline::before {
            content: '';
            position: absolute;
            left: 1rem;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #dee2e6;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 2rem;
        }

        .group-section {
            border: 2px solid #4a90d9;
            border-radius: 10px;
            margin-bottom: 1.25rem;
            background: #ffffff;
        }

        .group-section-header {
            padding: 0.65rem 0.85rem;
            border-bottom: 1px solid #b8d4f0;
            background: #e8f0fb;
            border-radius: 8px 8px 0 0;
            cursor: pointer;
            user-select: none;
            transition: background 0.15s;
        }
        .group-section-header:hover {
            background: #d6e6f8;
        }

        .group-chevron {
            transition: transform 0.25s ease;
            font-size: 0.85rem;
            color: #4a90d9;
        }
        .group-section.collapsed .group-chevron {
            transform: rotate(-90deg);
        }
        .group-section.collapsed .group-steps {
            display: none;
        }

        .group-title-label {
            font-size: 0.92rem;
            font-weight: 600;
            color: #2f3a48;
        }

        .group-name-copy {
            font-size: 0.92rem;
            font-weight: 600;
            color: #1a6fcc;
            cursor: pointer;
            border-bottom: 1px dashed #1a6fcc;
            transition: color 0.15s;
        }
        .group-name-copy:hover {
            color: #0d4a8a;
        }

        .group-steps {
            padding: 0.85rem;
        }

        .copy-toast {
            position: fixed;
            bottom: 60px;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: #fff;
            padding: 8px 20px;
            border-radius: 6px;
            font-size: 0.85rem;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s;
            pointer-events: none;
        }
        .copy-toast.show {
            opacity: 1;
        }

        .error-details {
            background: #f8d7da;
            color: #721c24;
            padding: 0.75rem;
            border-radius: 0.375rem;
            margin-top: 0.5rem;
            border: 1px solid #f5c6cb;
        }
        .result-details {
            background: #f8f9fa;
            padding: 0.75rem;
            border-radius: 0.375rem;
            margin-top: 0.5rem;
            border: 1px solid #dee2e6;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: pre-wrap;
        }
        .result-compact {
            font-size: 0.9rem;
            color: #495057;
            line-height: 1.5;
            padding: 0.5rem;
            background: #f8f9fa;
            border-radius: 0.25rem;
            border-left: 3px solid #007bff;
        }
        .text-result-wrapped {
            font-family: 'Courier New', monospace;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-wrap: break-word;
            color: #495057;
            line-height: 1.5;
            margin: 0;
            padding: 0;
            background: transparent;
            border: none;
        }
        .json-result-wrapped {
            font-family: 'Courier New', monospace;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-wrap: break-word;
            color: #495057;
            line-height: 1.5;
            margin: 0;
            padding: 0;
            background: transparent;
            border: none;
        }
        .execution-result-card {
            background: #ffffff;
            padding: 1rem;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 4px solid #007bff;
        }
        .execution-result-card .badge {
            font-size: 0.85rem;
            padding: 0.4rem 0.7rem;
            font-weight: 500;
        }
        .text-result, .json-result {
            margin: 0;
        }
        .text-result pre, .json-result pre {
            margin-bottom: 0;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 0.9rem;
            line-height: 1.4;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
    </style>'''

    def _generate_replay_modal(self, execution_result: PlanExecutionResult, step_lookup: Dict, step_screenshots: Dict[str, List[Dict]]) -> str:
        """Generate the replay modal HTML."""
        return '''
    <!-- Replay Modal -->
    <div id="replayModal" class="replay-modal" style="display: none;">
        <div class="replay-modal-content">
            <!-- Header -->
            <div class="replay-header">
                <div class="d-flex align-items-center gap-3">
                    <h2 class="h4 mb-0">
                        <i class="bi bi-play-circle me-2"></i>
                        Execution Replay
                    </h2>
                    <span id="replayTotalTime" class="text-muted"></span>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span id="replayStepCounter" class="text-muted"></span>
                    <button class="btn-close-replay" onclick="closeReplayModal()" title="Close">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>
            </div>

            <!-- Content -->
            <div class="replay-content" id="replayContent">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>

            <!-- Navigation Footer -->
            <div class="replay-footer">
                <button id="replayPrevBtn" class="btn btn-secondary" onclick="previousStep()">
                    <i class="bi bi-arrow-left me-2"></i>
                    Previous
                </button>
                <div class="text-muted small">
                    Use arrow keys to navigate
                </div>
                <button id="replayNextBtn" class="btn btn-secondary" onclick="nextStep()">
                    Next
                    <i class="bi bi-arrow-right ms-2"></i>
                </button>
            </div>
        </div>
    </div>'''

    def _generate_modal_and_scripts(self, execution_result: PlanExecutionResult, step_lookup: Dict, step_screenshots: Dict[str, List[Dict]], plan: ExecutablePlan = None, plan_path: Optional[Path] = None) -> str:
        """Generate the modal and JavaScript for the report."""
        # Prepare step data for JavaScript
        steps_data = []
        for i, step_result in enumerate(execution_result.step_execution_results):
            step = step_lookup.get(step_result.step_id)
            screenshots = step_screenshots.get(step_result.step_id, [])

            # Check if previous step had sensitive data - if so, mark this step to hide "before" screenshot
            hide_before_screenshot = False
            if i > 0:
                prev_step_result = execution_result.step_execution_results[i - 1]
                if prev_step_result.contains_sensitive_data:
                    hide_before_screenshot = True

            # Serialize parameters properly
            parameters = {}
            if step and step.parameters:
                parameters = self._serialize_for_json(step.parameters)

            step_data = {
                'step_id': step_result.step_id,
                'description': step_result.description,
                'success': step_result.success,
                'execution_time': step_result.execution_time,
                'error': step_result.error,
                'result': self._format_execution_result(step_result.result, compact=False),
                'tags': step.tags if step else [],
                'tool': step.tool if step else None,
                'parameters': parameters,
                'screenshots': screenshots,
                'hide_before_screenshot': hide_before_screenshot,  # Flag to hide "before" screenshot in replay
                'contains_sensitive_data': step_result.contains_sensitive_data,  # Also pass current step's sensitive flag
                'new_precondition_applied': getattr(step_result, 'new_precondition_applied', False),
                'ocr_retargeted': getattr(step_result, 'ocr_retargeted', False),
                'ocr_retarget_detail': getattr(step_result, 'ocr_retarget_detail', None)
            }
            steps_data.append(step_data)

        import json
        steps_json = json.dumps(steps_data).replace('<', r'\u003c')
        total_time = sum(r.execution_time for r in execution_result.step_execution_results)

        # Embed plan data for screenshot update feature
        # Read the original plan file from disk to preserve the export format (with screenshots section)
        plan_data_json = 'null'
        plan_path_str = 'null'
        group_plans_json = '{}'
        if plan_path:
            try:
                with open(plan_path, 'r', encoding='utf-8') as pf:
                    original_plan_data = json.load(pf)
                plan_data_json = json.dumps(original_plan_data, default=str)
                plan_path_str = json.dumps(str(plan_path))

                # Load referenced group files for screenshot update feature
                group_plans = {}
                execution_order = original_plan_data.get('plan_metadata', {}).get('execution_order', [])
                group_refs = [item for item in execution_order if item.startswith('plan_')]
                if group_refs:
                    # Search for group files in the groups directory (sibling of plan's parent)
                    groups_dir = plan_path.parent.parent / 'groups'
                    if groups_dir.exists():
                        for group_file in groups_dir.glob('*.json'):
                            try:
                                with open(group_file, 'r', encoding='utf-8') as gf:
                                    group_data = json.load(gf)
                                group_id = group_data.get('plan_metadata', {}).get('plan_id')
                                if group_id and group_id in group_refs:
                                    group_plans[group_id] = {
                                        'data': group_data,
                                        'path': str(group_file)
                                    }
                            except Exception as e:
                                logger.warning(f"Failed to load group file {group_file}: {e}")
                group_plans_json = json.dumps(group_plans, default=str)
            except Exception as e:
                logger.warning(f"Failed to embed plan data for screenshot update feature: {e}")
                plan_data_json = 'null'
                plan_path_str = 'null'
                group_plans_json = '{}'

        return f'''
    <!-- Fullscreen Modal for Screenshots -->
    <div class="modal-fullscreen" id="screenshotModal" onclick="closeModal()">
        <img id="modalImage" alt="Fullscreen Screenshot">
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Step data for replay
        const stepsData = {steps_json};
        const totalExecutionTime = {total_time:.2f};
        let currentStepIndex = 0;

        function escapeHtml(s) {{
            if (s === null || s === undefined) return '';
            return String(s)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }}

        function openReplayModal() {{
            document.getElementById('replayModal').style.display = 'flex';
            currentStepIndex = 0;
            renderReplayStep();
        }}

        function closeReplayModal() {{
            document.getElementById('replayModal').style.display = 'none';
        }}

        function previousStep() {{
            if (currentStepIndex > 0) {{
                currentStepIndex--;
                renderReplayStep();
            }}
        }}

        function nextStep() {{
            if (currentStepIndex < stepsData.length - 1) {{
                currentStepIndex++;
                renderReplayStep();
            }}
        }}

        function renderReplayStep() {{
            const step = stepsData[currentStepIndex];
            const content = document.getElementById('replayContent');

            // Update counter and total time
            document.getElementById('replayStepCounter').textContent =
                `Step ${{currentStepIndex + 1}} of ${{stepsData.length}}`;
            document.getElementById('replayTotalTime').textContent =
                `(${{totalExecutionTime.toFixed(2)}}s)`;

            // Update navigation buttons
            document.getElementById('replayPrevBtn').disabled = currentStepIndex === 0;
            document.getElementById('replayNextBtn').disabled = currentStepIndex === stepsData.length - 1;

            // Generate tags and parameters HTML (combined in one line)
            let tagsAndParamsHtml = '';
            const tagBadges = [];

            // Add tags
            if (step.tags && step.tags.length > 0) {{
                step.tags.forEach(tag => {{
                    tagBadges.push(`<span class="badge bg-success"><i class="bi bi-tag me-1"></i>${{tag}}</span>`);
                }});
            }}

            // Add parameters
            if (step.parameters && Object.keys(step.parameters).length > 0) {{
                const paramItems = Object.entries(step.parameters)
                    .filter(([_, value]) => value !== null && value !== undefined)
                    .map(([key, value]) => `${{key}}=${{value}}`)
                    .join(', ');
                if (paramItems) {{
                    tagBadges.push(`<span class="badge bg-purple"><i class="bi bi-gear me-1"></i>${{paramItems}}</span>`);
                }}
            }}

            if (tagBadges.length > 0) {{
                tagsAndParamsHtml = '<div class="d-flex gap-2 flex-wrap mb-2">' + tagBadges.join('') + '</div>';
            }}

            // Generate screenshots HTML
            let screenshotsHtml = '';
            if (step.screenshots && step.screenshots.length > 0) {{
                const expectedScreenshot = step.screenshots.find(s => s.type === 'expected');
                const beforeScreenshot = step.screenshots.find(s => s.type === 'before');

                // Show expected screenshot if available
                if (expectedScreenshot) {{
                    screenshotsHtml += `
                        <div class="bg-light rounded p-3 mb-3">
                            <div class="small fw-bold mb-2"><i class="bi bi-image me-1"></i>Expected Screenshot</div>
                            <img src="${{expectedScreenshot.base64}}"
                                 class="rounded border cursor-pointer"
                                 onclick="showFullscreen('${{expectedScreenshot.base64}}')"
                                 style="display: block; max-width: 100%; max-height: 40vh; width: auto; height: auto; object-fit: contain;">
                        </div>`;
                }}

                // Hide "before" screenshot if previous step had sensitive data OR current step has sensitive data (for "after" screenshots)
                if (beforeScreenshot && !step.hide_before_screenshot) {{
                    // Check if step has x,y coordinates for crosshair (must be valid numbers, not null/undefined/0)
                    const hasCoords = step.parameters &&
                                    typeof step.parameters.x === 'number' &&
                                    typeof step.parameters.y === 'number' &&
                                    step.parameters.x !== null &&
                                    step.parameters.y !== null;

                    let crosshairHtml = '';
                    let onloadHandler = '';

                    if (hasCoords) {{
                        crosshairHtml = `
                            <div class="crosshair-overlay" style="display: none;">
                                <div class="crosshair-v"></div>
                                <div class="crosshair-h"></div>
                                <div class="crosshair-center"></div>
                            </div>`;
                        onloadHandler = `onload="positionCrosshair(this, ${{step.parameters.x}}, ${{step.parameters.y}}, 'crosshair-${{currentStepIndex}}')"`;
                    }}

                    screenshotsHtml += `
                        <div class="bg-light rounded p-3 mb-3">
                            <div style="position: relative; display: inline-block; max-width: 100%;">
                                <img src="${{beforeScreenshot.base64}}"
                                     class="rounded border cursor-pointer"
                                     onclick="showFullscreen('${{beforeScreenshot.base64}}')"
                                     ${{onloadHandler}}
                                     style="display: block; max-width: 100%; max-height: 60vh; width: auto; height: auto; object-fit: contain;">
                                ${{crosshairHtml}}
                            </div>
                        </div>`;
                }} else if (beforeScreenshot && step.hide_before_screenshot) {{
                    // Show privacy placeholder when previous step had sensitive data
                    screenshotsHtml += `
                        <div class="bg-light rounded p-3 mb-3">
                            <div class="screenshot-placeholder d-flex flex-column align-items-center justify-content-center bg-light rounded border"
                                 style="height: 300px; min-height: 200px;">
                                <i class="bi bi-shield-lock fs-1 text-muted mb-3"></i>
                                <p class="text-muted mb-1 fw-bold">Screenshot Hidden for Privacy</p>
                                <small class="text-muted text-center">Previous step contained sensitive information</small>
                            </div>
                        </div>`;
                }}
            }}

            // Generate error HTML
            let errorHtml = '';
            if (step.error) {{
                errorHtml = `
                    <div class="alert alert-danger mb-3">
                        <h6 class="alert-heading">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Error
                        </h6>
                        <pre class="mb-0 small">${{escapeHtml(step.error)}}</pre>
                    </div>`;
            }}

            // Generate update screenshot button for failed steps with before screenshots
            let updateBtnHtml = '';
            if (!step.success && originalPlanData) {{
                const beforeScreenshot = step.screenshots ? step.screenshots.find(s => s.type === 'before') : null;
                if (beforeScreenshot) {{
                    const isAlreadyUpdated = screenshotUpdates[step.step_id];
                    if (isAlreadyUpdated) {{
                        updateBtnHtml = `
                            <div class="mt-3">
                                <button id="updateBtn-${{currentStepIndex}}" class="btn btn-success btn-sm" disabled>
                                    <i class="bi bi-check-lg me-1"></i> Updated
                                </button>
                            </div>`;
                    }} else {{
                        updateBtnHtml = `
                            <div class="mt-3">
                                <button id="updateBtn-${{currentStepIndex}}" class="btn btn-warning btn-sm" onclick="updateScreenshotForStep('${{step.step_id}}')">
                                    <i class="bi bi-arrow-repeat me-1"></i> Use Before Screenshot as Expected
                                </button>
                                <div class="small text-muted mt-1">Replace the expected screenshot with the before-execution screenshot in the plan JSON.</div>
                            </div>`;
                    }}
                }}
            }}

            // Render content
            const statusClass = step.success ? 'success' : 'danger';
            const statusIcon = step.success ? 'check-circle-fill' : 'x-circle-fill';
            const statusText = step.success ? 'Success' : 'Failed';

            content.innerHTML = `
                <div class="replay-step-content">
                    <!-- Two Column Layout -->
                    <div class="replay-two-column">
                        <!-- Left Column: Step Info + Execution Result -->
                        <div class="replay-column">
                            <div class="card border-${{statusClass}}">
                                <div class="card-body">
                                    <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
                                        <span class="badge bg-secondary">Step ${{currentStepIndex + 1}}</span>
                                        <span class="badge bg-${{statusClass}}">
                                            <i class="bi bi-${{statusIcon}} me-1"></i>
                                            ${{statusText}}
                                        </span>
                                        <span class="badge bg-info">
                                            <i class="bi bi-clock me-1"></i>
                                            ${{step.execution_time.toFixed(2)}}s
                                        </span>
                                        ${{step.tool ? `<span class="badge bg-primary"><i class="bi bi-tools me-1"></i>${{step.tool}}</span>` : ''}}
                                        ${{tagBadges.join('')}}
                                    </div>
                                    <p class="mb-0">${{step.description}}</p>
                                </div>
                            </div>
                            ${{errorHtml}}
                            <div class="card">
                                <div class="card-body">
                                    <h6 class="text-muted mb-3">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Execution Result
                                    </h6>
                                    <div class="result-content">
                                        ${{step.result}}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Right Column: Screenshot -->
                        <div class="replay-column">
                            ${{screenshotsHtml}}
                            ${{updateBtnHtml}}
                        </div>
                    </div>
                </div>
            `;
        }}

        function positionCrosshair(img, x, y, crosshairId) {{
            // Simple percentage-based positioning - works regardless of image scaling
            if (!img || x === undefined || y === undefined) return;

            const crosshair = img.nextElementSibling;
            if (!crosshair || !crosshair.classList.contains('crosshair-overlay')) return;

            // Calculate percentage position
            const percentX = (x / img.naturalWidth) * 100;
            const percentY = (y / img.naturalHeight) * 100;

            // Position using percentages - scales automatically with image
            crosshair.style.left = `${{percentX}}%`;
            crosshair.style.top = `${{percentY}}%`;
            crosshair.style.display = 'block';
        }}

        function showFullscreen(imageSrc) {{
            const modal = document.getElementById('screenshotModal');
            const modalImg = document.getElementById('modalImage');
            modalImg.src = imageSrc;
            modal.classList.add('show');
        }}

        function closeModal() {{
            const modal = document.getElementById('screenshotModal');
            modal.classList.remove('show');
        }}

        // Keyboard navigation
        document.addEventListener('keydown', function(event) {{
            const replayModal = document.getElementById('replayModal');
            if (replayModal.style.display === 'flex') {{
                if (event.key === 'ArrowLeft') {{
                    previousStep();
                }} else if (event.key === 'ArrowRight') {{
                    nextStep();
                }} else if (event.key === 'Escape') {{
                    closeReplayModal();
                }}
            }} else if (event.key === 'Escape') {{
                closeModal();
            }}
        }});

        // Group collapse/expand toggle
        function toggleGroupSteps(header) {{
            const section = header.closest('.group-section');
            if (section) section.classList.toggle('collapsed');
        }}

        // Copy group file path to clipboard
        function copyGroupPath(el) {{
            const path = el.getAttribute('data-path');
            if (!path) return;
            navigator.clipboard.writeText(path).then(() => {{
                showCopyToast('Copied: ' + path);
            }}).catch(() => {{
                showCopyToast('Copy failed');
            }});
        }}

        function showCopyToast(msg) {{
            let toast = document.getElementById('copyToast');
            if (!toast) {{
                toast = document.createElement('div');
                toast.id = 'copyToast';
                toast.className = 'copy-toast';
                document.body.appendChild(toast);
            }}
            toast.textContent = msg;
            toast.classList.add('show');
            clearTimeout(toast._timer);
            toast._timer = setTimeout(() => toast.classList.remove('show'), 2000);
        }}

        // Auto-scroll to first failed step if any
        document.addEventListener('DOMContentLoaded', function() {{
            const failedSteps = document.querySelectorAll('.timeline-item.failed');
            if (failedSteps.length > 0) {{
                setTimeout(() => {{
                    failedSteps[0].scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                }}, 1000);
            }}
        }});

        // ===== Screenshot Update & Plan Download Feature =====
        const originalPlanData = {plan_data_json};
        const originalPlanPath = {plan_path_str};
        const groupPlansData = {group_plans_json};
        const screenshotUpdates = {{}}; // step_id -> new screenshot data URI
        let updateCount = 0;

        // Find which group a step belongs to (returns group plan_id or null for main plan steps)
        function findGroupForStep(stepId) {{
            if (!originalPlanData) return null;
            // Check if step exists in main plan's steps
            const mainStep = originalPlanData.steps && originalPlanData.steps.find(s => s.step_id === stepId);
            if (mainStep) return null; // Step is in the main plan

            // Check group plans
            for (const [groupId, groupInfo] of Object.entries(groupPlansData)) {{
                const groupData = groupInfo.data;
                if (groupData && groupData.steps) {{
                    const groupStep = groupData.steps.find(s => s.step_id === stepId);
                    if (groupStep) return groupId;
                }}
            }}
            return null;
        }}

        function updateScreenshotForStep(stepId) {{
            if (!originalPlanData) {{
                alert('Plan data not available for update.');
                return;
            }}
            const step = stepsData.find(s => s.step_id === stepId);
            if (!step) return;

            const beforeScreenshot = step.screenshots.find(s => s.type === 'before');
            if (!beforeScreenshot) {{
                alert('No before-execution screenshot available for this step.');
                return;
            }}

            screenshotUpdates[stepId] = beforeScreenshot.base64;
            updateCount++;

            // Show visual feedback
            const btn = document.getElementById('updateBtn-' + currentStepIndex);
            if (btn) {{
                btn.textContent = '\u2713 Updated';
                btn.classList.remove('btn-warning');
                btn.classList.add('btn-success');
                btn.disabled = true;
            }}

            // Show download button
            const downloadBar = document.getElementById('downloadBar');
            if (downloadBar) {{
                downloadBar.style.display = 'block';
                document.getElementById('updateCountBadge').textContent = Object.keys(screenshotUpdates).length + ' screenshot(s) updated';
            }}
        }}

        function _applyScreenshotUpdate(planObj, stepId, newScreenshotUri) {{
            const step = planObj.steps ? planObj.steps.find(s => s.step_id === stepId) : null;

            // Update in screenshots section
            if (planObj.screenshots) {{
                let screenshotKey = stepId;
                if (step && typeof step.screenshot === 'string' && !step.screenshot.startsWith('data:')) {{
                    screenshotKey = step.screenshot;
                }}
                planObj.screenshots[screenshotKey] = newScreenshotUri;
            }}

            // Also update inline screenshot in steps when it stores a data URI directly
            if (step && step.screenshot && step.screenshot.startsWith('data:')) {{
                step.screenshot = newScreenshotUri;
            }}
        }}

        function _triggerDownload(data, filename) {{
            const jsonStr = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonStr], {{ type: 'application/json' }});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }}

        function downloadUpdatedPlan() {{
            if (!originalPlanData || Object.keys(screenshotUpdates).length === 0) {{
                alert('No updates to apply.');
                return;
            }}

            // Classify updates by their target file (main plan vs group plans)
            const mainPlanUpdates = {{}};
            const groupUpdates = {{}}; // group_plan_id -> {{ stepId: newScreenshotUri }}
            for (const [stepId, newScreenshotUri] of Object.entries(screenshotUpdates)) {{
                const groupId = findGroupForStep(stepId);
                if (groupId) {{
                    if (!groupUpdates[groupId]) groupUpdates[groupId] = {{}};
                    groupUpdates[groupId][stepId] = newScreenshotUri;
                }} else {{
                    mainPlanUpdates[stepId] = newScreenshotUri;
                }}
            }}

            // Apply and download main plan updates (if any)
            if (Object.keys(mainPlanUpdates).length > 0) {{
                const updatedPlan = JSON.parse(JSON.stringify(originalPlanData));
                for (const [stepId, newScreenshotUri] of Object.entries(mainPlanUpdates)) {{
                    _applyScreenshotUpdate(updatedPlan, stepId, newScreenshotUri);
                }}
                let filename = 'updated_plan.json';
                if (originalPlanPath) {{
                    const parts = originalPlanPath.replace(/\\\\/g, '/').split('/');
                    filename = parts[parts.length - 1] || filename;
                }}
                _triggerDownload(updatedPlan, filename);
            }}

            // Apply and download group plan updates (if any)
            for (const [groupId, updates] of Object.entries(groupUpdates)) {{
                const groupInfo = groupPlansData[groupId];
                if (!groupInfo || !groupInfo.data) continue;
                const updatedGroup = JSON.parse(JSON.stringify(groupInfo.data));
                for (const [stepId, newScreenshotUri] of Object.entries(updates)) {{
                    _applyScreenshotUpdate(updatedGroup, stepId, newScreenshotUri);
                }}
                let filename = groupId + '.json';
                if (groupInfo.path) {{
                    const parts = groupInfo.path.replace(/\\\\/g, '/').split('/');
                    filename = parts[parts.length - 1] || filename;
                }}
                _triggerDownload(updatedGroup, filename);
            }}
        }}
    </script>

    <!-- Download Updated Plan Floating Bar -->
    <div id="downloadBar" style="display: none; position: fixed; bottom: 0; left: 0; right: 0; z-index: 1040; background: #198754; color: white; padding: 12px 24px; box-shadow: 0 -2px 10px rgba(0,0,0,0.2);">
        <div class="d-flex align-items-center justify-content-between">
            <div>
                <i class="bi bi-check-circle-fill me-2"></i>
                <span id="updateCountBadge">0 screenshot(s) updated</span>
                <span class="ms-2 small opacity-75">— Download the updated plan JSON and replace the original file to apply changes.</span>
            </div>
            <button class="btn btn-light btn-sm fw-bold" onclick="downloadUpdatedPlan()">
                <i class="bi bi-download me-1"></i> Download Updated Plan
            </button>
        </div>
    </div>'''
