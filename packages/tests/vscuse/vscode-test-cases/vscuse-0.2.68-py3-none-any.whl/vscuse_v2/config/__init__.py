"""
Configuration Management for VSC-Use

Provides centralized configuration management with layered overrides:
User Config File → Environment Variables → Default Values
"""

from .config_manager import ConfigManager, ConfigurationError, VSCUseConfig, get_azure_openai_config, get_azure_vision_config, get_config, get_docker_config, get_execution_config, get_logging_config, get_server_config, reset_config

__all__ = [
    "ConfigManager",
    "get_config",
    "reset_config",
    "get_azure_openai_config",
    "get_azure_vision_config",
    "get_docker_config",
    "get_server_config",
    "get_execution_config",
    "get_logging_config",
    "ConfigurationError",
    "VSCUseConfig"
]
