#!/usr/bin/env python3
"""
Validator

Unified validation logic for both preconditions and postconditions.
Supports multiple image hash algorithms (pHash, aHash, dHash, wHash) with tolerance-based matching for robust screenshot comparison.

Preconditions are checked before executing a step to ensure the UI is in the expected state.
Postconditions are validated after step execution to verify the expected outcome.
This is crucial for UI automation where the interface might need time to update after previous actions.

Supported condition format:
- dhash:x:y:size:tolerance:hash_value (unified format)
- phash:x:y:size:tolerance:hash_value (unified format)
- ahash:x:y:size:tolerance:hash_value (unified format)
- whash:x:y:size:tolerance:hash_value (unified format)

Where:
- size=0: Full image hash (tolerance-based matching)
- size>0: Spot-based hash at coordinates with specified size
- tolerance: Number of bits allowed to differ for successful match

The tolerance parameter allows for flexible validation where images can differ
by up to N bits and still pass validation, making the system more resilient
to minor timing differences, font rendering variations, and small UI changes.
"""

from enum import Enum
from pathlib import Path
from typing import List, Optional, Tuple, Union

import imagehash
from PIL import Image, ImageEnhance, ImageFilter
from pydantic import BaseModel, ConfigDict, Field, computed_field

from vscuse_v2.utils.logger import setup_logger

from .ocr_text import is_ocr_precondition

logger = setup_logger(__name__)


class HashType(str, Enum):
    """Supported hash algorithm types."""
    DHASH = "dhash"
    PHASH = "phash"
    AHASH = "ahash"
    WHASH = "whash"


class ConditionFormat(str, Enum):
    """Supported condition format types."""
    SPOT = "spot"
    TOLERANCE = "tolerance"


class ParsedCondition(BaseModel):
    """Parsed condition result with cleaner typing."""
    model_config = ConfigDict(extra='forbid')

    success: bool
    condition_format: Optional[ConditionFormat] = None
    hash_type: Optional[HashType] = None
    coordinates: Optional[Tuple[int, int]] = None  # (x, y) as tuple
    size: Optional[int] = Field(None, gt=0, le=200)  # Validation built-in
    tolerance: Optional[int] = Field(None, ge=0)
    expected_hash: Optional[str] = None
    condition_type: Optional[str] = None
    error: Optional[str] = None
    expected_format: Optional[str] = None
    supported_types: Optional[List[str]] = None


class ValidationResult(BaseModel):
    """Simplified validation result with computed fields."""
    model_config = ConfigDict(extra='forbid')

    # Core fields
    success: bool
    hash_type: Optional[HashType] = None
    condition_format: Optional[ConditionFormat] = None

    # Hash values
    expected_hash: Optional[str] = None
    current_hash: Optional[str] = None

    # Validation metrics
    hamming_distance: Optional[int] = Field(None, ge=0)
    tolerance: int = Field(default=0, ge=0)
    exact_match: bool = False

    # Context
    screenshot_path: Optional[str] = None
    coordinates: Optional[Tuple[int, int]] = None  # (x, y) as tuple
    spot_size: Optional[int] = Field(None, gt=0, le=200)

    # Error handling
    error: Optional[str] = None
    expected_format: Optional[str] = None
    supported_types: Optional[List[str]] = None

    @computed_field
    @property
    def within_tolerance(self) -> bool:
        """Check if validation is within tolerance."""
        if self.hamming_distance is None:
            return self.exact_match
        return self.hamming_distance <= self.tolerance

    @computed_field
    @property
    def similarity_percentage(self) -> Optional[float]:
        """Calculate similarity percentage based on hamming distance."""
        if self.hamming_distance is None:
            return None
        return (64 - self.hamming_distance) / 64 * 100

    @computed_field
    @property
    def similarity_level(self) -> Optional[str]:
        """Get human-readable similarity level."""
        if self.hamming_distance is None:
            return None

        if self.hamming_distance == 0:
            return "identical"
        elif self.hamming_distance <= 3:
            return "nearly_identical"
        elif self.hamming_distance <= 5:
            return "very_similar"
        elif self.hamming_distance <= 10:
            return "similar"
        elif self.hamming_distance <= 20:
            return "somewhat_similar"
        else:
            return "different"


class PreconditionResult(BaseModel):
    """Result of precondition validation with cleaner structure."""
    model_config = ConfigDict(extra='forbid')

    success: bool
    reason: str
    tolerance_count: int = Field(ge=0)
    spot_count: int = Field(ge=0)
    total_conditions: int = Field(ge=0)
    individual_results: List[ValidationResult]


def parse_condition(condition: str, context: str = "condition") -> ParsedCondition:
    """
    Parse and validate condition string in unified format.

    Args:
        condition: The condition string in format:
                  "hash_type:x:y:size:tolerance:hash_value"
        context: Context for error messages

    Returns:
        ParsedCondition with parsed values or error information
    """
    try:
        # Parse condition format
        parts = condition.split(":")

        # Handle unified format: hash_type:x:y:size:tolerance:hash_value
        if len(parts) == 6 and parts[0] in [ht.value for ht in HashType]:
            hash_type_str = parts[0]
            x, y = int(parts[1]), int(parts[2])
            size = int(parts[3])
            tolerance = int(parts[4])
            expected_hash = parts[5].strip()

            # Validate hash type
            try:
                hash_type = HashType(hash_type_str)
            except ValueError:
                return ParsedCondition(
                    success=False,
                    error=f"Unsupported hash type: {hash_type_str}",
                    supported_types=[ht.value for ht in HashType]
                )

            # Determine condition format based on size
            condition_format = ConditionFormat.SPOT if size > 0 else ConditionFormat.TOLERANCE

            return ParsedCondition(
                success=True,
                condition_format=condition_format,
                hash_type=hash_type,
                coordinates=(x, y),
                size=size if size > 0 else None,
                tolerance=tolerance,
                expected_hash=expected_hash,
                condition_type=parts[0]
            )
        else:
            return ParsedCondition(
                success=False,
                error=f"Invalid {context} format: {condition}",
                expected_format="hash_type:x:y:size:tolerance:hash_value"
            )

    except ValueError as e:
        return ParsedCondition(
            success=False,
            error=f"Invalid parameter value: {e}"
        )
    except Exception as e:
        return ParsedCondition(
            success=False,
            error=f"{context.capitalize()} parsing failed: {e}"
        )


class Validator:
    """Unified validation logic for both preconditions and postconditions."""

    def __init__(self, small_spot_threshold: int = 16, medium_spot_threshold: int = 96, use_weighted_validation: bool = True):
        """
        Initialize validator with configurable size thresholds and preprocessing control.

        Args:
            small_spot_threshold: Maximum size for small spot validation (default: 16)
            medium_spot_threshold: Maximum size for medium spot validation (default: 96)
            use_weighted_validation: Whether to use weighted validation instead of strict three-level logic (default: True)
        """
        self.small_spot_threshold = small_spot_threshold
        self.medium_spot_threshold = medium_spot_threshold
        self.enable_preprocessing = False
        self.use_weighted_validation = use_weighted_validation

        # Weighted validation configuration
        self.weighted_validation_config = {
            'reliable_small_spot_weight': 0.4,      # High weight for small spots on textured areas
            'unreliable_small_spot_weight': 0.1,   # Low weight for small spots on uniform areas
            'medium_spot_weight': 0.3,              # Medium weight for medium spots
            'full_screen_weight': 0.3,              # Medium weight for full screen
            'success_threshold': 0.6                # Need 60% weighted score to pass
        }

    def is_problematic_hash(self, hash_value: str) -> bool:
        """
        Check if a hash value is potentially problematic (e.g., all zeros, all ones).
        These hashes often indicate uniform regions that may cause false positives.

        Args:
            hash_value: Hash string to check

        Returns:
            True if hash is problematic, False otherwise
        """
        if not hash_value or len(hash_value) != 16:  # Standard 64-bit hash = 16 hex chars
            return True

        # Check for common problematic patterns
        problematic_patterns = {
            "0000000000000000",  # All zeros - likely uniform/white region
            "ffffffffffffffff",  # All ones - likely saturated/black region
            "f0f0f0f0f0f0f0f0",  # Checkerboard pattern - possible rendering artifact
            "0f0f0f0f0f0f0f0f"   # Inverse checkerboard - possible rendering artifact
        }

        hash_lower = hash_value.lower()
        return hash_lower in problematic_patterns

    def _calculate_weighted_validation_score(self, small_spot_results, medium_spot_results, full_screen_results) -> Tuple[float, str]:
        """
        Calculate weighted validation score based on reliability and success of different validation levels.

        Small spots on uniform areas (problematic hashes) get lower weight to prevent false positives.

        Returns:
            Tuple of (weighted_score, explanation)
        """
        total_score = 0.0
        max_possible_score = 0.0
        explanations = []
        config = self.weighted_validation_config

        # Process small spot results
        if small_spot_results:
            reliable_small_spots = []
            unreliable_small_spots = []

            for result in small_spot_results:
                # Check if the hash is problematic (uniform area)
                is_problematic = (result.current_hash and
                                self.is_problematic_hash(result.current_hash))

                if is_problematic:
                    unreliable_small_spots.append(result)
                else:
                    reliable_small_spots.append(result)

            # Weight reliable small spots higher
            if reliable_small_spots:
                reliable_passed = sum(1 for r in reliable_small_spots if r.success)
                reliable_weight = config['reliable_small_spot_weight']
                reliable_score = (reliable_passed / len(reliable_small_spots)) * reliable_weight
                total_score += reliable_score
                max_possible_score += reliable_weight
                explanations.append(f"Reliable small spots: {reliable_passed}/{len(reliable_small_spots)} (weight: {reliable_weight})")

            # Weight unreliable small spots lower
            if unreliable_small_spots:
                unreliable_passed = sum(1 for r in unreliable_small_spots if r.success)
                unreliable_weight = config['unreliable_small_spot_weight']
                unreliable_score = (unreliable_passed / len(unreliable_small_spots)) * unreliable_weight
                total_score += unreliable_score
                max_possible_score += unreliable_weight
                explanations.append(f"Unreliable small spots: {unreliable_passed}/{len(unreliable_small_spots)} (weight: {unreliable_weight})")

        # Process medium spot results
        if medium_spot_results:
            medium_passed = sum(1 for r in medium_spot_results if r.success)
            medium_weight = config['medium_spot_weight']
            medium_score = (medium_passed / len(medium_spot_results)) * medium_weight
            total_score += medium_score
            max_possible_score += medium_weight
            explanations.append(f"Medium spots: {medium_passed}/{len(medium_spot_results)} (weight: {medium_weight})")

        # Process full screen results
        if full_screen_results:
            full_passed = sum(1 for r in full_screen_results if r.success)
            full_weight = config['full_screen_weight']
            full_score = (full_passed / len(full_screen_results)) * full_weight
            total_score += full_score
            max_possible_score += full_weight
            explanations.append(f"Full screen: {full_passed}/{len(full_screen_results)} (weight: {full_weight})")

        # Calculate final weighted score (0.0 to 1.0)
        if max_possible_score > 0:
            weighted_score = total_score / max_possible_score
        else:
            weighted_score = 0.0

        explanation = f"Weighted score: {weighted_score:.2f}/{config['success_threshold']} ({'; '.join(explanations)})"
        return weighted_score, explanation

    def compute_hash(self, image_path: Path, hash_type: Union[HashType, str] = HashType.DHASH) -> Optional[str]:
        """Compute hash for an image using specified algorithm with enhanced preprocessing.

        Args:
            image_path: Path to the image file
            hash_type: Type of hash to compute

        Returns:
            Hash string or None if failed
        """
        try:
            if not image_path.exists():
                logger.error(f"Image file not found: {image_path}")
                return None

            # Convert string to enum if needed
            if isinstance(hash_type, str):
                hash_type = HashType(hash_type)

            # Compute hash based on type with enhanced preprocessing
            with Image.open(image_path) as img:
                # Apply preprocessing for better accuracy (especially for dhash)
                processed_img = self._preprocess_image_for_hash(img, hash_type)

                if hash_type == HashType.PHASH:
                    hash_value = str(imagehash.phash(processed_img))
                elif hash_type == HashType.AHASH:
                    hash_value = str(imagehash.average_hash(processed_img))
                elif hash_type == HashType.DHASH:
                    hash_value = str(imagehash.dhash(processed_img))
                elif hash_type == HashType.WHASH:
                    hash_value = str(imagehash.whash(processed_img))
                else:
                    logger.error(f"Unsupported hash type: {hash_type}")
                    return None

                return hash_value

        except Exception as e:
            logger.error(f"Error computing {hash_type} for {image_path}: {e}")
            return None

    def _preprocess_image_for_hash(self, img: Image.Image, hash_type: HashType) -> Image.Image:
        """
        Preprocess image for better hash accuracy, especially when color doesn't matter.

        Args:
            img: PIL Image to preprocess
            hash_type: Type of hash being computed

        Returns:
            Preprocessed PIL Image
        """
        try:
            # Check if preprocessing is disabled
            if not self.enable_preprocessing:
                logger.debug(f"Image preprocessing disabled, returning original image for {hash_type}")
                return img

            # For dhash, we want to focus on structural differences, not color
            if hash_type == HashType.DHASH:
                # Convert to grayscale to remove color influence
                processed = img.convert('L')

                # Enhance contrast to make structural differences more prominent
                enhancer = ImageEnhance.Contrast(processed)
                processed = enhancer.enhance(1.5)

                # Apply slight blur to reduce noise while preserving structure
                processed = processed.filter(ImageFilter.GaussianBlur(radius=0.5))

                return processed

            # For phash, also remove color but keep it simpler
            elif hash_type == HashType.PHASH:
                processed = img.convert('L')
                # Slight contrast enhancement for phash
                enhancer = ImageEnhance.Contrast(processed)
                processed = enhancer.enhance(1.2)
                return processed

            # For ahash and whash, minimal preprocessing
            else:
                return img.convert('L')

        except Exception as e:
            logger.warning(f"Error preprocessing image for {hash_type}: {e}")
            # Fallback to original image
            return img

    def compute_spot_hash(self, image_path: Path, x: int, y: int, size: int = 20, hash_type: Union[HashType, str] = HashType.DHASH) -> Optional[str]:
        """
        Compute hash for a small spot around coordinates.

        Args:
            image_path: Path to the image file
            x: X coordinate (center of spot)
            y: Y coordinate (center of spot)
            size: Size of the spot (width and height in pixels)
            hash_type: Type of hash to compute

        Returns:
            Hash string or None if failed
        """
        try:
            if not image_path.exists():
                logger.error(f"Image file not found: {image_path}")
                return None

            # Convert string to enum if needed
            if isinstance(hash_type, str):
                hash_type = HashType(hash_type)

            # Load image and extract spot
            with Image.open(image_path) as img:
                if img.mode != 'RGB':
                    img = img.convert('RGB')

                # Calculate spot boundaries
                half_size = size // 2
                x1 = max(0, x - half_size)
                y1 = max(0, y - half_size)
                x2 = min(img.width, x + half_size)
                y2 = min(img.height, y + half_size)

                # Validate spot is within image bounds
                if x1 >= img.width or y1 >= img.height or x2 <= 0 or y2 <= 0:
                    logger.error(f"Spot at ({x}, {y}) with size {size} is outside image bounds {img.width}x{img.height}")
                    return None

                # Extract the spot
                spot = img.crop((x1, y1, x2, y2))

                # Ensure spot has minimum size for reliable hashing
                if spot.width < 8 or spot.height < 8:
                    logger.warning(f"Spot too small ({spot.width}x{spot.height}) for reliable hashing, resizing to 8x8 minimum")
                    spot = spot.resize((max(8, spot.width), max(8, spot.height)), Image.Resampling.LANCZOS)

                # Apply the same preprocessing as full image hashing
                processed_spot = self._preprocess_image_for_hash(spot, hash_type)

                # Compute hash for the preprocessed spot
                if hash_type == HashType.PHASH:
                    hash_value = str(imagehash.phash(processed_spot))
                elif hash_type == HashType.AHASH:
                    hash_value = str(imagehash.average_hash(processed_spot))
                elif hash_type == HashType.DHASH:
                    hash_value = str(imagehash.dhash(processed_spot))
                elif hash_type == HashType.WHASH:
                    hash_value = str(imagehash.whash(processed_spot))
                else:
                    logger.error(f"Unsupported hash type: {hash_type}")
                    return None

                # logger.debug(f"Computed {hash_type.value} for spot at ({x}, {y}) size {size}: {hash_value}")
                return hash_value

        except Exception as e:
            logger.error(f"Error computing spot {hash_type} at ({x}, {y}): {e}")
            return None

    def validate_condition(self, condition: str, current_screenshot_path: Optional[Path] = None, context: str = "condition") -> ValidationResult:
        """
        Unified validation method for all condition types.

        Args:
            condition: The condition string in any supported format
            current_screenshot_path: Path to the current screenshot
            context: Context for error messages

        Returns:
            ValidationResult with validation results
        """
        # Parse condition using the unified parser
        parsed = parse_condition(condition, context)

        if not parsed.success:
            return ValidationResult(
                success=False,
                error=parsed.error,
                expected_format=parsed.expected_format,
                supported_types=parsed.supported_types
            )

        # Validate screenshot path
        if current_screenshot_path is None:
            return ValidationResult(
                success=False,
                error=f"No screenshot path provided for {context} validation"
            )

        try:
            # Extract coordinates
            x, y = parsed.coordinates

            # Ensure path is a Path object
            screenshot_path = Path(current_screenshot_path)

            # Compute current hash based on condition format
            if parsed.condition_format == ConditionFormat.SPOT:
                current_hash = self.compute_spot_hash(
                    screenshot_path, x, y, parsed.size, parsed.hash_type
                )
                tolerance = parsed.tolerance  # Use tolerance from parsed condition
                spot_size = parsed.size

                # Check for problematic current hash in spot comparisons
                # if current_hash is not None and self.is_problematic_hash(current_hash):
                #     coord_info = f" at {parsed.coordinates}"
                #     logger.warning(f"Spot comparison{coord_info} - Current hash is problematic: {current_hash}")

                #     # Set tolerance to -1 to force validation failure for problematic hashes
                #     tolerance = -1
                #     logger.info(f"Spot comparison{coord_info} - Setting tolerance to -1 to prevent false positive from problematic hash")
            else:  # TOLERANCE format
                current_hash = self.compute_hash(screenshot_path, parsed.hash_type)
                tolerance = parsed.tolerance
                spot_size = None

            if current_hash is None:
                error_msg = f"Failed to compute {parsed.hash_type.value}"
                if parsed.condition_format == ConditionFormat.SPOT:
                    error_msg += f" at ({x}, {y})"
                return ValidationResult(
                    success=False,
                    error=error_msg
                )

            # Calculate hamming distance and success
            exact_match = (current_hash == parsed.expected_hash)
            hamming_distance = None

            if len(current_hash) == len(parsed.expected_hash):
                try:
                    hash1 = imagehash.hex_to_hash(current_hash)
                    hash2 = imagehash.hex_to_hash(parsed.expected_hash)
                    hamming_distance = int(hash1 - hash2)
                except Exception as e:
                    logger.warning(f"Error calculating hamming distance: {e}")

            success = hamming_distance <= tolerance if hamming_distance is not None else exact_match

            # Create result
            result = ValidationResult(
                success=success,
                hash_type=parsed.hash_type,
                condition_format=parsed.condition_format,
                expected_hash=parsed.expected_hash,
                current_hash=current_hash,
                hamming_distance=hamming_distance,
                tolerance=tolerance,
                exact_match=exact_match,
                screenshot_path=str(current_screenshot_path),
                coordinates=parsed.coordinates,
                spot_size=spot_size
            )

            # Debug logging
            coord_info = f" at {parsed.coordinates}" if parsed.condition_format == ConditionFormat.SPOT else ""
            size_info = f" size={spot_size}" if spot_size else " size=full_image"
            logger.info(f"{parsed.condition_format.value.title()} hash comparison{coord_info}{size_info} - "
                        f"Expected {parsed.hash_type.value}: {parsed.expected_hash}, Current: {current_hash}, "
                        f"Hamming distance: {hamming_distance}, Tolerance: {tolerance}, "
                        f"Success: {success}")

            return result

        except Exception as e:
            return ValidationResult(
                success=False,
                error=f"{context.capitalize()} validation failed: {e}"
            )

    def generate_condition(self, screenshot_path: Path, x: int, y: int, hash_type: str = "dhash", size: int = 0, tolerance: int = 0) -> Optional[str]:
        """
        Generate a unified condition string from a screenshot at specific coordinates.

        Args:
            screenshot_path: Path to screenshot
            x: X coordinate
            y: Y coordinate
            hash_type: Hash algorithm to use ('dhash', 'phash', 'ahash', 'whash')
            size: Spot size in pixels (0 means full image hash)
            tolerance: Tolerance value for hash matching (0 for exact match)

        Returns:
            Condition string in format: {hash_type}:{x}:{y}:{size}:{tolerance}:{hash_value}
            or None if failed
        """
        # Compute hash based on size parameter
        if size > 0:
            # Spot-based hash
            hash_value = self.compute_spot_hash(screenshot_path, x, y, size, hash_type)
        else:
            # Full image hash
            hash_value = self.compute_hash(screenshot_path, hash_type)

        if hash_value:
            return f"{hash_type}:{x}:{y}:{size}:{tolerance}:{hash_value}"
        return None

    def get_supported_condition_types(self) -> List[str]:
        """Get list of supported condition types in unified format."""
        return [
            "dhash:x:y:size:tolerance:hash_value",
            "phash:x:y:size:tolerance:hash_value",
            "ahash:x:y:size:tolerance:hash_value",
            "whash:x:y:size:tolerance:hash_value"
        ]

    def validate_preconditions(self, preconditions: List[str], current_screenshot_path: Optional[Path] = None) -> PreconditionResult:
        """
        Validate multiple preconditions with configurable validation logic.

        Two validation modes available:

        1. Weighted validation (default, use_weighted_validation=True):
           - Assigns weights to different validation levels
           - Small spots on uniform areas (problematic hashes) get low weight
           - Small spots on textured areas get high weight
           - Flexible threshold-based success criteria

        2. Three-level validation (strict, use_weighted_validation=False):
           - Original logic: Small spot must pass AND (medium spot OR full screen) must pass
           - More strict but can fail on uniform areas where users click

        Args:
            preconditions: List of precondition strings
            current_screenshot_path: Path to the current screenshot

        Returns:
            PreconditionResult with overall validation result and individual condition results
        """
        small_spot_results = []   # size <= 16
        medium_spot_results = []  # 16 < size <= 96
        full_screen_results = []  # size = 0
        all_results = []

        for precondition in preconditions:
            # OCR preconditions (ocr:v1:) are handled by the executor's
            # _wait_for_ocr_precondition; skip them here so they are never
            # mis-classified as failed hash conditions.
            if is_ocr_precondition(precondition):
                continue

            # Check for unified format: hash_type:x:y:size:tolerance:hash_value
            hash_types = ["dhash", "phash", "ahash", "whash"]
            is_valid_format = any(
                precondition.startswith(f"{hash_type}:")
                for hash_type in hash_types
            )

            if is_valid_format:
                result = self.validate_condition(precondition, current_screenshot_path, "precondition")

                # Categorize based on size parameter (parsed from the condition)
                try:
                    parts = precondition.split(":")
                    if len(parts) >= 6:
                        size = int(parts[3])
                        if size == 0:
                            full_screen_results.append(result)
                        elif size <= self.small_spot_threshold:
                            small_spot_results.append(result)
                        elif size <= self.medium_spot_threshold:
                            medium_spot_results.append(result)
                        else:
                            # Large spots treated as medium spots
                            medium_spot_results.append(result)
                    else:
                        # Fallback: treat as full screen
                        full_screen_results.append(result)
                except (ValueError, IndexError):
                    # Fallback: treat as full screen
                    full_screen_results.append(result)

            else:
                # Handle unknown precondition types
                result = ValidationResult(
                    success=False,
                    error=f"Unknown precondition type: {precondition}",
                    supported_types=self.get_supported_condition_types()
                )

            all_results.append(result)

        # Apply flexible validation logic:
        # 1. If we have spot conditions: Small spot must pass AND (medium spot OR full screen) must pass
        # 2. If we only have full screen conditions: At least one full screen must pass
        overall_success = False
        success_reason = ""

        # Check if any conditions pass
        small_spot_passed = small_spot_results and any(result.success for result in small_spot_results)
        medium_spot_passed = medium_spot_results and any(result.success for result in medium_spot_results)
        full_screen_passed = full_screen_results and any(result.success for result in full_screen_results)

        # Check if we have any spot conditions at all
        has_spot_conditions = bool(small_spot_results or medium_spot_results)

        if has_spot_conditions:
            if self.use_weighted_validation:
                # Use weighted validation logic
                weighted_score, score_explanation = self._calculate_weighted_validation_score(
                    small_spot_results, medium_spot_results, full_screen_results
                )

                success_threshold = self.weighted_validation_config['success_threshold']
                if weighted_score >= success_threshold:
                    overall_success = True
                    success_reason = f"Weighted validation passed: {score_explanation}"
                    logger.debug(f"Weighted validation: {success_reason}")
                else:
                    overall_success = False
                    success_reason = f"Weighted validation failed: {score_explanation}"
                    logger.debug(f"Weighted validation failed: {success_reason}")
            else:
                # Original three-level validation: Small spot must pass AND (medium spot OR full screen) must pass
                if small_spot_passed and (medium_spot_passed or full_screen_passed):
                    overall_success = True
                    passed_small = sum(1 for result in small_spot_results if result.success)
                    passed_medium = sum(1 for result in medium_spot_results if result.success)
                    passed_full = sum(1 for result in full_screen_results if result.success)

                    if medium_spot_passed:
                        success_reason = f"Three-level validation: Small spot passed ({passed_small}/{len(small_spot_results)}) AND medium spot passed ({passed_medium}/{len(medium_spot_results)})"
                    else:
                        success_reason = f"Three-level validation: Small spot passed ({passed_small}/{len(small_spot_results)}) AND full screen passed ({passed_full}/{len(full_screen_results)})"

                    logger.debug(f"Three-level validation: {success_reason}")
                else:
                    # Three-level validation failed
                    failed_small = len([r for r in small_spot_results if not r.success])
                    failed_medium = len([r for r in medium_spot_results if not r.success])
                    failed_full = len([r for r in full_screen_results if not r.success])

                    if not small_spot_passed:
                        success_reason = f"Three-level validation failed: Small spot failed ({failed_small}/{len(small_spot_results)})"
                    else:
                        success_reason = f"Three-level validation failed: Small spot passed but both medium spot ({failed_medium}/{len(medium_spot_results)}) and full screen ({failed_full}/{len(full_screen_results)}) failed"

                    logger.debug(f"Three-level validation failed: {success_reason}")
        else:
            # Only full screen conditions - simplified validation
            if full_screen_passed:
                overall_success = True
                passed_full = sum(1 for result in full_screen_results if result.success)
                success_reason = f"Full screen validation: Passed ({passed_full}/{len(full_screen_results)})"
                logger.debug(f"Full screen validation: {success_reason}")
            else:
                failed_full = len([r for r in full_screen_results if not r.success])
                success_reason = f"Full screen validation failed: ({failed_full}/{len(full_screen_results)})"
                logger.debug(f"Full screen validation failed: {success_reason}")

        # Return consolidated result with updated counts
        return PreconditionResult(
            success=overall_success,
            reason=success_reason,
            tolerance_count=len(full_screen_results),  # Full screen conditions
            spot_count=len(small_spot_results) + len(medium_spot_results),  # All spot conditions
            total_conditions=len(preconditions),
            individual_results=all_results
        )

    def validate_postconditions(self, postconditions: List[str], current_screenshot_path: Optional[Path] = None) -> List[ValidationResult]:
        """
        Validate multiple postconditions including spot-based conditions.

        Args:
            postconditions: List of postcondition strings
            current_screenshot_path: Path to the current screenshot

        Returns:
            List of validation results
        """
        results = []

        for postcondition in postconditions:
            # Check for hash-based postconditions
            hash_types = ["dhash", "phash", "ahash", "whash"]
            is_hash_postcondition = any(
                postcondition.startswith(f"{hash_type}_match_tolerance:")
                for hash_type in hash_types
            )

            # Check for spot-based postconditions
            is_spot_postcondition = any(
                postcondition.startswith(f"{hash_type}_match_spot:")
                for hash_type in hash_types
            )

            if is_hash_postcondition or is_spot_postcondition:
                result = self.validate_condition(postcondition, current_screenshot_path, "postcondition")
            else:
                # Handle other types of postconditions
                result = ValidationResult(
                    success=False,
                    error=f"Unknown postcondition type: {postcondition}",
                    validation_type="unknown",
                    supported_types=self.get_supported_condition_types()
                )

            results.append(result)

        return results


# Module-level convenience functions
def validate_preconditions(preconditions: List[str], current_screenshot_path: Optional[Path] = None, use_weighted_validation: bool = True) -> PreconditionResult:
    """
    Convenience function to validate preconditions without creating an instance.

    Logic:
    - Weighted validation (default): Uses weights for different validation levels
    - Three-level validation (fallback): Small spot must pass AND (medium spot OR full screen) must pass

    Args:
        preconditions: List of precondition strings
        current_screenshot_path: Path to the current screenshot
        use_weighted_validation: Whether to use weighted validation (default: True)

    Returns:
        Dict with overall validation result and individual condition results
    """
    validator_instance = Validator(use_weighted_validation=use_weighted_validation)
    return validator_instance.validate_preconditions(preconditions, current_screenshot_path)


def validate_postconditions(postconditions: List[str], current_screenshot_path: Optional[Path] = None) -> List[ValidationResult]:
    """Convenience function to validate postconditions without creating an instance."""
    validator_instance = Validator()
    return validator_instance.validate_postconditions(postconditions, current_screenshot_path)



def generate_condition(screenshot_path: Path, x: int, y: int, hash_type: str = "dhash", size: int = 0, tolerance: int = 0) -> Optional[str]:
    """
    Convenience function to generate unified condition without creating an instance.

    Args:
        screenshot_path: Path to screenshot
        x: X coordinate
        y: Y coordinate
        hash_type: Hash algorithm to use ('dhash', 'phash', 'ahash', 'whash')
        size: Spot size in pixels (0 means full image hash)
        tolerance: Tolerance value for hash matching (0 for exact match)

    Returns:
        Condition string in format: {hash_type}:{x}:{y}:{size}:{tolerance}:{hash_value}
    """
    validator_instance = Validator()
    return validator_instance.generate_condition(screenshot_path, x, y, hash_type, size, tolerance)


# Export class and functions
__all__ = [
    'Validator',
    'validate_preconditions',
    'validate_postconditions',
    'generate_condition',
    'parse_condition',
    'ParsedCondition',
    'ValidationResult',
    'PreconditionResult'
]
