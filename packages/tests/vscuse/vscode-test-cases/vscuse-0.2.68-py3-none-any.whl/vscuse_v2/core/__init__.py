#!/usr/bin/env python3
"""
Executable Plan Schema Module

A comprehensive schema and toolkit for representing executable test plans that can be:
- Generated from user interaction recordings
- Interpreted from natural language instructions
- Executed by automated systems
- Extended with custom tools and agents

Main Components:
- Executable_plan_schema: Core schema definitions using Pydantic
- natural_language_parser: Parse natural language plans into schema format
- enhanced_planner: Generate plans from interaction recordings
- enhanced_executor: Execute plans with advanced control flow
- demo: Demonstration and examples

Usage:
    # Create a plan from natural language
    from vscuse_v2.schema import NaturalLanguageParser
    parser = NaturalLanguageParser()
    plan = parser.parse_plan("@user click button\n/wait(duration=1.0)")

    # Generate plan from recording
    from vscuse_v2.schema import Planner
    planner = Planner()
    plan = planner.generate_plan(Path("recording.json"))

    # Execute plan
    from vscuse_v2.schema import Executor
    executor = Executor()
    result = await executor.execute_plan(plan)
"""

from .executor import Executor
from .models import PlanExecutionResult, StepExecutionResult, StepReportData
from .parser import Parser
from .planner import Planner
from .schema import AgentType, ContentReference, ExecutablePlan, ExecutionContext, PlanMetadata, PlanVersion, Step, ToolParameters
from .validator import Validator

__all__ = [
    # Core schema
    'ExecutablePlan',
    'Step',
    'PlanMetadata',
    'ExecutionContext',
    'ContentReference',
    'ToolParameters',
    'AgentType',
    'PlanVersion',

    # Data models
    'PlanExecutionResult',
    'StepExecutionResult',
    'StepReportData',

    # Processors
    'Parser',
    'Planner',
    'Executor',
    'Validator',
]
__description__ = "Comprehensive executable plan schema for automated testing workflows"
