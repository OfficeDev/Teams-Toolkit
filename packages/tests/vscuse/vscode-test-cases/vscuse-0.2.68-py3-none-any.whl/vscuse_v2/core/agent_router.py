#!/usr/bin/env python3
"""
Agent Router

Handles routing and execution of steps through appropriate agents.
Manages agent selection, parsing, and execution coordination.
"""

from typing import Optional

from vscuse_v2.agent import AssertionAgent, CodeAgent, FileAgent, InteractionAgent
from vscuse_v2.agent.base_agent import AgentExecutionResult
from vscuse_v2.core.parser import Parser
from vscuse_v2.core.schema import AgentType, Step
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class AgentRouter:
    """
    Routes step execution to appropriate agents based on step configuration.

    Handles:
    - Agent selection from step configuration or description parsing
    - Agent instantiation and execution
    - Task message preparation
    """

    def __init__(self, docker_server_url: Optional[str] = None):
        """
        Initialize the agent router.

        Args:
            docker_server_url: Optional Docker server URL for agents that need it
        """
        self.docker_server_url = docker_server_url

        # Agent type mapping
        self.agent_map = {
            AgentType.FILE.value: self._execute_with_file_agent,
            AgentType.CODE.value: self._execute_with_code_agent,
            AgentType.ASSERTION.value: self._execute_with_assertion_agent,
            AgentType.INTERACTION.value: self._execute_with_interaction_agent
        }

    async def execute_step_with_agent(self, step: Step, store_fact: Optional[str] = None) -> AgentExecutionResult:
        """
        Execute step with the appropriate agent based on step configuration.

        Args:
            step: Step object to execute
            store_fact: Optional fact name for storing code agent results

        Returns:
            AgentExecutionResult from the appropriate agent
        """
        # Parse agent from description or use step agent
        parsed_result = Parser.parse_step(step)
        agent_name = parsed_result[0].lower() if parsed_result else step.agent.value
        task_message = parsed_result[1] if parsed_result else step.description

        logger.debug(f"Routing step {getattr(step, 'step_id', 'unknown')} to agent: {agent_name}")

        # Route to appropriate agent
        if agent_name in self.agent_map:
            if agent_name == AgentType.INTERACTION.value:
                # Interaction agent needs the full step object
                return await self._execute_with_interaction_agent(step)
            elif agent_name == AgentType.CODE.value:
                # Code agent may have a sample parameter and store_fact
                sample = step.parameters.sample if step.parameters else None
                return await self._execute_with_code_agent(task_message, sample, store_fact)
            else:
                # Other agents use task message
                return await self.agent_map[agent_name](task_message)
        else:
            logger.warning(f"Unknown agent type '{agent_name}', defaulting to interaction agent")
            return await self._execute_with_interaction_agent(step)

    async def _execute_with_file_agent(self, task_message: str) -> AgentExecutionResult:
        """
        Execute task using FileAgent.

        Args:
            task_message: Task description for the file agent

        Returns:
            AgentExecutionResult from file agent
        """
        logger.debug(f"Executing with FileAgent: {task_message[:100]}...")
        async with FileAgent() as agent:
            return await agent.execute_task(task_message)

    async def _execute_with_code_agent(self, task_message: str, sample: str = None, store_fact: str = None) -> AgentExecutionResult:
        """
        Execute task using CodeAgent.

        Args:
            task_message: Task description for the code agent
            sample: Optional sample execution result from previous successful run
            store_fact: Optional fact name for storing execution result

        Returns:
            AgentExecutionResult from code agent
        """
        logger.debug(f"Executing with CodeAgent: {task_message[:100]}...")
        if sample:
            logger.debug(f"Using sample reference (length: {len(sample)} chars)")
        if store_fact:
            logger.debug(f"Will store result as fact: {store_fact}")
        async with CodeAgent(sample=sample, store_fact=store_fact) as agent:
            return await agent.execute_task(task_message)

    async def _execute_with_assertion_agent(self, task_message: str) -> AgentExecutionResult:
        """
        Execute task using AssertionAgent.

        Args:
            task_message: Task description for the assertion agent

        Returns:
            AgentExecutionResult from assertion agent
        """
        logger.debug(f"Executing with AssertionAgent: {task_message[:100]}...")
        async with AssertionAgent(docker_server_url=self.docker_server_url) as agent:
            return await agent.execute_task(task_message)

    async def _execute_with_interaction_agent(self, step: Step) -> AgentExecutionResult:
        """
        Execute step using InteractionAgent.

        Args:
            step: Full step object for the interaction agent

        Returns:
            AgentExecutionResult from interaction agent
        """
        logger.debug(f"Executing with InteractionAgent: step {getattr(step, 'step_id', 'unknown')}")
        async with InteractionAgent(docker_server_url=self.docker_server_url) as agent:
            return await agent.execute_task(step)
