#!/usr/bin/env python3
"""
Fact Store

Global runtime context for storing facts extracted during plan execution.
Facts are key-value pairs where values are strings (max 50 words) representing
extracted information that can be referenced in subsequent steps.
"""

from typing import Dict, Optional

from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class FactStore:
    """Global singleton for storing facts during plan execution."""

    _instance = None
    _facts: Dict[str, str] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def get_facts(self) -> Dict[str, str]:
        """Get all stored facts.

        Returns:
            Dictionary of fact_name -> fact_value
        """
        return self._facts

    def get_fact(self, fact_name: str) -> Optional[str]:
        """Get a specific fact by name.

        Args:
            fact_name: Name of the fact to retrieve

        Returns:
            Fact value if exists, None otherwise
        """
        return self._facts.get(fact_name)

    def store_fact(self, fact_name: str, fact_value: str) -> None:
        """Store a fact with validation.

        Args:
            fact_name: Name/key for the fact
            fact_value: String value (max 50 words)

        Raises:
            ValueError: If fact_value exceeds 50 words
        """
        # Validate word count
        word_count = len(fact_value.split())
        if word_count > 50:
            raise ValueError(
                f"Fact value exceeds 50 words limit (got {word_count} words). "
                f"Please provide a more concise fact."
            )

        self._facts[fact_name] = fact_value
        logger.debug(f"Stored fact '{fact_name}': {fact_value}")

    def reset_facts(self) -> None:
        """Reset all stored facts. Call this when starting a new execution."""
        self._facts.clear()
        logger.debug("Fact store reset")

    def has_fact(self, fact_name: str) -> bool:
        """Check if a fact exists.

        Args:
            fact_name: Name of the fact to check

        Returns:
            True if fact exists, False otherwise
        """
        return fact_name in self._facts

    def get_facts_copy(self) -> Dict[str, str]:
        """Get a copy of all facts for debugging purposes.

        Returns:
            Copy of facts dictionary
        """
        return self._facts.copy()
