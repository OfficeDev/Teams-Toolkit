#!/usr/bin/env python3
"""
Executable Plan Schema

A comprehensive schema for representing executable test plans that can be:
1. Generated from user interaction recordings
2. Interpreted from natural language instructions
3. Executed by automated systems
4. Extended with custom tools and agents

The schema supports:
- Agent-based task delegation (@agent)
- Content file references (#content)
- Tool invocations (/tool)
- Hierarchical plan structure
- Validation and execution metadata
- Special tags for execution control:
  - delay:X - Wait X seconds before executing the step
  - force_run:true - Skip precondition and postcondition checks
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

# Import default values from config manager
from vscuse_v2.config.config_manager import ExecutionConfig


class PlanVersion(str, Enum):
    """Supported plan schema versions."""
    V1_0 = "1.0"
    V1_1 = "1.1"


class AgentType(str, Enum):
    """Supported agent types - each agent represents a collection of tools."""
    INTERACTION = "interaction"  # UI interactions (click, type, etc.)
    FILE = "file"               # File operations (read, write, create)
    CODE = "code"               # Code execution and system commands (renamed from system)
    ASSERTION = "assertion"     # Assertions and validation checks (renamed from validation)


class ExecutionContext(BaseModel):
    """Execution context and configuration settings."""
    # Execution configuration settings (aligned with ExecutionConfig from config_manager)
    delay_between_steps: float = Field(ExecutionConfig().delay_between_steps, description="Default delay between steps in seconds")
    stop_on_error: bool = Field(ExecutionConfig().stop_on_error, description="Stop execution on error")
    precondition_wait_timeout: float = Field(ExecutionConfig().precondition_wait_timeout, description="Maximum time to wait for preconditions")
    precondition_retry_interval: float = Field(ExecutionConfig().precondition_retry_interval, description="Interval between precondition retry attempts")
    step_retry_timeout: float = Field(ExecutionConfig().step_retry_timeout, description="Maximum time in seconds to retry step on failure")


class ContentReference(BaseModel):
    """Reference to content files or data."""
    type: Literal["file", "url", "inline", "variable"] = Field(description="Content type")
    path: Optional[str] = Field(None, description="File path or URL")
    content: Optional[str] = Field(None, description="Inline content")
    encoding: Optional[str] = Field("utf-8", description="Content encoding")
    mime_type: Optional[str] = Field(None, description="MIME type")
    variables: Dict[str, Any] = Field(default_factory=dict, description="Template variables")


class ToolParameters(BaseModel):
    """Tool parameters for interaction agent - other agents handle natural language directly."""
    # Interaction tool parameters - only these are exposed since file, code, and assertion agents
    # handle natural language descriptions internally
    x: Optional[int] = Field(None, description="X coordinate for click/hover")
    y: Optional[int] = Field(None, description="Y coordinate for click/hover")
    button: Optional[str] = Field(None, description="Mouse button")
    text: Optional[str] = Field(None, description="Text to type")
    keys: Optional[str] = Field(None, description="Keyboard shortcut keys")
    key: Optional[str] = Field(None, description="Single key press")

    # Scroll parameters for interaction agent
    dx: Optional[int] = Field(None, description="Horizontal scroll amount")
    dy: Optional[int] = Field(None, description="Vertical scroll amount")

    # Sample parameter for code agent learning
    sample: Optional[str] = Field(None, description="Sample execution result from previous successful run (used for code agent learning)")

    @field_validator('x', 'y')
    @classmethod
    def validate_coordinates(cls, v):
        if v is not None and (v < 0 or v > 10000):
            raise ValueError('Coordinates must be between 0 and 10000')
        return v


class Step(BaseModel):
    """Individual step in the plan."""
    step_id: str = Field(description="Unique step identifier")
    agent: AgentType = Field(AgentType.CODE, description="Agent responsible for execution - represents the collection of tools available")
    tool: str = Field(description="Tool name to execute")
    parameters: ToolParameters = Field(default_factory=ToolParameters, description="Tool parameters")
    description: str = Field(description="Human-readable step description")
    content_refs: List[ContentReference] = Field(default_factory=list, description="Referenced content")

    # Execution metadata
    timeout: Optional[float] = Field(30.0, description="Step timeout in seconds")
    retry_count: int = Field(0, description="Number of retries on failure")
    continue_on_error: bool = Field(False, description="Continue execution if step fails")

    # Dependencies and conditions
    depends_on: List[str] = Field(default_factory=list, description="Step IDs this step depends on")
    preconditions: List[str] = Field(default_factory=list, description="Conditions that must be true")
    postconditions: List[str] = Field(default_factory=list, description="Expected outcomes")

    # Precondition wait configuration (overrides plan defaults)
    precondition_wait_timeout: Optional[float] = Field(None, description="Max time to wait for preconditions (overrides plan default)")
    precondition_retry_interval: Optional[float] = Field(None, description="Interval between precondition retries (overrides plan default)")

    # Tags support
    tags: List[str] = Field(default_factory=list, description="Step tags for filtering/grouping")

    # Screenshot reference (for recording-based steps)
    screenshot: Optional[str] = Field(None, description="Screenshot path for step execution")


class PlanDescription(BaseModel):
    """Structured plan description."""
    owner: str = Field("", description="Plan owner")
    workitem: str = Field("", description="Associated work item or ticket")
    other: str = Field("", description="Other plan information")


class PlanMetadata(BaseModel):
    """Plan metadata and configuration."""
    plan_id: str = Field(description="Unique plan identifier")
    name: str = Field(description="Plan name")
    description: Optional[PlanDescription] = Field(None, description="Structured plan description")
    version: PlanVersion = Field(PlanVersion.V1_1, description="Schema version")

    # Source information
    generated_at: datetime = Field(default_factory=datetime.now, description="Generation timestamp")

    # Execution configuration
    execution_context: ExecutionContext = Field(default_factory=ExecutionContext)
    execution_order: List[str] = Field(default_factory=list, description="Step IDs in execution order")

    # Plan characteristics
    total_steps: int = Field(0, description="Total number of steps")

    # Tags and categorization
    tags: List[str] = Field(default_factory=list, description="Plan tags")


class ExecutablePlan(BaseModel):
    """Complete executable plan schema."""
    plan_metadata: PlanMetadata = Field(description="Plan metadata")
    steps: List[Step] = Field(description="Plan steps")

    # Natural language integration
    agent_instructions: Dict[str, str] = Field(default_factory=dict, description="Agent-specific instructions")

    class Config:
        """Pydantic configuration."""
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

    def validate_plan(self) -> List[str]:
        """Validate the complete plan and return any errors."""
        errors = []

        # Basic structure validation
        if not self.steps:
            errors.append("Plan has no steps defined")
            return errors

        # Check for duplicate step IDs
        step_ids = [step.step_id for step in self.steps]
        unique_step_ids = set(step_ids)

        if len(step_ids) != len(unique_step_ids):
            duplicates = [step_id for step_id in unique_step_ids if step_ids.count(step_id) > 1]
            errors.append(f"Duplicate step IDs found: {duplicates}")

        # Validate individual steps
        for i, step in enumerate(self.steps):
            # Check required fields
            if not step.step_id.strip():
                errors.append(f"Step at index {i} has empty step_id")

            if not step.description.strip():
                errors.append(f"Step {step.step_id} has empty description")

        # Validate step dependencies
        for step in self.steps:
            for dep in step.depends_on:
                if dep not in unique_step_ids:
                    errors.append(f"Step {step.step_id} depends on non-existent step '{dep}'")
                elif dep == step.step_id:
                    errors.append(f"Step {step.step_id} cannot depend on itself")

        # Validate execution order
        if self.plan_metadata.execution_order:
            execution_order_set = set(self.plan_metadata.execution_order)

            # Note: Duplicate entries are allowed in execution_order
            # (e.g., same group referenced multiple times or same step re-run)
            # We only validate that each referenced step ID exists

            # Check for non-existent steps in execution order
            invalid_steps = execution_order_set - unique_step_ids
            if invalid_steps:
                errors.append(f"Execution order references non-existent steps: {sorted(invalid_steps)}")

            # Check for missing steps from execution order
            missing_steps = unique_step_ids - execution_order_set
            if missing_steps:
                errors.append(f"Steps not included in execution_order: {sorted(missing_steps)}")
        else:
            # Auto-generate execution order if not specified
            self.plan_metadata.execution_order = [step.step_id for step in self.steps]

        # Validate plan metadata
        if not self.plan_metadata.plan_id.strip():
            errors.append("Plan metadata has empty plan_id")

        if not self.plan_metadata.name.strip():
            errors.append("Plan metadata has empty name")

        # Update metadata (only if no critical errors)
        if not any("Duplicate step IDs" in error or "has no steps" in error for error in errors):
            self.plan_metadata.total_steps = len(unique_step_ids)

        return errors


# Schema is now complete - no forward references to rebuild

def create_example_plan() -> ExecutablePlan:
    """Create an example executable plan demonstrating the schema."""

    # Example steps from a typical workflow
    steps = [
        Step(
            step_id="step_001",
            agent=AgentType.INTERACTION,
            tool="click",
            parameters=ToolParameters(x=28, y=303, button="left"),
            description="Click on VS Code explorer icon",
            tags=["navigation", "ui"]
        ),

        Step(
            step_id="step_002",
            agent=AgentType.INTERACTION,
            tool="keyboard_shortcut",
            parameters=ToolParameters(keys="ctrl+shift+p"),
            description="Open VS Code command palette",
            tags=["navigation", "command"]
        ),

        Step(
            step_id="step_003",
            agent=AgentType.INTERACTION,
            tool="type_text",
            parameters=ToolParameters(text="provision"),
            description="Type 'provision' in command palette",
            tags=["input", "search", "delay:2"],
            depends_on=["step_002"]
        ),

        Step(
            step_id="step_004",
            agent=AgentType.FILE,
            tool="create_file",
            parameters=ToolParameters(),  # File agent handles natural language descriptions directly
            description="Create a configuration file named config.yaml with version 1.0",
            content_refs=[
                ContentReference(
                    type="file",
                    path="templates/config.yaml.template",
                    mime_type="text/yaml"
                )
            ],
            tags=["file", "config"]
        )
    ]

    # Plan metadata
    metadata = PlanMetadata(
        plan_id="plan_example_001",
        name="VS Code Setup Workflow",
        description=PlanDescription(
            owner="Example User",
            workitem="TICKET-123",
            other="Example workflow demonstrating the executable plan schema"
        ),
        execution_context=ExecutionContext(),
        tags=["vscode", "setup", "demo"]
    )

    plan = ExecutablePlan(
        plan_metadata=metadata,
        steps=steps
    )

    return plan


if __name__ == "__main__":
    # Demonstrate the schema
    example_plan = create_example_plan()

    # Validate the plan
    errors = example_plan.validate_plan()
    if errors:
        print("Validation errors:")
        for error in errors:
            print(f"  - {error}")
    else:
        print("Plan validation passed!")

    # Export to JSON
    json_output = example_plan.model_dump_json(indent=2)
    print("\nExample plan JSON:")
    print(json_output[:500] + "..." if len(json_output) > 500 else json_output)
