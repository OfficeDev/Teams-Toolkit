#!/usr/bin/env python3
"""
OCR-based precondition checker.

Compares the *expected* whole-screen OCR text (captured at record time) with the
*current* screen's OCR text and asks an LLM to judge whether the current screen is
consistent enough to execute the step. This is the primary precondition mechanism;
the legacy perceptual-hash path is retained as a transitional fallback in the executor.
"""

import time
from typing import Optional

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from openai import AsyncAzureOpenAI
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class OcrConsistencyResult(BaseModel):
    """Structured LLM verdict on OCR text consistency."""
    consistent: bool
    confidence: float
    reasoning: str


class OcrPreconditionPromptTemplate:
    """Prompts for the OCR precondition consistency judge."""

    AGENT_INSTRUCTIONS = """
You decide whether a UI automation step can run now, by comparing the text that was
visible on screen when the step was RECORDED against the text visible on the CURRENT screen.

You receive:
1. The step's action description (what it INTENDS to do) and, if a click, its target (x, y).
2. EXPECTED TEXT: all text read from the screen at record time.
3. CURRENT TEXT: all text read from the screen right now.

First, use the STEP DESCRIPTION to understand the step's intent: which screen/dialog it expects
to be on and which UI element (button, menu item, field, label) it is about to act on. If a
PRECONDITION INTENT is provided, treat it as the PRIMARY thing to verify — it explicitly states
what must be true on the current screen for this step to run. Then judge whether the CURRENT
screen is in a state CONSISTENT with the recorded state for executing that intent — i.e. the same
screen/view is shown and the element the intent/description refers to is present.

Guidelines:
- If a PRECONDITION INTENT is given, prioritize verifying it over unrelated text.
- Prioritize the element/screen implied by the description over unrelated text.
- Ignore benign differences: dynamic values (timestamps, paths, usernames, versions, counters),
  cursor/focus, minor OCR noise, reordering, and unrelated text elsewhere on screen.
- Treat as INCONSISTENT: a different screen/view/dialog, a missing target element or label,
  an error/blocking overlay, or content indicating the app is on the wrong step.
- Be decisive but conservative: if the current screen is clearly a different context, mark it
  inconsistent so the runner keeps waiting rather than clicking blindly.

Respond in the structured format:
- consistent: true if the current screen is compatible with executing the step's intent, else false
- confidence: 0.0-1.0 confidence in your judgement
- reasoning: one short sentence explaining the decision
"""

    QUERY_TEMPLATE = (
        "STEP DESCRIPTION: {description}\n"
        "{intent_info}"
        "{target_info}"
        "\n=== EXPECTED TEXT (recorded) ===\n{expected_text}\n"
        "\n=== CURRENT TEXT (now) ===\n{current_text}\n"
    )


class OcrPreconditionChecker:
    """LLM judge for whether current OCR text is consistent with expected OCR text."""

    def __init__(self):
        self._client: Optional[AsyncAzureOpenAI] = None
        self._agent: Optional[Agent] = None
        self._runner: Optional[Runner] = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        if self._client is None:
            azure_config = get_azure_openai_config()
            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)
            self._agent = Agent(
                name="OcrPreconditionChecker",
                instructions=OcrPreconditionPromptTemplate.AGENT_INSTRUCTIONS,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                ),
                output_type=OcrConsistencyResult,
            )
            self._runner = Runner()
            logger.info(f"OCR precondition checker initialized with model: {azure_config.model}")

    async def judge_consistency(
        self,
        expected_text: str,
        current_text: str,
        description: str = "",
        target_x: Optional[int] = None,
        target_y: Optional[int] = None,
        intent: Optional[str] = None,
    ) -> OcrConsistencyResult:
        """Ask the LLM whether *current_text* is consistent with *expected_text*.

        *intent* (from the ``precondition_intent:`` step tag) is an optional
        free-text hint stating what the precondition must verify; when provided
        it is presented to the judge as the primary thing to check.

        Returns an :class:`OcrConsistencyResult`. On any error, returns a
        non-consistent result with confidence 0.0 so the caller keeps waiting.
        """
        try:
            await self._initialize_client()

            target_info = ""
            if target_x is not None and target_y is not None:
                target_info = f"CLICK TARGET: ({target_x}, {target_y})\n"

            intent_info = ""
            if intent:
                intent_info = f"PRECONDITION INTENT (verify this first): {intent}\n"

            query = OcrPreconditionPromptTemplate.QUERY_TEMPLATE.format(
                description=description or "(no description)",
                intent_info=intent_info,
                target_info=target_info,
                expected_text=expected_text or "(empty)",
                current_text=current_text or "(empty)",
            )

            # Log the exact prompt sent to the LLM (helps diagnose precondition
            # decisions). Debug-level so it does not add noise to normal INFO runs.
            logger.debug("OCR precondition prompt sent to LLM:\n%s", query)

            start = time.time()
            result = await self._runner.run(self._agent, input=query)
            duration = time.time() - start

            verdict = result.final_output_as(OcrConsistencyResult, raise_if_incorrect_type=True)
            logger.info(
                f"OCR precondition judge: consistent={verdict.consistent} "
                f"confidence={verdict.confidence:.2f} ({duration:.2f}s) - {verdict.reasoning}"
            )
            # When the judge rejects the screen, log the compared texts so the
            # decision can be diagnosed from an INFO-level run.
            if not verdict.consistent:
                logger.info(
                    "OCR precondition INCONSISTENT - inputs were: description=%r intent=%r\n"
                    "--- EXPECTED TEXT (recorded, first 800 chars) ---\n%s\n"
                    "--- CURRENT TEXT (now, first 800 chars) ---\n%s",
                    description,
                    intent,
                    (expected_text or "")[:800],
                    (current_text or "")[:800],
                )
            return verdict
        except Exception as e:  # noqa: BLE001 - never let the judge crash the loop
            logger.warning(f"OCR precondition judge failed: {e}")
            return OcrConsistencyResult(
                consistent=False,
                confidence=0.0,
                reasoning=f"judge error: {e}",
            )
