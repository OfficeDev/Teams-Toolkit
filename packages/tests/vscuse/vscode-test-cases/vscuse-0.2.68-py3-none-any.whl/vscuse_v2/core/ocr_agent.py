#!/usr/bin/env python3
"""
OCR Agent using Azure Computer Vision

Uses Azure Computer Vision to extract text and bounding boxes from a screenshot,
then uses an LLM to find the (x, y) coordinate of a UI element described in natural language.

This is an internal agent used by the tag processor (ocr:true tag), not exposed to end users.
"""

import base64
import json
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential
from openai import AsyncAzureOpenAI
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config, get_azure_vision_config
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class OcrCoordinateResult:
    """Result from OCR-based coordinate resolution."""
    x: int
    y: int
    text: str
    justification: Optional[str] = None


class OcrAgentPromptTemplate:
    """Template for generating OCR agent prompts and instructions."""

    AGENT_INSTRUCTIONS = """
You are a UI element locator that finds the (x, y) coordinates of a target element on a screenshot.

You receive:
1. A screenshot of the current screen
2. A list of OCR text blocks (each with a bounding box [x1, y1, x2, y2]) extracted from that screenshot
3. A natural-language description of the UI element the user wants to interact with

Your task: identify the single best matching text block from the OCR data.

IMPORTANT GUIDELINES:
- Use both the screenshot and the OCR data to make your decision
- Match the description to visible text, considering context and position
- If multiple blocks partially match, choose the most specific and relevant one
- If the description refers to a sub-part of a text block, specify it in the substring field
- Provide a brief justification for your choice

Your response must be in the structured format with these fields:
- text: the full matched text block
- bbox: bounding box [x1, y1, x2, y2] of the matched block
- substring: (optional) the specific part of text to click on
- justification: short explanation of your choice
"""

    QUERY_TEMPLATE = (
        "Description: {description}\n\n"
        "OCR data:\n{ocr_data}"
    )

    OCR_ERROR_MESSAGES = {
        "no_text_blocks": (
            "OCR returned no text blocks from the screenshot."
        ),
        "invalid_llm_response": (
            "OCR LLM returned invalid JSON: {error_details}\nRaw: {raw_response}"
        ),
        "vision_endpoint_missing": (
            "AZURE_VISION_ENDPOINT environment variable is not set. "
            "It is required for the ocr:true tag."
        ),
        "vision_key_missing": (
            "AZURE_VISION_KEY environment variable is not set. "
            "It is required for the ocr:true tag."
        ),
    }

    @classmethod
    def get_error_message(cls, error_type: str, **kwargs) -> str:
        """Get formatted error message for specific error type."""
        template = cls.OCR_ERROR_MESSAGES.get(
            error_type, "An unexpected OCR error occurred: {error_details}"
        )
        return template.format(**kwargs)


class OcrLlmResult(BaseModel):
    """Structured LLM response for OCR element matching."""
    text: str
    bbox: List[int]
    substring: Optional[str] = None
    justification: Optional[str] = None


def _calculate_substring_coordinates(text: str, substring: str, bbox: List[int]) -> Dict[str, int]:
    """
    Estimate the centre x coordinate for a substring within a bounding box,
    assuming uniform character width.
    """
    center_x = (bbox[0] + bbox[2]) // 2
    center_y = (bbox[1] + bbox[3]) // 2

    if substring and substring in text and len(text) > 0:
        text_width = bbox[2] - bbox[0]
        char_width = text_width / len(text)
        start_index = text.find(substring)
        start_x = bbox[0] + int(start_index * char_width)
        end_x = start_x + int(len(substring) * char_width)
        center_x = (start_x + end_x) // 2

    return {"x": center_x, "y": center_y}


class OcrAgent:
    """
    Agent that resolves a natural-language description to (x, y) screen coordinates
    using Azure Computer Vision OCR + an LLM reasoner.

    This is an internal agent used by the ocr:true tag, not directly exposed to end users.
    """

    def __init__(self):
        """Initialize the OCR agent."""
        self._client: Optional[AsyncAzureOpenAI] = None
        self._agent: Optional[Agent] = None
        self._runner: Optional[Runner] = None
        self._vision_client = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        """Initialize the Azure OpenAI client, vision client, and agent."""
        if self._client is None:
            azure_config = get_azure_openai_config()
            vision_config = get_azure_vision_config()

            if not vision_config.endpoint or vision_config.endpoint.startswith("${"):
                raise ValueError(
                    OcrAgentPromptTemplate.get_error_message("vision_endpoint_missing")
                )
            if not vision_config.api_key or vision_config.api_key.startswith("${"):
                raise ValueError(
                    OcrAgentPromptTemplate.get_error_message("vision_key_missing")
                )

            self._vision_client = ImageAnalysisClient(
                endpoint=vision_config.endpoint,
                credential=AzureKeyCredential(vision_config.api_key),
            )

            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)

            self._agent = Agent(
                name="OcrAgent",
                instructions=OcrAgentPromptTemplate.AGENT_INSTRUCTIONS,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                ),
                output_type=OcrLlmResult,
            )
            self._runner = Runner()
            logger.info(f"OCR agent initialized successfully with model: {azure_config.model}")

    async def resolve_coordinates(
        self,
        description: str,
        screenshot_path: str,
    ) -> OcrCoordinateResult:
        """
        Resolve (x, y) for the UI element described in *description* by running
        OCR on *screenshot_path* and asking the LLM to pick the right block.

        Args:
            description: Natural-language description of the UI element.
            screenshot_path: Absolute path to a screenshot image file.

        Returns:
            OcrCoordinateResult with resolved x, y coordinates.

        Raises:
            RuntimeError: If OCR finds no text, or the LLM response cannot be parsed.
        """
        await self._initialize_client()

        with open(screenshot_path, "rb") as f:
            image_data = f.read()

        result = self._vision_client.analyze(
            image_data=image_data,
            visual_features=[VisualFeatures.READ],
        )

        if not result.read or not result.read.blocks:
            raise RuntimeError(
                OcrAgentPromptTemplate.get_error_message("no_text_blocks")
            )

        ocr_blocks = self._extract_ocr_blocks(result)

        x, y, text, justification = await self._ask_llm(description, ocr_blocks, screenshot_path)

        logger.info(
            f"OCR resolved '{description[:60]}' -> ({x}, {y}), matched text: '{text}'"
        )
        return OcrCoordinateResult(x=x, y=y, text=text, justification=justification)

    def _extract_ocr_blocks(self, result) -> List[Dict]:
        """Convert the Azure Vision result into a flat list of {text, bbox} dicts."""
        blocks = []
        for block in result.read.blocks:
            for line in block.lines:
                polygon = line.bounding_polygon
                if not polygon:
                    continue

                if hasattr(polygon[0], "x"):
                    xs = [p.x for p in polygon]
                    ys = [p.y for p in polygon]
                else:
                    xs = [p[0] for p in polygon]
                    ys = [p[1] for p in polygon]

                bbox = [int(min(xs)), int(min(ys)), int(max(xs)), int(max(ys))]
                blocks.append({"text": line.text, "bbox": bbox})

        return blocks

    def _encode_image_file(self, file_path: str) -> str:
        """Encode an image file to base64."""
        try:
            with open(file_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
            return encoded_string
        except Exception as e:
            raise ValueError(f"Failed to encode image file: {str(e)}")

    async def _ask_llm(
        self,
        description: str,
        ocr_blocks: List[Dict],
        screenshot_path: str,
    ) -> Tuple[int, int, str, Optional[str]]:
        """
        Ask the LLM which OCR block corresponds to *description*.

        Returns (x, y, matched_text, justification).
        """
        if self._agent is None or self._runner is None:
            raise RuntimeError("OCR agent not initialized. Call _initialize_client() first.")

        ocr_data_str = json.dumps(ocr_blocks, ensure_ascii=False, indent=2)
        query_text = OcrAgentPromptTemplate.QUERY_TEMPLATE.format(
            description=description,
            ocr_data=ocr_data_str,
        )

        # Read and encode the screenshot
        image_b64 = self._encode_image_file(screenshot_path)
        image_url = f"data:image/png;base64,{image_b64}"

        # Build multimodal input: screenshot image + OCR query text
        input_data = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_image",
                        "detail": "high",
                        "image_url": image_url,
                    }
                ],
            },
            {
                "role": "user",
                "content": query_text,
            }
        ]

        result = await self._runner.run(self._agent, input=input_data)

        if not result or not hasattr(result, 'final_output'):
            raise RuntimeError("Invalid result from OCR agent runner")

        try:
            ocr_result = result.final_output_as(OcrLlmResult, raise_if_incorrect_type=True)
        except TypeError as e:
            logger.warning(f"Structured output validation failed: {e}. Final output type: {type(result.final_output)}")
            raise RuntimeError(
                OcrAgentPromptTemplate.get_error_message(
                    "invalid_llm_response",
                    error_details=str(e),
                    raw_response=str(result.final_output),
                )
            ) from e

        logger.debug(f"OCR LLM structured response: {ocr_result}")

        text = ocr_result.text
        bbox = ocr_result.bbox
        substring = ocr_result.substring
        justification = ocr_result.justification

        if substring and substring in text:
            coords = _calculate_substring_coordinates(text, substring, bbox)
        else:
            coords = {
                "x": (bbox[0] + bbox[2]) // 2,
                "y": (bbox[1] + bbox[3]) // 2,
            }

        return coords["x"], coords["y"], text, justification
