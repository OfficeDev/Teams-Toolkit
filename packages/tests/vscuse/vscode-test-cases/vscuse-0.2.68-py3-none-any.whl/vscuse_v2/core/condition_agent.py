#!/usr/bin/env python3
"""
Condition Agent for UI State Comparison using OpenAI Agents SDK

This agent compares current screenshots with recorded screenshots to determine
if UI conditions are met for step execution, providing fallback analysis when
automated condition checks fail.
"""

import base64
import io
import time
from typing import Optional, Tuple

import imagehash
from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from openai import AsyncAzureOpenAI
from PIL import Image, ImageDraw
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.core.schema import Step
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class ConditionAnalysisResult(BaseModel):
    """Structured result for condition analysis."""
    decision: str  # One of: EXECUTE, WAIT, SKIP, ABORT
    explanation: str


def is_valid_screenshot_data(screenshot: Optional[str]) -> bool:
    """Validate if screenshot data is a valid base64 data URI or file path.

    Args:
        screenshot: Screenshot data string to validate

    Returns:
        True if screenshot appears to be valid data, False otherwise
    """
    if not screenshot:
        return False

    # Check if it's a data URI with actual base64 content
    if screenshot.startswith('data:'):
        # Data URI should be at least: "data:image/jpeg;base64," + some data
        # Minimum valid data URI is around 30+ chars
        if len(screenshot) < 50:
            return False
        if ';base64,' not in screenshot:
            return False
        # Check there's actual content after base64,
        try:
            _, base64_data = screenshot.split(',', 1)
            return len(base64_data) > 100  # Minimum base64 content
        except ValueError:
            return False

    # Check if it's a file path that exists
    import os
    if os.path.isfile(screenshot):
        return True

    # If it's neither a data URI nor existing file, it's invalid
    return False


class ConditionPromptTemplate:
    """Template for generating condition analysis prompts."""

    AGENT_INSTRUCTIONS = """
You are a UI automation condition analyzer. Compare two screenshots to determine if the current UI state is suitable for executing an automation step.

Your task is to analyze:
1. Whether the current UI state matches or is compatible with the recorded state
2. If the intended UI element is present and clickable/interactable
3. Whether the step can be safely executed despite minor UI differences

Be MORE CONSERVATIVE about UI state differences. If there are active dropdowns, menus, overlays, or other UI elements that weren't present in the recorded state, prefer WAIT or SKIP over EXECUTE to avoid unintended interactions.

Be practical and focused on whether the automation step can succeed, not perfect pixel matching.
"""

    CONDITION_ANALYSIS_PROMPT = """
Compare these two screenshots to determine if an automation step can be executed:

**RECORDED SCREENSHOT** (when step was originally recorded):
This shows the UI state when the step was successfully recorded.

**CURRENT SCREENSHOT** (current UI state):
This shows the current UI state where we want to execute the step.

**STEP TO EXECUTE:**
- Tool: {tool}
- Parameters: {parameters}
- Description: {description}

{coordinate_info}

**ANALYSIS REQUIRED:**
1. Is the target UI element visible and accessible in the current screenshot?
2. Are there any blocking overlays, dialogs, or UI changes that would prevent execution?
3. Is the current UI state fundamentally compatible with executing this step?

**DECISION OPTIONS:**
- EXECUTE: If the step can be safely executed
- WAIT: If the UI needs time to load/stabilize but execution should be possible soon
- SKIP: If the UI state is incompatible and step should be skipped
- ABORT: If there are serious UI issues that require manual intervention

Provide your analysis using the structured output format with 'decision' and 'explanation' fields.
"""

    @classmethod
    def format_analysis_prompt(
        cls,
        step: Step,
        has_coordinates: bool = False
    ) -> str:
        """Format the condition analysis prompt with step details.

        Args:
            step: Step object being analyzed
            has_coordinates: Whether the step has x,y coordinates

        Returns:
            Formatted prompt string
        """
        coordinate_info = ""
        if has_coordinates and step.parameters and hasattr(step.parameters, 'x') and hasattr(step.parameters, 'y'):
            coordinate_info = f"\n**TARGET COORDINATES:** ({step.parameters.x}, {step.parameters.y})\nA red crosshair will be drawn on both screenshots at these coordinates to show the intended interaction point."

        return cls.CONDITION_ANALYSIS_PROMPT.format(
            tool=step.tool,
            parameters=step.parameters.model_dump(exclude_none=True) if step.parameters else {},
            description=step.description or "No description",
            coordinate_info=coordinate_info
        )


class ConditionAgent:
    """Agent for analyzing UI condition compatibility using vision comparison."""

    def __init__(self):
        """Initialize the condition analysis agent."""
        self._client: AsyncAzureOpenAI = None
        self._agent: Agent = None
        self._runner: Optional[Runner] = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        """Initialize the Azure OpenAI client and agent."""
        if self._client is None:
            # Get configuration from config manager
            azure_config = get_azure_openai_config()

            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)

            self._agent = Agent(
                name="ConditionAnalyzer",
                instructions=ConditionPromptTemplate.AGENT_INSTRUCTIONS,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                ),
                output_type=ConditionAnalysisResult
            )

            self._runner = Runner()
            logger.info("Condition analysis agent initialized")

    def _convert_to_base64_with_crosshair(
        self,
        image_source: str,
        x: Optional[int] = None,
        y: Optional[int] = None,
        label: str = ""
    ) -> str:
        """Convert image source (data URI or file path) to base64 with optional crosshair overlay.

        Args:
            image_source: Data URI string (data:image/...;base64,...) or file path
            x: X coordinate for crosshair (optional)
            y: Y coordinate for crosshair (optional)
            label: Label for debugging/logging

        Returns:
            Base64 encoded data URL with crosshair if coordinates provided

        Raises:
            ValueError: If data URI format is invalid or image_source is not valid
            FileNotFoundError: If file doesn't exist
            IOError: If there's an error processing the image
        """
        try:
            # Validate image source before processing
            if not is_valid_screenshot_data(image_source):
                raise ValueError(
                    f"Invalid {label} screenshot data: '{image_source[:50]}...' "
                    f"(length: {len(image_source)}). Expected data URI or valid file path."
                )

            # Load image based on source type
            if image_source.startswith('data:'):
                # Parse data URI
                header, base64_data = image_source.split(',', 1)
                image_data = base64.b64decode(base64_data)
                image = Image.open(io.BytesIO(image_data))
            else:
                # Load from file path
                image = Image.open(image_source)

            with image:
                # Convert to RGB if needed
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                # Create a copy to avoid modifying original
                image_copy = image.copy()

                # Draw crosshair if coordinates provided
                if x is not None and y is not None:
                    draw = ImageDraw.Draw(image_copy)

                    # Draw crosshair (same style as core_agent.py)
                    crosshair_size = 8
                    line_width = 2

                    # White outline for visibility
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='white', width=line_width + 2)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='white', width=line_width + 2)

                    # Red crosshair on top
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='red', width=line_width)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='red', width=line_width)

                    logger.debug(f"Drew crosshair at ({x}, {y}) on {label} screenshot")

                # Convert to base64
                buffer = io.BytesIO()
                image_copy.save(buffer, format="JPEG", quality=95)
                encoded_string = base64.b64encode(buffer.getvalue()).decode("utf-8")

                return f"data:image/jpeg;base64,{encoded_string}"

        except FileNotFoundError:
            logger.error(f"Screenshot file not found: {image_source}")
            raise
        except Exception as e:
            logger.error(f"Error processing {label} screenshot: {e}")
            raise

    async def analyze_condition_compatibility(
        self,
        step: Step,
        current_screenshot_path: str
    ) -> Tuple[str, str]:
        """Analyze if current UI state is compatible with step execution.

        Args:
            step: Step object containing recorded screenshot and parameters
            current_screenshot_path: Path to current screenshot

        Returns:
            Tuple of (decision, explanation) where decision is one of:
            - "EXECUTE": Step can be safely executed
            - "WAIT": UI needs time to stabilize
            - "SKIP": UI state is incompatible
            - "ABORT": Serious UI issues require manual intervention

        Raises:
            ValueError: If step doesn't have required screenshot
            Exception: For API or processing errors
        """
        start_time = time.time()

        try:
            # Validate screenshot data exists and is valid
            if not step.screenshot:
                logger.warning(f"Step {step.step_id} has no recorded screenshot, allowing execution without comparison")
                return "EXECUTE", "No recorded screenshot available - allowing execution based on step definition only"

            if not is_valid_screenshot_data(step.screenshot):
                logger.warning(f"Step {step.step_id} has invalid screenshot data: '{step.screenshot[:50]}...', allowing execution without comparison")
                return "EXECUTE", f"Invalid recorded screenshot data (length: {len(step.screenshot)}) - allowing execution based on step definition only"

            logger.info(f"Analyzing condition compatibility for step {step.step_id}")

            # Perform preliminary pHash comparison to avoid unnecessary LLM calls
            try:
                # Load images for hash comparison (without crosshairs for accurate comparison)
                # Handle both data URI and file path for recorded screenshot
                if step.screenshot.startswith('data:'):
                    # Data URI format
                    _, base64_data = step.screenshot.split(',', 1)
                    recorded_image_data = base64.b64decode(base64_data)
                    recorded_img = Image.open(io.BytesIO(recorded_image_data))
                else:
                    # File path format
                    recorded_img = Image.open(step.screenshot)

                current_img = Image.open(current_screenshot_path)

                # Calculate perceptual hashes
                recorded_hash = imagehash.phash(recorded_img)
                current_hash = imagehash.phash(current_img)

                # Calculate Hamming distance
                hamming_distance = recorded_hash - current_hash

                logger.debug(f"pHash comparison - Hamming distance: {hamming_distance}")

                # If images are too different (Hamming distance > 40), skip LLM analysis
                if hamming_distance > 40:
                    logger.info(f"Screenshots too different (Hamming distance: {hamming_distance} > 40), skipping LLM analysis")
                    return "SKIP", f"Screenshots significantly different (pHash Hamming distance: {hamming_distance} > 40). UI state incompatible with recorded state."

                logger.debug(f"pHash similarity acceptable (Hamming distance: {hamming_distance} <= 40), proceeding with LLM analysis")

            except Exception as e:
                logger.warning(f"pHash comparison failed: {e}. Proceeding with LLM analysis as fallback.")

            await self._initialize_client()

            # Check if step has coordinates for crosshair indication
            has_coordinates = (step.parameters and
                             hasattr(step.parameters, 'x') and hasattr(step.parameters, 'y') and
                             step.parameters.x is not None and step.parameters.y is not None)

            x_coord = step.parameters.x if has_coordinates else None
            y_coord = step.parameters.y if has_coordinates else None

            # Prepare images with crosshairs if coordinates exist
            # Recorded screenshot can be either data URI or file path
            recorded_image = self._convert_to_base64_with_crosshair(
                step.screenshot, x_coord, y_coord, "recorded"
            )

            # Current screenshot is always a file path
            current_image = self._convert_to_base64_with_crosshair(
                current_screenshot_path, x_coord, y_coord, "current"
            )

            # Prepare the analysis prompt
            prompt = ConditionPromptTemplate.format_analysis_prompt(
                step=step,
                has_coordinates=has_coordinates
            )

            # Prepare input for the agent with clear image labels
            input_data = [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_text", "text": "**RECORDED SCREENSHOT** (when step was originally recorded):"},
                        {"type": "input_image", "image_url": recorded_image},
                        {"type": "input_text", "text": "**CURRENT SCREENSHOT** (current UI state):"},
                        {"type": "input_image", "image_url": current_image}
                    ]
                }
            ]

            # Execute analysis
            api_start = time.time()
            result = await self._runner.run(self._agent, input=input_data)
            api_duration = time.time() - api_start

            # Use structured output with validation
            try:
                analysis_result = result.final_output_as(ConditionAnalysisResult, raise_if_incorrect_type=True)
                decision = analysis_result.decision.upper()
                explanation = analysis_result.explanation
            except TypeError as e:
                logger.warning(f"Structured output validation failed: {str(e)}. Using fallback parsing.")
                # Fallback to string parsing if structured output fails
                response = str(result.final_output).strip()
                lines = response.split('\n', 1)
                decision = lines[0].strip().upper()
                explanation = lines[1].strip() if len(lines) > 1 else "No explanation provided"

            # Validate decision
            valid_decisions = ["EXECUTE", "WAIT", "SKIP", "ABORT"]
            if decision not in valid_decisions:
                logger.warning(f"Invalid decision '{decision}', defaulting to WAIT")
                decision = "WAIT"
                explanation = f"Invalid decision format. Decision: {decision}"

            # Log performance metrics
            total_duration = time.time() - start_time
            usage = result.context_wrapper.usage

            logger.info(f"Condition analysis for step {step.step_id}: {decision} ({total_duration:.2f}s, API: {api_duration:.2f}s, tokens: {usage.input_tokens}/{usage.output_tokens})")
            logger.debug(f"Analysis explanation: {explanation}")

            return decision, explanation

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Failed to analyze conditions for step {step.step_id} after {duration:.2f}s: {e}")
            # Return conservative decision on error
            return "WAIT", f"Condition analysis failed: {str(e)}"

    @classmethod
    async def check_step_compatibility(
        cls,
        step: Step,
        current_screenshot_path: str
    ) -> Tuple[str, str]:
        """Convenience method to check step compatibility with current UI state.

        Args:
            step: Step object containing recorded screenshot and parameters
            current_screenshot_path: Path to current screenshot

        Returns:
            Tuple of (decision, explanation)
        """
        agent = cls()
        return await agent.analyze_condition_compatibility(
            step, current_screenshot_path
        )
