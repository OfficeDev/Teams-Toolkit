#!/usr/bin/env python3
"""
Tag Processor

Handles processing of step tags for execution control and configuration.
Supports various tag formats like delay:X, force_run:true, etc.
"""

from typing import Any, Dict, List, Optional

from vscuse_v2.utils.logger import setup_logger

from .schema import Step

logger = setup_logger(__name__)


class TagProcessor:
    """
    Processes step tags to extract execution configuration and control directives.

    Supported tag formats:
    - delay:X - Adds a delay of X seconds before step execution
    - force_run:true - Skips preconditions and postconditions for the step
    - precondition_wait_timeout:X - Overrides precondition wait timeout for the step (seconds)
    """

    def __init__(self):
        """Initialize the tag processor."""
        self.supported_tags = {
            'delay': self._parse_delay_tag,
            'force_run': self._parse_force_run_tag,
            'precondition_wait_timeout': self._parse_precondition_wait_timeout_tag,
            'step_retry_timeout': self._parse_step_retry_timeout_tag,
            'store_fact': self._parse_store_fact_tag,
            'ocr': self._parse_ocr_tag,
            'precondition_intent': self._parse_precondition_intent_tag
        }

    def get_delay_seconds(self, step: Step) -> Optional[float]:
        """
        Extract delay value from step tags.

        Args:
            step: Step object with tags attribute

        Returns:
            Delay value in seconds, or None if no delay tag found
        """
        if not step.tags:
            return None

        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower().startswith("delay:"):
                try:
                    delay_value = tag.strip().lower().split("delay:")[1]
                    delay_seconds = float(delay_value)
                    logger.debug(f"Found delay tag for step {step.step_id}: {delay_seconds}s")
                    return delay_seconds
                except (IndexError, ValueError):
                    logger.warning(
                        f"Invalid delay tag format in step {step.step_id}: {tag}. "
                        f"Expected format: delay:X where X is a number"
                    )
                    continue

        return None

    def get_step_retry_timeout(self, step: Step) -> Optional[float]:
        """
        Extract step_retry_timeout value from step tags.

        Args:
            step: Step object with tags attribute

        Returns:
            Retry timeout value in seconds, or None if no step_retry_timeout tag found
        """
        if not step.tags:
            return None

        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower().startswith("step_retry_timeout:"):
                try:
                    timeout_value = tag.strip().lower().split("step_retry_timeout:")[1]
                    timeout_seconds = float(timeout_value)
                    if timeout_seconds < 0:
                        logger.warning(
                            f"Invalid step_retry_timeout value in step {step.step_id}: {timeout_seconds}. "
                            f"Must be non-negative. Ignoring tag."
                        )
                        continue
                    logger.debug(f"Found step_retry_timeout tag for step {step.step_id}: {timeout_seconds}s")
                    return timeout_seconds
                except (IndexError, ValueError):
                    logger.warning(
                        f"Invalid step_retry_timeout tag format in step {step.step_id}: {tag}. "
                        f"Expected format: step_retry_timeout:X where X is a non-negative number (seconds)"
                    )
                    continue

        return None

    def get_ocr_enabled(self, step: Step) -> bool:
        """
        Check if the step should use OCR to resolve x, y coordinates.

        Args:
            step: Step object with tags attribute

        Returns:
            True if step has ocr:true tag, False otherwise
        """
        if not step.tags:
            return False

        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower() == "ocr:true":
                logger.debug(f"Found ocr:true tag for step {step.step_id}")
                return True

        return False

    def get_store_fact(self, step: Step) -> Optional[str]:
        """
        Extract store_fact value from step tags.

        Args:
            step: Step object with tags attribute

        Returns:
            Fact name to store, or None if no store_fact tag found
        """
        if not step.tags:
            return None

        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower().startswith("store_fact:"):
                try:
                    fact_name = tag.strip().split("store_fact:")[1]
                    if fact_name:
                        logger.debug(f"Found store_fact tag for step {step.step_id}: {fact_name}")
                        return fact_name
                    else:
                        logger.warning(
                            f"Invalid store_fact tag format in step {step.step_id}: {tag}. "
                            f"Expected format: store_fact:fact_name"
                        )
                except IndexError:
                    logger.warning(
                        f"Invalid store_fact tag format in step {step.step_id}: {tag}. "
                        f"Expected format: store_fact:fact_name"
                    )
                    continue

        return None

    def get_precondition_intent(self, step: Step) -> Optional[str]:
        """
        Extract the precondition_intent value from step tags.

        The intent is a free-text hint describing what the step's precondition
        should verify (e.g., what screen/dialog/element must be present). It is
        passed to the OCR precondition LLM judge so it focuses on that intent
        rather than a generic whole-screen comparison. Only used by OCR
        (ocr:v1) preconditions.

        Format: ``precondition_intent:<free text>`` (the value may contain spaces
        and colons; its original case is preserved).

        Args:
            step: Step object with tags attribute

        Returns:
            The intent text, or None if no precondition_intent tag found
        """
        if not step.tags:
            return None

        prefix = "precondition_intent:"
        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower().startswith(prefix):
                stripped = tag.strip()
                value = stripped[len(prefix):].strip()
                if value:
                    logger.debug(f"Found precondition_intent tag for step {step.step_id}")
                    return value
                logger.warning(
                    f"Empty precondition_intent tag in step {step.step_id}: {tag}. "
                    f"Expected format: precondition_intent:<text>"
                )

        return None

    def should_force_run(self, step: Step) -> bool:
        """
        Check if step should be force-run (skip preconditions and postconditions).
        Args:
            step: Step object with tags attribute

        Returns:
            True if step has force_run:true tag, False otherwise
        """
        if not step.tags:
            return False

        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower() == "force_run:true":
                logger.debug(f"Found force_run tag for step {step.step_id}")
                return True

        return False

    def get_precondition_wait_timeout(self, step: Step) -> Optional[float]:
        """
        Extract precondition_wait_timeout value from step tags.

        Args:
            step: Step object with tags attribute

        Returns:
            Timeout value in seconds, or None if no precondition_wait_timeout tag found
        """
        if not step.tags:
            return None

        for tag in step.tags:
            if isinstance(tag, str) and tag.strip().lower().startswith("precondition_wait_timeout:"):
                try:
                    timeout_value = tag.strip().lower().split("precondition_wait_timeout:")[1]
                    timeout_seconds = float(timeout_value)
                    logger.debug(f"Found precondition_wait_timeout tag for step {step.step_id}: {timeout_seconds}s")
                    return timeout_seconds
                except (IndexError, ValueError):
                    logger.warning(
                        f"Invalid precondition_wait_timeout tag format in step {step.step_id}: {tag}. "
                        f"Expected format: precondition_wait_timeout:X where X is a number"
                    )
                    continue

        return None

    def extract_all_directives(self, step: Step) -> Dict[str, Any]:
        """
        Extract all tag directives from a step.

        Args:
            step: Step object with tags attribute

        Returns:
            Dictionary with all extracted directives:
            {
                'delay_seconds': Optional[float],
                'force_run': bool,
                'precondition_wait_timeout': Optional[float],
                'unknown_tags': List[str]  # Tags that couldn't be parsed
            }
        """
        directives = {
            'delay_seconds': None,
            'force_run': False,
            'precondition_wait_timeout': None,
            'step_retry_timeout': None,
            'store_fact': None,
            'ocr': False,
            'precondition_intent': None,
            'unknown_tags': []
        }

        if not step.tags:
            return directives

        # Process each tag
        for tag in step.tags:
            if not isinstance(tag, str):
                directives['unknown_tags'].append(str(tag))
                continue

            tag_lower = tag.strip().lower()

            # Check for delay tag
            if tag_lower.startswith("delay:"):
                if directives['delay_seconds'] is None:  # Only take first delay tag
                    directives['delay_seconds'] = self.get_delay_seconds(step)

            # Check for force_run tag
            elif tag_lower == "force_run:true":
                directives['force_run'] = True

            # Check for precondition_wait_timeout tag
            elif tag_lower.startswith("precondition_wait_timeout:"):
                if directives['precondition_wait_timeout'] is None:  # Only take first timeout tag
                    directives['precondition_wait_timeout'] = self.get_precondition_wait_timeout(step)

            # Check for step_retry_timeout tag
            elif tag_lower.startswith("step_retry_timeout:"):
                if directives['step_retry_timeout'] is None:  # Only take first retry timeout tag
                    directives['step_retry_timeout'] = self.get_step_retry_timeout(step)

            # Check for store_fact tag
            elif tag_lower.startswith("store_fact:"):
                if directives['store_fact'] is None:  # Only take first store_fact tag
                    directives['store_fact'] = self.get_store_fact(step)

            # Check for ocr tag
            elif tag_lower == "ocr:true":
                directives['ocr'] = True

            # Check for precondition_intent tag
            elif tag_lower.startswith("precondition_intent:"):
                if directives['precondition_intent'] is None:  # Only take first intent tag
                    directives['precondition_intent'] = self.get_precondition_intent(step)

            # Unknown tag format
            else:
                directives['unknown_tags'].append(tag)

        return directives

    def _parse_delay_tag(self, tag_value: str) -> Optional[float]:
        """
        Parse a delay tag value.

        Args:
            tag_value: The value part of delay:X tag

        Returns:
            Delay in seconds, or None if invalid
        """
        try:
            return float(tag_value)
        except (ValueError, TypeError):
            return None

    def _parse_force_run_tag(self, tag_value: str) -> bool:
        """
        Parse a force_run tag value.

        Args:
            tag_value: The value part of force_run:X tag

        Returns:
            True if tag_value indicates force run, False otherwise
        """
        return tag_value.lower().strip() == "true"

    def _parse_precondition_wait_timeout_tag(self, tag_value: str) -> Optional[float]:
        """
        Parse a precondition_wait_timeout tag value.

        Args:
            tag_value: The value part of precondition_wait_timeout:X tag

        Returns:
            Timeout in seconds, or None if invalid
        """
        try:
            return float(tag_value)
        except (ValueError, TypeError):
            return None

    def _parse_step_retry_timeout_tag(self, tag_value: str) -> Optional[float]:
        """
        Parse a step_retry_timeout tag value.

        Args:
            tag_value: The value part of step_retry_timeout:X tag

        Returns:
            Retry timeout in seconds, or None if invalid
        """
        try:
            timeout_seconds = float(tag_value)
            return timeout_seconds if timeout_seconds >= 0 else None
        except (ValueError, TypeError):
            return None

    def _parse_store_fact_tag(self, tag_value: str) -> Optional[str]:
        """
        Parse a store_fact tag value.

        Args:
            tag_value: The value part of store_fact:fact_name tag

        Returns:
            Fact name string, or None if invalid
        """
        if tag_value and isinstance(tag_value, str) and tag_value.strip():
            return tag_value.strip()
        return None

    def _parse_ocr_tag(self, tag_value: str) -> bool:
        """
        Parse an ocr tag value.

        Args:
            tag_value: The value part of ocr:X tag

        Returns:
            True if tag_value is "true", False otherwise
        """
        return tag_value.lower().strip() == "true"

    def _parse_precondition_intent_tag(self, tag_value: str) -> Optional[str]:
        """
        Parse a precondition_intent tag value.

        Args:
            tag_value: The value part of precondition_intent:<text> tag

        Returns:
            The intent text, or None if empty
        """
        if tag_value and isinstance(tag_value, str) and tag_value.strip():
            return tag_value.strip()
        return None

    def validate_tags(self, step: Step) -> Dict[str, List[str]]:
        """
        Validate all tags in a step and report any issues.

        Args:
            step: Step object with tags attribute

        Returns:
            Dictionary with validation results:
            {
                'valid': List[str],    # Valid tags
                'invalid': List[str],  # Invalid tags with issues
                'warnings': List[str]  # Warning messages
            }
        """
        result = {
            'valid': [],
            'invalid': [],
            'warnings': []
        }

        if not step.tags:
            return result

        for tag in step.tags:
            if not isinstance(tag, str):
                result['invalid'].append(str(tag))
                result['warnings'].append(f"Non-string tag found: {tag}")
                continue

            tag_lower = tag.strip().lower()

            # Validate delay tag
            if tag_lower.startswith("delay:"):
                try:
                    delay_value = tag_lower.split("delay:")[1]
                    float(delay_value)
                    result['valid'].append(tag)
                except (IndexError, ValueError):
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid delay tag format: {tag}")

            # Validate force_run tag
            elif tag_lower.startswith("force_run:"):
                if tag_lower == "force_run:true":
                    result['valid'].append(tag)
                else:
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid force_run tag format: {tag} (should be 'force_run:true')")

            # Validate precondition_wait_timeout tag
            elif tag_lower.startswith("precondition_wait_timeout:"):
                try:
                    timeout_value = tag_lower.split("precondition_wait_timeout:")[1]
                    float(timeout_value)
                    result['valid'].append(tag)
                except (IndexError, ValueError):
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid precondition_wait_timeout tag format: {tag}")

            # Validate step_retry_timeout tag
            elif tag_lower.startswith("step_retry_timeout:"):
                try:
                    timeout_value = tag_lower.split("step_retry_timeout:")[1]
                    timeout_seconds = float(timeout_value)
                    if timeout_seconds < 0:
                        result['invalid'].append(tag)
                        result['warnings'].append(f"Invalid step_retry_timeout value: {tag} (must be non-negative)")
                    else:
                        result['valid'].append(tag)
                except (IndexError, ValueError):
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid step_retry_timeout tag format: {tag}")

            # Validate store_fact tag
            elif tag_lower.startswith("store_fact:"):
                try:
                    fact_name = tag.strip().split("store_fact:")[1]
                    if fact_name.strip():
                        result['valid'].append(tag)
                    else:
                        result['invalid'].append(tag)
                        result['warnings'].append(f"Invalid store_fact tag format: {tag} (fact_name cannot be empty)")
                except IndexError:
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid store_fact tag format: {tag}")

            # Validate ocr tag
            elif tag_lower.startswith("ocr:"):
                if tag_lower == "ocr:true":
                    result['valid'].append(tag)
                else:
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid ocr tag format: {tag} (should be 'ocr:true')")

            # Validate precondition_intent tag
            elif tag_lower.startswith("precondition_intent:"):
                if tag.strip()[len("precondition_intent:"):].strip():
                    result['valid'].append(tag)
                else:
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Invalid precondition_intent tag: {tag} (text cannot be empty)")

            # Unknown but potentially valid tag format
            else:
                if ":" in tag:
                    result['valid'].append(tag)  # Assume key:value format is valid
                else:
                    result['invalid'].append(tag)
                    result['warnings'].append(f"Unrecognized tag format: {tag}")

        return result

    @staticmethod
    def get_supported_tag_formats() -> List[str]:
        """
        Get list of supported tag formats.

        Returns:
            List of supported tag format descriptions
        """
        return [
            "delay:X - Add delay of X seconds before step execution",
            "force_run:true - Skip preconditions and postconditions for this step",
            "precondition_wait_timeout:X - Override precondition wait timeout for this step (seconds)",
            "step_retry_timeout:X - Override retry timeout for this step in seconds (retries until timeout reached)",
            "store_fact:fact_name - Store execution result as a fact (code agent only)",
            "ocr:true - Use Azure Computer Vision OCR to resolve x,y coordinates from step description",
            "precondition_intent:<text> - Hint for the OCR precondition LLM judge describing what to verify"
        ]
