#!/usr/bin/env python3
"""
Planner

Converts raw interaction recordings into the new executable plan schema format.
Generate structured plans with agents, tools, and content references.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional

from vscuse_v2.core.schema import AgentType, ExecutablePlan, ExecutionContext, PlanDescription, PlanMetadata, PlanVersion, Step, ToolParameters
from vscuse_v2.utils.id_generator import generate_step_id
from vscuse_v2.utils.image_tool import convert_image_to_data_uri
from vscuse_v2.utils.logger import setup_logger

from .core_agent import CoreAgent
from .ocr_text import OcrConfigError, encode_ocr_precondition, extract_ocr_text, get_image_viewport
from .validator import generate_condition

logger = setup_logger(__name__)


class Planner:
    """Generates executable plans from interaction recordings using the new schema."""

    def __init__(self, recording_path: Optional[Path] = None):
        """Initialize the enhanced planner.

        Args:
            recording_path: Path to the recording file. Can be set later with set_recording_path().
        """
        self.recording_path = recording_path
        self.step_counter = 0

        # Tool mappings from interaction types to schema tools
        self.interaction_to_tool = {
            "click_left": ("click", AgentType.INTERACTION),
            "click_right": ("click", AgentType.INTERACTION),
            "click_middle": ("click", AgentType.INTERACTION),
            "type_text": ("type_text", AgentType.INTERACTION),
            "keyboard_shortcut": ("keyboard_shortcut", AgentType.INTERACTION),
            "key_press": ("key_press", AgentType.INTERACTION),
            "hover": ("hover", AgentType.INTERACTION),
            "scroll": ("scroll", AgentType.INTERACTION),
        }

    def set_recording_path(self, recording_path: Path) -> None:
        """Set the recording path for this planner instance."""
        self.recording_path = recording_path
        self.step_counter = 0  # Reset step counter when changing recording

    def load_recording(self) -> Dict:
        """Load recording data from JSON file and convert screenshot paths to local paths."""
        if not self.recording_path:
            raise ValueError("Recording path not set. Use set_recording_path() or pass recording_path in constructor.")

        try:
            with open(self.recording_path, 'r', encoding='utf-8') as f:
                recording_data = json.load(f)

            # Convert screenshot paths to local paths
            home = Path.home()

            # Convert top-level screenshot_dir if present
            if "screenshot_dir" in recording_data and recording_data["screenshot_dir"]:
                original_path = recording_data["screenshot_dir"]
                local_path = home / ".vscuse" / original_path.lstrip("/")
                recording_data["screenshot_dir"] = str(local_path)

            # Convert recording_dir if present
            if "recording_dir" in recording_data and recording_data["recording_dir"]:
                original_path = recording_data["recording_dir"]
                local_path = home / ".vscuse" / original_path.lstrip("/")
                recording_data["recording_dir"] = str(local_path)

            # Convert screenshot paths in interactions
            if "interactions" in recording_data:
                for interaction in recording_data["interactions"]:
                    # Convert screenshot path (simplified format)
                    if "screenshot" in interaction and interaction["screenshot"]:
                        original_path = interaction["screenshot"]
                        local_path = home / ".vscuse" / original_path.lstrip("/")
                        interaction["screenshot"] = str(local_path)

            logger.info(f"Converted screenshot paths to local paths using {home}/.vscuse prefix")
            return recording_data

        except Exception as e:
            logger.error(f"Error loading recording: {e}")
            raise

    def merge_continuous_type_text(self, interactions: List[Dict]) -> List[Dict]:
        """Merge continuous type_text interactions and editing sequences into single type_text interactions."""
        if not interactions:
            return interactions

        merged = []
        i = 0

        while i < len(interactions):
            current = interactions[i]

            # If this is a type_text action or editing-related key_press, look for editing sequences
            if current.get("action") in ["type_text", "key_press"]:
                merged_interaction, consumed = self.merge_editing_sequence(interactions, i)
                merged.append(merged_interaction)
                i += consumed
            else:
                # Not an editing action, add as-is
                merged.append(current)
                i += 1

        logger.info(f"Merged {len(interactions)} interactions into {len(merged)} (saved {len(interactions) - len(merged)} editing merges)")
        return merged

    def merge_editing_sequence(self, interactions: List[Dict], start_idx: int) -> tuple[Dict, int]:
        """Merge a sequence of editing operations into a single type_text interaction.

        Args:
            interactions: List of all interactions
            start_idx: Starting index of the sequence

        Returns:
            Tuple of (merged_interaction, number_of_consumed_interactions)
        """
        editing_actions = {"type_text", "key_press"}
        editing_keys = {"backspace", "delete", "space"}

        current = interactions[start_idx]

        # Start building the final text result
        if current.get("action") == "type_text":
            final_text = current.get("text", "")
        else:
            # Starting with a key_press - check what kind of key
            key = current.get("key", "")
            if key not in editing_keys:
                # Not an editing key, return as-is
                return current, 1

            # Handle specific editing keys
            if key == "space":
                final_text = " "
            else:
                # For backspace/delete, start with empty text
                final_text = ""

        start_timestamp = current.get("timestamp")
        last_screenshot = current.get("screenshot")  # Use simplified screenshot field

        # Look ahead for more editing actions
        i = start_idx + 1
        consumed = 1

        while i < len(interactions):
            next_interaction = interactions[i]
            next_action = next_interaction.get("action")

            # Check if next interaction is part of editing sequence
            if next_action not in editing_actions:
                break

            if next_action == "type_text":
                # Add text content
                text_to_add = next_interaction.get("text", "")
                final_text += text_to_add
            elif next_action == "key_press":
                key = next_interaction.get("key", "")
                if key == "backspace":
                    # Remove last character if possible
                    if final_text:
                        final_text = final_text[:-1]
                elif key == "delete":
                    # For delete, we simulate removing next character (simplified)
                    # In real scenarios, this would depend on cursor position
                    pass
                elif key == "space":
                    # Convert space key press to space character
                    final_text += " "
                elif key in editing_keys:
                    # Other editing keys (if any added in the future)
                    pass
                else:
                    # Not an editing key, stop merging
                    break
            else:
                # Unknown action in editing context, stop merging
                break

            # Update screenshot to get the final result
            if next_interaction.get("screenshot"):
                last_screenshot = next_interaction.get("screenshot")

            i += 1
            consumed += 1

        # Create merged interaction as type_text
        merged_interaction = current.copy()
        merged_interaction["action"] = "type_text"
        merged_interaction["text"] = final_text
        merged_interaction["timestamp"] = start_timestamp
        merged_interaction["screenshot"] = last_screenshot  # Use simplified screenshot field

        # Add metadata about the merge
        merged_interaction["merged_count"] = consumed
        merged_interaction["original_action"] = current.get("action")

        return merged_interaction, consumed

    def convert_paste_shortcuts(self, interaction: Dict) -> Dict:
        """Convert paste shortcuts to type_text actions when clipboard text is available.

        Args:
            interaction: The interaction dictionary to potentially convert

        Returns:
            Dict: The original interaction or a converted type_text interaction
        """
        action = interaction.get("action", "unknown")

        # Check if this is a paste shortcut with text available - convert to type_text
        if action == "keyboard_shortcut":
            key = interaction.get("key", "")
            text = interaction.get("text")
            if self.is_paste_shortcut(key) and text:
                # Convert paste shortcut to type_text action
                converted_interaction = interaction.copy()
                converted_interaction["action"] = "type_text"
                logger.info(f"Converting paste shortcut '{key}' to type_text with content: '{text[:3]}{'...' if len(text) > 3 else ''}'")
                return converted_interaction

        # Return original interaction if no conversion needed
        return interaction

    def process_interactions(self, interactions: List[Dict]) -> List[Dict]:
        """Process interactions by applying various transformations.

        Args:
            interactions: List of interaction dictionaries to process

        Returns:
            List[Dict]: List of processed interaction dictionaries
        """
        processed = []

        for interaction in interactions:
            # Convert paste shortcuts to type_text actions
            processed_interaction = self.convert_paste_shortcuts(interaction)

            # Add any additional processing here in the future
            # For example: normalize coordinates, validate actions, etc.

            processed.append(processed_interaction)

        return processed

    def generate_postcondition(self, screenshot_path: Path) -> List[str]:
        """
        Generate postcondition strings from a screenshot file path using both dHash and pHash with tolerance.

        Args:
            screenshot_path: Path to the screenshot file

        Returns:
            A list of postcondition strings with dHash and pHash tolerance or empty list if unable to generate
        """
        # TODO: Implement postcondition generation later
        return []

    def generate_ocr_precondition(self, interaction: Dict) -> Optional[List[str]]:
        """Build an ``ocr:v1:`` precondition by OCRing the recorded screenshot.

        Returns a single-element list, or None if OCR is unavailable / the screen
        has no text, so the caller can degrade to legacy hash preconditions.
        """
        screenshot = interaction.get("screenshot")
        if not screenshot:
            return None

        screenshot_path = Path(screenshot)
        if not screenshot_path.exists():
            logger.warning(f"OCR precondition: screenshot not found: {screenshot_path}")
            return None

        try:
            full_text = extract_ocr_text(screenshot_path)
        except OcrConfigError as e:
            logger.warning(f"OCR precondition unavailable ({e}); falling back to hash preconditions")
            return None
        except Exception as e:  # noqa: BLE001 - degrade gracefully on any OCR error
            logger.warning(f"OCR precondition generation failed ({e}); falling back to hash preconditions")
            return None

        if not full_text.strip():
            logger.info("OCR precondition: no text detected on screen; falling back to hash preconditions")
            return None

        viewport = get_image_viewport(screenshot_path)
        x, y = interaction.get("x"), interaction.get("y")
        target = {"x": int(x), "y": int(y)} if x is not None and y is not None else None
        return [encode_ocr_precondition(full_text, viewport=viewport, target=target)]

    def generate_precondition(self, interaction: Dict) -> List[str]:
        """
        Simple and robust three-level precondition generation.
        Args:
            interaction: The interaction dictionary containing screenshot info and coordinates

        Returns:
            List of precondition strings for validation
        """
        preconditions = []

        try:
            screenshot = interaction.get("screenshot")
            if not screenshot:
                logger.debug("No screenshot found in interaction")
                return preconditions

            screenshot_path = Path(screenshot)
            if not screenshot_path.exists():
                logger.error(f"Screenshot file not found: {screenshot_path}")
                return preconditions

            x, y = interaction.get("x"), interaction.get("y")
            action = interaction.get("action", "unknown")

            if x is not None and y is not None:
                # Level 1: Small spot (16px, tolerance=5) - Must be precise
                small_condition = generate_condition(screenshot_path, x, y, "dhash", size=16, tolerance=5)
                if small_condition:
                    preconditions.append(small_condition)

                # Level 2: Medium spot (96px, tolerance=5) - UI element check
                medium_condition = generate_condition(screenshot_path, x, y, "dhash", size=96, tolerance=5)
                if medium_condition:
                    preconditions.append(medium_condition)

                # Level 3: Full screen (tolerance=10) - Overall context
                full_condition = generate_condition(screenshot_path, x, y, "dhash", size=0, tolerance=10)
                if full_condition:
                    preconditions.append(full_condition)

                logger.debug(f"Generated {len(preconditions)} preconditions for {action} at ({x}, {y})")
            else:
                # Fallback: full screen only
                center_x, center_y = 512, 384
                full_condition = generate_condition(screenshot_path, center_x, center_y, "dhash", size=0, tolerance=20)
                if full_condition:
                    preconditions.append(full_condition)

            return preconditions

        except Exception as e:
            logger.error(f"Error generating preconditions: {e}")
            return preconditions

    def convert_interaction_to_step(self, interaction: Dict) -> Step:
        """Convert a single interaction to a Step with preconditions and postconditions."""

        action = interaction.get("action", "unknown")

        # Map to tool and agent type
        tool_name, agent_type = self.interaction_to_tool.get(action, ("custom_action", AgentType.CODE))

        # Create parameters with only relevant fields
        params_dict = {}

        if action in ["click_left", "click_right", "click_middle"]:
            params_dict.update({
                "x": interaction.get("x"),
                "y": interaction.get("y"),
                "button": action.split("_")[1] if "_" in action else "left"
            })
        elif action == "type_text":
            params_dict["text"] = interaction.get("text", "")
        elif action == "keyboard_shortcut":
            params_dict["keys"] = interaction.get("key", "")
        elif action == "key_press":
            params_dict["key"] = interaction.get("key", "")
        elif action == "hover":
            params_dict.update({
                "x": interaction.get("x"),
                "y": interaction.get("y")
            })

        # Create ToolParameters
        params = ToolParameters(**params_dict)

        # Agent type: use the mapped agent type from interaction
        agent = agent_type

        # Generate description
        description = self.generate_description(interaction)

        self.step_counter += 1

        # Generate preconditions from screenshot.
        # Primary: OCR-based (ocr:v1:) precondition; degrade to legacy hash on failure.
        preconditions = []
        if agent_type == AgentType.INTERACTION:
            screenshot_path_str = interaction.get("screenshot")
            if screenshot_path_str:
                ocr_preconditions = self.generate_ocr_precondition(interaction)
                if ocr_preconditions:
                    preconditions.extend(ocr_preconditions)
                    logger.debug(f"Generated OCR precondition for step_{self.step_counter:03d}")
                else:
                    # Fallback: legacy three-level dhash preconditions
                    generated_preconditions = self.generate_precondition(interaction)
                    if generated_preconditions:
                        preconditions.extend(generated_preconditions)
                        logger.debug(f"Generated {len(generated_preconditions)} hash preconditions for step_{self.step_counter:03d}")

        # Generate postconditions - for now, disabled since we simplified to single screenshot
        postconditions = []
        # Note: With simplified screenshot approach, we no longer have after screenshots
        # Postconditions would need to be generated differently or omitted

        # Create step with preconditions
        step = Step(
            step_id=generate_step_id(),
            agent=agent,
            tool=tool_name,
            parameters=params,
            description=description,
            preconditions=preconditions,
            postconditions=postconditions,
            timeout=30.0,
            tags=[],
            screenshot=interaction.get("screenshot")  # Use simplified screenshot field
        )

        return step

    def generate_description(self, interaction: Dict) -> str:
        """Generate a human-readable description for the step."""
        action = interaction.get("action", "unknown")

        if action == "click_left":
            return f"Click at position ({interaction.get('x')}, {interaction.get('y')})"
        elif action == "type_text":
            return f"Type text: '{interaction.get('text', '')}'"
        elif action == "keyboard_shortcut":
            return f"Use keyboard shortcut: {interaction.get('key', '')}"
        elif action == "key_press":
            return f"Press key: {interaction.get('key', '')}"
        else:
            return f"Execute {action}"

    def is_paste_shortcut(self, key: str) -> bool:
        """Check if the key combination is a paste shortcut."""
        if not key:
            return False

        paste_shortcuts = {'ctrl+v', 'cmd+v', 'shift+insert'}
        return key.lower() in paste_shortcuts

    async def generate_plan(self, recording_path: Optional[Path] = None, output_path: Optional[Path] = None) -> ExecutablePlan:
        """Generate a simple plan from a recording with merged type_text.

        Args:
            recording_path: Path to the recording file. If not provided, uses the instance's recording_path.
            output_path: Optional output path for the generated plan.
        """
        # Set recording path if provided, or use instance's recording path
        if recording_path:
            self.set_recording_path(recording_path)
        elif not self.recording_path:
            raise ValueError("No recording path provided. Set recording_path in constructor or pass it to generate_plan().")

        logger.info(f"Generating simple plan from: {self.recording_path.name}")

        # Load recording
        recording_data = self.load_recording()
        interactions = recording_data.get("interactions", [])

        if not interactions:
            logger.warning("No interactions found in recording")
            interactions = []

        # Merge continuous type_text interactions and editing sequences
        merged_interactions = self.merge_continuous_type_text(interactions)
        logger.info(f"Merged interactions: {len(interactions)} -> {len(merged_interactions)}")

        # Process interactions (convert paste shortcuts, etc.)
        processed_interactions = self.process_interactions(merged_interactions)
        logger.info(f"Processed {len(processed_interactions)} interactions")

        # Convert each processed interaction directly to a step
        steps = []
        for interaction in processed_interactions:
            step = self.convert_interaction_to_step(interaction)
            steps.append(step)

        # Enhance step descriptions using AI vision analysis
        if steps:
            try:
                logger.info(f"Enhancing descriptions for {len(steps)} steps using AI vision analysis")
                enhanced_descriptions = await CoreAgent.enhance_step_description(steps)

                # Update step descriptions with enhanced versions
                for step in steps:
                    if step.step_id in enhanced_descriptions:
                        step.description = enhanced_descriptions[step.step_id]
                        logger.debug(f"Enhanced description for {step.step_id}")

                logger.info(f"Successfully enhanced descriptions for {len(enhanced_descriptions)} steps")
            except Exception as e:
                logger.warning(f"Failed to enhance step descriptions: {e}")
                logger.info("Proceeding with original descriptions")

        # Convert screenshot file paths to data URIs for portability
        logger.info("Converting screenshot file paths to data URIs...")
        for step in steps:
            if step.screenshot and not step.screenshot.startswith("data:"):
                try:
                    step.screenshot = convert_image_to_data_uri(step.screenshot)
                    logger.debug(f"Converted screenshot for step {step.step_id} to data URI")
                except Exception as e:
                    logger.warning(f"Failed to convert screenshot for step {step.step_id}: {e}")
        logger.info(f"Processed {len(steps)} steps for screenshot conversion")

        metadata = PlanMetadata(
            plan_id=f"plan_{self.recording_path.stem}",
            name=f"{self.recording_path.stem}",
            description=PlanDescription(
                owner="",
                workitem="",
                other=f"Generated from recording {recording_data.get('recording', 'unknown')}"
            ),
            version=PlanVersion.V1_1,
            execution_context=ExecutionContext(),
            execution_order=[step.step_id for step in steps],  # Set execution order based on step creation sequence
            tags=[]
        )

        # Create the complete plan
        plan = ExecutablePlan(
            plan_metadata=metadata,
            steps=steps
        )

        # Validate the plan
        errors = plan.validate_plan()
        if errors:
            logger.warning(f"Plan validation warnings: {errors}")

        # Save the plan
        if output_path is None:
            output_path = self.recording_path.parent / f"{self.recording_path.stem}_simple_plan.json"

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(plan.model_dump(exclude_none=True), f, indent=2, ensure_ascii=False, default=str)

        logger.info(f"Simple plan generated: {output_path}")
        logger.info(f"Plan contains {len(steps)} steps")

        return plan
