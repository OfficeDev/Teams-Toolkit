#!/usr/bin/env python3
"""
Interaction Agent

Handles UI interaction tasks using OpenAI Agents SDK with Computer interaction tools.
This agent can execute interaction tasks through natural language descriptions
or directly execute specific interaction tools.
"""

import json
import time
from typing import Any, Dict

from agents import Agent, OpenAIChatCompletionsModel, Runner, function_tool, set_tracing_disabled

from vscuse_v2.agent.base_agent import AgentExecutionResult, BaseAgent, CommonUtilities
from vscuse_v2.config.config_manager import get_azure_openai_config
from vscuse_v2.core.schema import Step
from vscuse_v2.docker.docker_client import DockerClient
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class InteractionAgentPromptTemplate:
    """Template for generating interaction agent prompts and instructions."""

    AGENT_INSTRUCTIONS = """
You are a UI interaction agent that can perform computer interactions like clicking, typing, scrolling, and keyboard shortcuts.

Available interaction tools:
- click(x, y, button="left"): Click at coordinates
- type_text(text): Type text at current cursor position
- keyboard_shortcut(keys): Execute keyboard shortcut (e.g., "ctrl+c", "alt+tab")
- key_press(key): Press a single key
- hover(x, y): Hover mouse at coordinates
- scroll(x=0, y=0, dx=0, dy=3): Scroll at position with deltas

IMPORTANT GUIDELINES:
1. Always use absolute coordinates for click and hover operations
2. For keyboard shortcuts, use standard format like "ctrl+c", "shift+tab", "alt+f4"
3. Be precise with text input - type exactly what is requested
4. Consider timing when needed - some operations may need delays
5. For complex interactions, break them down into simple steps

When given a task description, analyze what interactions are needed and execute them step by step.
Use the available tools to accomplish the goal efficiently.
"""


class InteractionAgent(BaseAgent):
    """UI interaction agent using OpenAI Agents SDK with Computer tools."""

    def __init__(self, docker_server_url: str = "http://localhost:6081", delay: float = 0.1):
        """
        Initialize InteractionAgent.

        Args:
            docker_server_url: URL of the Docker server with interaction API
            delay: Default delay between actions
        """
        super().__init__()
        self._docker_client = DockerClient(docker_server_url=docker_server_url)

    async def _setup_agent(self) -> None:
        """Setup the interaction agent with interaction tools."""

        azure_config = get_azure_openai_config()

        self._agent = Agent(
            name="InteractionAgent",
            instructions=InteractionAgentPromptTemplate.AGENT_INSTRUCTIONS,
            model=OpenAIChatCompletionsModel(
                model=azure_config.model,
                openai_client=self._client,
            ),
            tools=[
                self._create_click_tool(),
                self._create_type_text_tool(),
                self._create_keyboard_shortcut_tool(),
                self._create_key_press_tool(),
                self._create_hover_tool(),
                self._create_scroll_tool(),
            ],
        )
        self._runner = Runner()
        set_tracing_disabled(True)

    def _create_click_tool(self):
        """Create click tool for the agent."""
        @function_tool
        def click(x: int, y: int, button: str = "left") -> str:
            """
            Click at specified coordinates.

            Args:
                x: X coordinate to click
                y: Y coordinate to click
                button: Mouse button ("left", "right", "middle")

            Returns:
                Result of click operation
            """
            interaction_data = {"x": x, "y": y, "button": button}
            result = self._docker_client.click(interaction_data)

            logger.info(f"Click tool executed: x={x}, y={y}, button={button}")
            logger.info(f"Result: {result}")

            return json.dumps(result, indent=2)

        return click

    def _create_type_text_tool(self):
        """Create type text tool for the agent."""
        @function_tool
        def type_text(text: str) -> str:
            """
            Type text at current cursor position.

            Args:
                text: Text to type

            Returns:
                Result of type operation
            """
            interaction_data = {"text": text}
            result = self._docker_client.type_text(interaction_data)

            logger.info(f"Type text tool executed: text='{text}'")
            logger.info(f"Result: {result}")

            return json.dumps(result, indent=2)

        return type_text

    def _create_keyboard_shortcut_tool(self):
        """Create keyboard shortcut tool for the agent."""
        @function_tool
        def keyboard_shortcut(keys: str) -> str:
            """
            Execute keyboard shortcut.

            Args:
                keys: Keyboard shortcut (e.g., "ctrl+c", "alt+tab")

            Returns:
                Result of keyboard shortcut operation
            """
            interaction_data = {"key": keys}
            result = self._docker_client.keyboard_shortcut(interaction_data)

            logger.info(f"Keyboard shortcut tool executed: keys='{keys}'")
            logger.info(f"Result: {result}")

            return json.dumps(result, indent=2)

        return keyboard_shortcut

    def _create_key_press_tool(self):
        """Create key press tool for the agent."""
        @function_tool
        def key_press(key: str) -> str:
            """
            Press a single key.

            Args:
                key: Key to press

            Returns:
                Result of key press operation
            """
            interaction_data = {"key": key}
            result = self._docker_client.key_press(interaction_data)

            logger.info(f"Key press tool executed: key='{key}'")
            logger.info(f"Result: {result}")

            return json.dumps(result, indent=2)

        return key_press

    def _create_hover_tool(self):
        """Create hover tool for the agent."""
        @function_tool
        def hover(x: int, y: int) -> str:
            """
            Hover mouse at specified coordinates.

            Args:
                x: X coordinate to hover
                y: Y coordinate to hover

            Returns:
                Result of hover operation
            """
            interaction_data = {"x": x, "y": y}
            result = self._docker_client.hover(interaction_data)

            logger.info(f"Hover tool executed: x={x}, y={y}")
            logger.info(f"Result: {result}")

            return json.dumps(result, indent=2)

        return hover

    def _create_scroll_tool(self):
        """Create scroll tool for the agent."""
        @function_tool
        def scroll(x: int = 0, y: int = 0, dx: int = 0, dy: int = 3) -> str:
            """
            Scroll at specified position.

            Args:
                x: X coordinate for scroll center
                y: Y coordinate for scroll center
                dx: Horizontal scroll delta
                dy: Vertical scroll delta (positive = down, negative = up)

            Returns:
                Result of scroll operation
            """
            interaction_data = {"x": x, "y": y, "dx": dx, "dy": dy}
            result = self._docker_client.scroll(interaction_data)

            logger.info(f"Scroll tool executed: x={x}, y={y}, dx={dx}, dy={dy}")
            logger.info(f"Result: {result}")

            return json.dumps(result, indent=2)

        return scroll

    async def execute_task(self, step: Step) -> AgentExecutionResult:
        """
        Execute a UI interaction task based on step description.

        Args:
            step: Step object containing task description and other metadata

        Returns:
            AgentExecutionResult with execution details
        """
        await self._ensure_initialized()

        start_time = time.time()
        try:
            # Check if step has tool and parameters - if so, execute tool directly
            if hasattr(step, 'tool') and step.tool and hasattr(step, 'parameters') and step.parameters:
                logger.info(f"Step has tool '{step.tool}' and parameters - executing tool directly")
                tool_result = await self.execute_tool(step)

                # Log result with consideration for sensitive data
                if hasattr(step, '_has_env_vars') and step._has_env_vars:
                    logger.info("Tool execution completed with sensitive data handling")
                else:
                    logger.info(f"Tool execution result: {tool_result}")

                execution_time = time.time() - start_time

                # Convert tool result to AgentExecutionResult
                if isinstance(tool_result, dict):
                    success = tool_result.get("success", True)
                    raw_output = tool_result.get("output", tool_result)

                    # Convert output to string (handles both dict and string cases)
                    output = json.dumps(raw_output, indent=2) if isinstance(raw_output, dict) else str(raw_output)

                    if success:
                        return AgentExecutionResult.success_result(
                            result=output,
                            action="interaction_agent_tool",
                            execution_time=execution_time
                        )
                    else:
                        return AgentExecutionResult.error_result(
                            error=output,
                            action="interaction_agent_tool",
                            execution_time=execution_time
                        )
                else:
                    return AgentExecutionResult.success_result(
                        result=str(tool_result),
                        action="interaction_agent_tool",
                        execution_time=execution_time
                    )

            # Extract task description from step
            task_description = step.description or f"Execute {step.tool} tool"

            logger.info(f"Executing interaction task: {CommonUtilities.truncate_text(task_description)}")

            result = await Runner.run(starting_agent=self._agent, input=task_description)

            execution_time = time.time() - start_time
            logger.info(f"Task execution time: {execution_time:.2f} seconds")

            return AgentExecutionResult.success_result(
                result=result.final_output,
                action="interaction_agent",
                execution_time=execution_time
            )

        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Interaction agent execution failed: {str(e)}")
            return AgentExecutionResult.error_result(
                error=str(e),
                action="interaction_agent",
                execution_time=execution_time
            )

    async def execute_tool(self, step) -> Dict[str, Any]:
        """
        Execute a specific interaction tool directly from a step.

        Args:
            step: Step object containing tool name and parameters

        Returns:
            Dict with execution result
        """
        tool = step.tool
        params = step.parameters

        logger.info(f"Executing interaction tool: {tool}")

        # Log parameters with consideration for sensitive data
        if hasattr(step, '_has_env_vars') and step._has_env_vars:
            logger.info("Parameters contain sensitive data - not logged for security")
        else:
            logger.info(f"Parameters: {params}")

        start_time = time.time()

        try:
            if tool == "click":
                if params.x is None or params.y is None:
                    raise ValueError("Click tool requires x and y coordinates")

                interaction_data = {
                    "x": params.x,
                    "y": params.y,
                    "button": params.button or "left"
                }
                result = self._docker_client.click(interaction_data)

            elif tool == "type_text":
                if params.text is None:
                    raise ValueError("Type tool requires text parameter")

                interaction_data = {"text": params.text}
                result = self._docker_client.type_text(interaction_data)

            elif tool == "keyboard_shortcut":
                if params.keys is None:
                    raise ValueError("Keyboard shortcut tool requires keys parameter")

                interaction_data = {"key": params.keys}
                result = self._docker_client.keyboard_shortcut(interaction_data)

            elif tool == "key_press":
                if params.key is None:
                    raise ValueError("Key press tool requires key parameter")

                interaction_data = {"key": params.key}
                result = self._docker_client.key_press(interaction_data)

            elif tool == "hover":
                if params.x is None or params.y is None:
                    raise ValueError("Hover tool requires x and y coordinates")

                interaction_data = {
                    "x": params.x,
                    "y": params.y
                }
                result = self._docker_client.hover(interaction_data)

            elif tool == "scroll":
                interaction_data = {
                    "x": params.x or 0,
                    "y": params.y or 0,
                    "dx": params.custom.get("dx", 0),
                    "dy": params.custom.get("dy", -3 if params.custom.get("direction", "down") == "up" else 3)
                }
                result = self._docker_client.scroll(interaction_data)

            else:
                raise ValueError(f"Unknown interaction tool: {tool}")

            # Add execution metadata and return using common utilities
            execution_time = time.time() - start_time

            formatted_result = CommonUtilities.format_execution_result(
                success=True,
                output=result,
                execution_time=execution_time,
                tool=tool
            )

            logger.info(f"Tool execution completed in {execution_time:.2f} seconds")
            return formatted_result

        except Exception as e:
            execution_time = time.time() - start_time
            error_result = CommonUtilities.format_execution_result(
                success=False,
                output=str(e),
                execution_time=execution_time,
                tool=tool,
                exception_type=type(e).__name__
            )

            logger.error(f"Tool execution failed: {e}")
            return error_result

    async def cleanup(self):
        """Cleanup resources if needed."""
        logger.info("InteractionAgent cleanup completed")
        await super().cleanup()
