#!/usr/bin/env python3
"""
Base Agent Class and Common Utilities

Provides common functionality for all agent implementations, including shared utilities,
error messages, validation functions, and base agent class to reduce code duplication.
"""

import time
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from agents import set_tracing_disabled
from openai import AsyncAzureOpenAI
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class AgentExecutionResult(BaseModel, frozen=True):
    """Standardized result format for all agent executions."""
    success: bool
    result: Optional[str] = None
    error: Optional[str] = None
    action: str
    execution_time: Optional[float] = None
    timestamp: float
    additional_info: Dict[str, Any] = {}

    @classmethod
    def success_result(cls, result: str, action: str, execution_time: Optional[float] = None, **kwargs) -> "AgentExecutionResult":
        """Create a successful execution result."""
        return cls(
            success=True,
            result=result,
            action=action,
            execution_time=execution_time,
            timestamp=time.time(),
            additional_info=kwargs
        )

    @classmethod
    def error_result(cls, error: str, action: str, execution_time: Optional[float] = None, **kwargs) -> "AgentExecutionResult":
        """Create an error execution result."""
        return cls(
            success=False,
            error=error,
            action=action,
            execution_time=execution_time,
            timestamp=time.time(),
            additional_info=kwargs
        )


class CommonErrorMessages:
    """Common error messages used across multiple agents."""

    AUTHENTICATION_ERROR = "Authentication error: Please check your OpenAI API credentials and try again."
    NETWORK_ERROR = "Network error: Please check your internet connection and try again."
    RATE_LIMIT_ERROR = "Rate limit exceeded: Please wait a moment and try again."
    EMPTY_INPUT_ERROR = "Input cannot be empty"
    INITIALIZATION_ERROR = "Agent initialization failed - client or runner is None"
    INVALID_RESULT_ERROR = "Invalid result received from agent execution"

    @classmethod
    def get_formatted_error(cls, error_type: str, **kwargs) -> str:
        """Get formatted error message for specific error type."""
        templates = {
            "timeout": "Operation timed out. The operation may be taking too long to complete. "
                      "Please check your request and try again with a simpler task or increase the timeout.",
            "docker_command_failed": "Docker command failed with exit code {returncode}. "
                                   "This might indicate a Docker or container issue. "
                                   "Error details: {error_details}",
            "file_system_error": "File system error occurred. This might be due to missing files or "
                               "permission issues. Please ensure required files exist and are accessible.",
            "docker_error": "Docker-related error: {error_msg}. "
                          "Please check that Docker is running and the container is accessible.",
            "script_execution_error": "Script execution error: {error_msg}. "
                                    "Please check your script syntax and try again.",
            "unexpected_error": "An unexpected error occurred: {error_type} - {error_msg}"
        }

        template = templates.get(error_type, templates["unexpected_error"])
        return template.format(**kwargs)


class CommonValidators:
    """Common validation functions used across multiple agents."""

    @staticmethod
    def validate_non_empty_string(value: str, field_name: str = "input") -> None:
        """Validate that a string is not None or empty."""
        if not value or not value.strip():
            raise ValueError(f"{field_name.capitalize()} cannot be empty")

    @staticmethod
    def validate_timeout(timeout: int, min_timeout: int = 1, max_timeout: int = 300) -> None:
        """Validate timeout value is within acceptable range."""
        if timeout <= 0 or timeout > max_timeout:
            raise ValueError(f"Timeout must be between {min_timeout} and {max_timeout} seconds")


class CommonUtilities:
    """Common utility functions used across multiple agents."""

    @staticmethod
    def format_execution_result(success: bool, output: str, execution_time: float = None,
                              tool: str = None, **additional_info) -> Dict:
        """Format execution result in a consistent way across agents."""
        result = {
            "success": success,
            "output": output,
            "timestamp": __import__("time").time()
        }

        if execution_time is not None:
            result["execution_time"] = execution_time

        if tool:
            result["tool"] = tool

        result.update(additional_info)
        return result

    @staticmethod
    def truncate_text(text: str, max_length: int = 1000) -> str:
        """Truncate text for logging purposes."""
        if len(text) <= max_length:
            return text
        return text[:max_length] + "..."

class BaseAgent(ABC):
    """
    Base class for all agent implementations.

    Provides common functionality including:
    - Azure OpenAI client initialization
    - Agent setup patterns
    - Context manager support
    - Consistent error handling
    """

    def __init__(self):
        """Initialize base agent."""
        self._client: Optional[AsyncAzureOpenAI] = None
        self._agent = None
        self._runner = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        """Initialize the Azure OpenAI client."""
        if self._client is None:
            # Get configuration from config manager
            azure_config = get_azure_openai_config()
            self._use_azure_credential = azure_config.use_azure_credential

            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)
            logger.info(f"{self.__class__.__name__} Azure OpenAI client initialized")

    @abstractmethod
    async def _setup_agent(self) -> None:
        """Setup the specific agent implementation. Must be implemented by subclasses."""
        pass

    async def _ensure_initialized(self) -> None:
        """Ensure client and agent are initialized."""
        await self._initialize_client()
        if self._agent is None:
            await self._setup_agent()

    def _get_common_error_message(self, error: Exception) -> str:
        """
        Get user-friendly error message for common error types.

        Args:
            error: The exception that occurred

        Returns:
            User-friendly error message
        """
        error_str = str(error).lower()

        if "authentication" in error_str or "unauthorized" in error_str:
            return CommonErrorMessages.AUTHENTICATION_ERROR
        elif "network" in error_str or "connection" in error_str:
            return CommonErrorMessages.NETWORK_ERROR
        elif "rate limit" in error_str:
            return CommonErrorMessages.RATE_LIMIT_ERROR
        else:
            return f"An error occurred: {str(error)}"

    async def cleanup(self):
        """Cleanup resources. Can be overridden by subclasses."""
        logger.debug(f"{self.__class__.__name__} cleanup completed")
        pass

    async def __aenter__(self):
        """Context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        await self.cleanup()
