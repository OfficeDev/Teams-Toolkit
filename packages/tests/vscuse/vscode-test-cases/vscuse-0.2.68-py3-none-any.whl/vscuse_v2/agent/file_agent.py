import json
import os
import shutil
import time
from typing import Any, Dict, Optional

from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from agents.mcp import MCPServer, MCPServerStdio

from vscuse_v2.agent.base_agent import AgentExecutionResult, BaseAgent, CommonUtilities
from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class FileAgentPromptTemplate:
    """Template for generating file agent prompts and instructions."""

    AGENT_INSTRUCTIONS = """
Use the tools to read the filesystem and answer questions based on those files. Handle file operations efficiently and accurately.

IMPORTANT: All file paths must be absolute paths starting with /projects/ (e.g., /projects/filename.txt). Never use relative paths. The filesystem server only allows access to the /projects directory.
"""


class LoggingMCPServerWrapper:
    """Wrapper to log MCP tool calls"""
    def __init__(self, server: MCPServer):
        self.server = server

    def __getattr__(self, name):
        return getattr(self.server, name)

    async def call_tool(self, name: str, arguments: Dict[str, Any]):
        logger.info(f"MCP Tool Call: {name}")
        logger.info(f"Parameters: {json.dumps(arguments, indent=2)}")

        result = await self.server.call_tool(name, arguments)

        result_text = result.content[0].text if result.content else 'No content'
        logger.info(f"Tool Result: {result_text}")
        logger.info("-" * 50)

        return result


class FileAgent(BaseAgent):
    """Simple file operation agent using MCP"""

    def __init__(self, work_dir: Optional[str] = None):
        """Initialize FileAgent"""
        super().__init__()
        if work_dir is None:
            home_dir = os.path.expanduser("~")
            work_dir = os.path.join(home_dir, ".vscuse", "workspace")

        self.work_dir = work_dir
        self._mcp_server = None

        # Ensure directory exists
        os.makedirs(self.work_dir, exist_ok=True)

    async def _setup_agent(self) -> None:
        """Setup the file agent with MCP server."""
        # Check for docker availability
        if not shutil.which("docker"):
            raise RuntimeError("docker is not installed. Please install Docker to use the MCP filesystem server.")

        os.chdir(self.work_dir)
        logger.info(f"Changed working directory to: {os.getcwd()}")

        # Setup MCP server with Docker
        raw_server = MCPServerStdio(
            name="Filesystem Server, via Docker",
            params={
                "command": "docker",
                "args": [
                    "run",
                    "-i",
                    "--rm",
                    "--mount", f"type=bind,src={self.work_dir},dst=/projects",
                    "mcp/filesystem",
                    "/projects"
                ],
            },
            client_session_timeout_seconds=180,
        )

        await raw_server.__aenter__()
        self._mcp_server = LoggingMCPServerWrapper(raw_server)

        # Setup agent with Azure OpenAI model
        azure_config = get_azure_openai_config()

        self._agent = Agent(
            name="FileAgent",
            instructions=FileAgentPromptTemplate.AGENT_INSTRUCTIONS,
            model=OpenAIChatCompletionsModel(
                model=azure_config.model,
                openai_client=self._client,
            ),
            mcp_servers=[self._mcp_server],
        )
        set_tracing_disabled(True)

    async def execute_task(self, message: str) -> AgentExecutionResult:
        """Execute a file operation task"""
        await self._ensure_initialized()

        logger.info(f"Executing task: {CommonUtilities.truncate_text(message)}")
        start_time = time.time()

        try:
            result = await Runner.run(starting_agent=self._agent, input=message)
            execution_time = time.time() - start_time
            logger.info(f"Execution time: {execution_time:.2f} seconds")

            return AgentExecutionResult.success_result(
                result=result.final_output,
                action="file_agent",
                execution_time=execution_time
            )
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"File agent execution failed: {str(e)}")
            return AgentExecutionResult.error_result(
                error=str(e),
                action="file_agent",
                execution_time=execution_time
            )

    async def cleanup(self):
        """Cleanup resources"""
        if self._mcp_server and hasattr(self._mcp_server, 'server'):
            try:
                await self._mcp_server.server.__aexit__(None, None, None)
            except Exception as e:
                logger.warning(f"Error during cleanup: {e}")
        await super().cleanup()
