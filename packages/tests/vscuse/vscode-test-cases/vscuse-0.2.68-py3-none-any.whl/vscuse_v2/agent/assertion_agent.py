#!/usr/bin/env python3
"""
Assertion Agent using OpenAI Agents SDK
An agent that evaluates assertions (true/false statements) based on screenshot analysis.

This agent automatically takes screenshots from the Docker environment and leverages
the OpenAI Agents SDK's native structured output support by using the `output_type` parameter.
The SDK automatically:
- Generates JSON schema from the Pydantic model
- Uses OpenAI's structured output API for guaranteed valid JSON
- Parses the response into the specified type (AssertionResult)
- Handles validation and error cases with built-in utilities

The agent takes screenshots automatically using the Computer class, eliminating the need
for manual screenshot handling. Uses the SDK's `final_output_as()` method for robust
type validation and error handling of structured outputs.
"""

import asyncio
import base64
from time import time

from agents import Agent, OpenAIChatCompletionsModel, Runner
from pydantic import BaseModel

from vscuse_v2.agent.base_agent import AgentExecutionResult, BaseAgent, CommonErrorMessages, CommonValidators
from vscuse_v2.config import get_azure_openai_config, get_docker_config
from vscuse_v2.core.fact_store import FactStore
from vscuse_v2.docker.docker_client import DockerClient
from vscuse_v2.utils.image_tool import detect_loading_stability
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class AssertionAgentPromptTemplate:
    """Template for generating assertion agent prompts and instructions."""

    AGENT_INSTRUCTIONS = """
You are an assertion evaluation assistant specialized in analyzing screenshots. Your task is to determine whether given assertions about visual content are true or false based on what you can observe in provided images.

When evaluating assertions, you should:
1. Carefully examine the provided screenshot in detail
2. Consider the assertion description exactly as stated
3. Determine if the assertion is TRUE or FALSE based on your visual observations
4. Provide a confidence score between 0.0 (no confidence) and 1.0 (completely confident)
5. Give clear, detailed reasoning for your decision
6. Describe specific visual evidence that supports your conclusion

IMPORTANT GUIDELINES:
- Only evaluate what you can actually see and verify in the screenshot
- Be objective and precise in your assessment
- If something cannot be determined from the screenshot, clearly state this limitation
- Focus on observable visual elements, UI components, text, colors, layouts, etc.
- Provide specific details about what you observe to support your true/false conclusion

CHARACTER RECOGNITION RULES (CRITICAL for code/identifier assertions):
Many monospace and sans-serif fonts render visually-similar characters that are easy to confuse.
You MUST treat the following pairs/groups as commonly confused and verify them with context before concluding:
- Uppercase `I` (eye) vs. lowercase `l` (ell) vs. digit `1` vs. pipe `|`
- Uppercase `O` (oh) vs. digit `0` (zero) vs. lowercase `o`
- Lowercase `rn` vs. lowercase `m`
- Digit `5` vs. uppercase `S`; digit `2` vs. uppercase `Z`; digit `8` vs. uppercase `B`; digit `6` vs. uppercase `G`
- Lowercase `c` vs. `e`; lowercase `a` vs. `o`; lowercase `g` vs. `q`

When the assertion mentions a specific identifier, keyword, variable name, file name, URL, or any literal token:
1. Read the token character-by-character; do NOT auto-correct or "normalize" what you see.
2. If the on-screen text MATCHES the assertion exactly (allowing for the confusable characters above), treat it as a MATCH — do not fail the assertion just because the glyph could also look like a different character.
   For example, if the assertion says `APP_ID` and the screenshot shows `APP_ID`, return TRUE — do NOT claim it is actually `APP_lD` or `APP_1D`.
3. If a token in the assertion contains uppercase `I` (e.g. `ID`, `APP_ID`, `TENANTID`), assume uppercase `I` unless the surrounding casing clearly indicates lowercase `l`. Identifiers like `*_ID`, `*ID`, `ID_*` overwhelmingly use uppercase `I`.
4. Use surrounding context (variable casing convention, language syntax, neighboring identifiers) to disambiguate confusable glyphs.
5. Never report the same string twice as if it were two different strings (e.g. claiming `APP_TENANTID` differs from `APP_TENANTID`). If both spellings look identical when written out, they ARE identical.
6. If you are genuinely uncertain which character is rendered, state the ambiguity explicitly in `reasoning` and lower your confidence — do NOT silently pick the wrong one.

Your response must be in the structured format with these fields:
- assertion: The original assertion being evaluated
- result: Boolean true or false
- confidence: Float between 0.0 and 1.0
- reasoning: Detailed explanation of your decision process
- visual_evidence: Specific visual details you observed that support your conclusion
"""

    ERROR_MESSAGES = {
        "invalid_image": "Invalid image data provided. Please ensure the image is properly encoded.",
        "empty_assertion": "Assertion description cannot be empty.",
        "analysis_failed": "Failed to analyze the screenshot: {error_msg}",
        "unexpected_error": "An unexpected error occurred: {error_type} - {error_msg}"
    }

    @classmethod
    def get_error_message(cls, error_type: str, **kwargs) -> str:
        """Get formatted error message for specific error type."""
        template = cls.ERROR_MESSAGES.get(error_type, cls.ERROR_MESSAGES["unexpected_error"])
        return template.format(**kwargs)


class AssertionResult(BaseModel):
    """Structured result for assertion evaluation."""
    assertion: str
    result: bool
    confidence: float  # 0.0 to 1.0
    reasoning: str
    visual_evidence: str


class AssertionError(Exception):
    """Custom exception for assertion evaluation errors."""
    pass


class AssertionAgent(BaseAgent):
    """An assertion evaluation agent that can analyze screenshots and evaluate assertions."""

    def __init__(self, docker_server_url: str = None):
        """Initialize the assertion agent.

        Args:
            docker_server_url: URL of the Docker server for taking screenshots.
                              If None, will use configuration default.
        """
        super().__init__()

        # Use provided URL or get from configuration
        if docker_server_url is None:
            docker_config = get_docker_config()
            docker_server_url = docker_config.server_url

        self._docker_client = DockerClient(docker_server_url=docker_server_url)
        self._fact_store = FactStore()

    async def _setup_agent(self) -> None:
        """Setup the assertion agent with structured output."""
        azure_config = get_azure_openai_config()

        self._agent = Agent(
            name="AssertionAgent",
            instructions=AssertionAgentPromptTemplate.AGENT_INSTRUCTIONS,
            model=OpenAIChatCompletionsModel(
                model=azure_config.model,
                openai_client=self._client,
            ),
            output_type=AssertionResult
        )
        self._runner = Runner()
        logger.info(f"Assertion agent initialized successfully with model: {azure_config.model}")

    def _encode_image_file(self, file_path: str) -> str:
        """Encode an image file to base64."""
        try:
            with open(file_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
            return encoded_string
        except Exception as e:
            raise ValueError(f"Failed to encode image file: {str(e)}")

    def _take_screenshot(self) -> str:
        """Take a screenshot and return the file path.

        Returns:
            str: Path to the saved screenshot file

        Raises:
            RuntimeError: If screenshot operation fails
        """
        try:
            # Use DockerClient's built-in screenshot path generation
            screenshot_path_str = self._docker_client.take_screenshot()

            logger.debug(f"Screenshot taken for assertion evaluation: {screenshot_path_str}")
            return screenshot_path_str

        except Exception as e:
            error_msg = f"Failed to take screenshot: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

    async def evaluate_assertion(self, assertion_description: str) -> AssertionResult:
        """Evaluate an assertion based on a screenshot taken automatically.

        Args:
            assertion_description: The assertion to evaluate

        Returns:
            AssertionResult: The evaluation result

        Raises:
            ValueError: If input validation fails
            RuntimeError: If agent initialization or screenshot fails
            Exception: For other unexpected errors
        """
        CommonValidators.validate_non_empty_string(assertion_description, "assertion description")

        try:
            await self._ensure_initialized()

            if self._agent is None or self._runner is None:
                raise RuntimeError(CommonErrorMessages.INITIALIZATION_ERROR)

            logger.info(f"Evaluating assertion: {assertion_description}")

            # Get all available facts from fact store
            facts = self._fact_store.get_facts()

            # Take a screenshot automatically
            screenshot_path = self._docker_client.take_screenshot()
            logger.debug(f"Screenshot taken for assertion evaluation: {screenshot_path}")

            # Read and encode the screenshot
            image_b64 = self._encode_image_file(screenshot_path)
            image_url = f"data:image/png;base64,{image_b64}"

            # Build the assertion prompt with fact context
            assertion_prompt = f"Please evaluate this assertion about the screenshot: {assertion_description}"

            # If facts are available, include them in the prompt
            if facts:
                fact_context = "\n\nAvailable facts:"
                for fact_name, fact_value in facts.items():
                    fact_context += f"\n- {fact_name}: {fact_value}"
                assertion_prompt += fact_context
                logger.debug(f"Including {len(facts)} fact(s) in assertion prompt")

            # Create input with image and assertion
            input_data = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_image",
                            "detail": "high",
                            "image_url": image_url,
                        }
                    ],
                },
                {
                    "role": "user",
                    "content": assertion_prompt
                }
            ]

            logger.debug(f"Assertion prompt: {assertion_prompt}")
            result = await self._runner.run(self._agent, input=input_data)

            if not result or not hasattr(result, 'final_output'):
                raise RuntimeError(CommonErrorMessages.INVALID_RESULT_ERROR)

            # Use the SDK's built-in final_output_as() method to safely cast and validate the result
            try:
                evaluation_result = result.final_output_as(AssertionResult, raise_if_incorrect_type=True)
                logger.info(f"Assertion evaluation completed: {evaluation_result.result}")
                return evaluation_result
            except TypeError as e:
                # If type validation fails, create a fallback result
                logger.warning(f"Result type validation failed: {str(e)}. Final output type: {type(result.final_output)}")
                return AssertionResult(
                    assertion=assertion_description,
                    result=False,
                    confidence=0.1,
                    reasoning=f"Structured output validation failed: {str(e)}",
                    visual_evidence="Unable to parse structured response"
                )

        except ValueError:
            # Re-raise validation errors
            raise
        except Exception as e:
            error_msg = f"Error evaluating assertion: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(self._get_common_error_message(e))

    async def _wait_for_stable_screenshot(self, max_wait: float = 10.0) -> str:
        """Wait for screenshot to stabilize before assertion evaluation.

        Ensures the page/application is not loading or waiting for responses
        by detecting when the UI content has stopped changing significantly.
        Uses enhanced loading detection that ignores cursor blinking but catches loading states.

        Args:
            max_wait: Maximum time to wait for stability (seconds, capped at 10s)

        Returns:
            str: Path to the stable screenshot
        """
        stability_checks = 3    # Need 3 consecutive stable screenshots
        check_interval = 1.5    # Check every 1.5 seconds (slower for assertion accuracy)

        start_time = time()
        stable_count = 0
        previous_screenshot_path = None

        logger.debug(f"Waiting for UI stability - detecting loading/response states for assertion evaluation (max {max_wait}s)")

        while time() - start_time < max_wait:
            try:
                # Take screenshot
                screenshot_path = self._take_screenshot()

                # Compare with previous screenshot using enhanced loading detection
                if previous_screenshot_path is not None:
                    stability_ratio = detect_loading_stability(previous_screenshot_path, screenshot_path)

                    # Higher threshold for assertion evaluation (95% vs 90% in executor)
                    # Assertions need more stable UI state for accurate evaluation
                    if stability_ratio >= 0.95:
                        stable_count += 1
                        logger.debug(f"UI stable - no loading detected ({stable_count}/{stability_checks}, stability: {stability_ratio:.3f})")

                        if stable_count >= stability_checks:
                            elapsed = time() - start_time
                            logger.debug(f"UI stabilized - ready for assertion evaluation after {elapsed:.2f}s")
                            return screenshot_path
                    else:
                        # Significant UI changes detected - likely loading/processing
                        stable_count = 0
                        logger.debug(f"UI changing - loading/processing detected (stability: {stability_ratio:.3f})")

                previous_screenshot_path = screenshot_path
                await asyncio.sleep(check_interval)

            except Exception as e:
                logger.warning(f"Error during stability check: {str(e)}")
                # Fallback to basic screenshot if comparison fails
                return self._take_screenshot()

        # Timeout reached - assume UI is stable enough
        elapsed = time() - start_time
        logger.debug(f"UI stability timeout after {elapsed:.2f}s - proceeding with last capture for assertion evaluation")
        return self._take_screenshot()

    async def execute_task(self, task_message: str) -> AgentExecutionResult:
        """Execute an assertion task and return a standardized result.

        This method provides compatibility with other agents' execute_task interface.

        Args:
            task_message: The assertion description to evaluate

        Returns:
            AgentExecutionResult with the assertion evaluation results
        """
        import time
        start_time = time.time()

        try:
            # Wait for stable screenshot before evaluation
            await self._wait_for_stable_screenshot(max_wait=60.0)

            assertion_result = await self.evaluate_assertion(task_message)
            execution_time = time.time() - start_time

            result_text = (f"Assertion: {assertion_result.assertion}\n"
                          f"Result: {'TRUE' if assertion_result.result else 'FALSE'}\n"
                          f"Confidence: {assertion_result.confidence:.2%}\n"
                          f"Reasoning: {assertion_result.reasoning}")

            success = assertion_result.result and assertion_result.confidence >= 0.7

            if success:
                return AgentExecutionResult.success_result(
                    result=result_text,
                    action="assertion_agent",
                    execution_time=execution_time,
                    assertion_confidence=assertion_result.confidence,
                    assertion_outcome=assertion_result.result
                )
            else:
                return AgentExecutionResult.error_result(
                    error=result_text,
                    action="assertion_agent",
                    execution_time=execution_time,
                    assertion_confidence=assertion_result.confidence,
                    assertion_outcome=assertion_result.result
                )

        except Exception as e:
            execution_time = time.time() - start_time
            return AgentExecutionResult.error_result(
                error=str(e),
                action="assertion_agent",
                execution_time=execution_time
            )

    async def cleanup(self):
        """Cleanup resources"""
        await super().cleanup()
