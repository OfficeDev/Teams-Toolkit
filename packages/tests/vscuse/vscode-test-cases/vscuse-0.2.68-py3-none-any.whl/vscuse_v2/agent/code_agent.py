#!/usr/bin/env python3
"""
Code Agent using OpenAI Agents SDK
A simple agent that can execute scripts in a Docker container.
"""

import os
import subprocess
import tempfile
import time
from typing import Any, Dict

from agents import Agent, OpenAIChatCompletionsModel, RunContextWrapper, Runner, function_tool

from vscuse_v2.agent.base_agent import AgentExecutionResult, BaseAgent, CommonErrorMessages, CommonUtilities, CommonValidators
from vscuse_v2.config import get_azure_openai_config, get_docker_config
from vscuse_v2.core.fact_store import FactStore
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class CodeAgentPromptTemplate:
    """Template for generating code agent prompts and instructions."""

    AGENT_INSTRUCTIONS = """
You are a code execution assistant that runs scripts in a Ubuntu Docker container (/workspace).

CRITICAL: You MUST execute the script and return the formatted output. Do NOT explain or discuss - just execute and show results.

Process:
1. Write complete, syntactically correct scripts
2. Execute using execute_script tool ONCE
3. Return the COMPLETE tool output without any additional commentary

OUTPUT FORMAT (MANDATORY):
You must ONLY return the exact output from the execute_script tool, which includes:
- === Generated Script ===
- === Execution Results ===
- === STDOUT ===
- === STDERR ===
- Success/failure status

Do NOT add explanations before or after the tool output.
Do NOT summarize the results.
Do NOT provide suggestions unless the script fails.

Safety Rules (fix issues in code, don't explain them):
- NO infinite loops or unbounded iterations
- NO operations waiting for user input
- USE timeouts for network/long operations (maximum timeout is 300 seconds)
- VERIFY file paths exist before use
- Handle special characters properly in scripts

If you see a potential issue, FIX IT IN THE CODE and execute. Only explain if execution fails.
"""

    AGENT_INSTRUCTIONS_WITH_SAMPLE = """
You are a code execution assistant that runs scripts in a Ubuntu Docker container (/workspace).

CRITICAL: You MUST execute the script and return the formatted output. Do NOT explain or discuss - just execute and show results.

REFERENCE SAMPLE FROM PREVIOUS SUCCESS:
The following is a successful execution from a similar task. Use it as a reference and adapt it to the current requirements:

{sample}

Process:
1. Study the reference sample above - it worked successfully before
2. Adapt the approach to current task requirements
3. Write complete, syntactically correct scripts
4. Execute using execute_script tool ONCE
5. Return the COMPLETE tool output without any additional commentary

OUTPUT FORMAT (MANDATORY):
You must ONLY return the exact output from the execute_script tool, which includes:
- === Generated Script ===
- === Execution Results ===
- === STDOUT ===
- === STDERR ===
- Success/failure status

Do NOT add explanations before or after the tool output.
Do NOT summarize the results.
Do NOT provide suggestions unless the script fails.

Safety Rules (fix issues in code, don't explain them):
- NO infinite loops or unbounded iterations
- NO operations waiting for user input
- USE timeouts for network/long operations (maximum timeout is 300 seconds)
- VERIFY file paths exist before use
- Handle special characters properly in scripts

Follow the patterns from the reference sample. If you see a potential issue, FIX IT IN THE CODE and execute. Only explain if execution fails.
"""

    SCRIPT_EXECUTION_ERROR_MESSAGES = {
        "timeout": (
            "Script execution timed out. The script may be taking too long to complete or "
            "might be stuck in an infinite loop. Please check your code and try again with "
            "a simpler script or increase the timeout."
        ),
        "docker_command_failed": (
            "Docker command failed with exit code {returncode}. "
            "This might indicate a Docker or container issue. "
            "Error details: {error_details}"
        ),
        "file_system_error": (
            "File system error occurred. This might be due to missing files or "
            "permission issues. Please ensure Docker is running and accessible."
        ),
        "docker_error": (
            "Docker-related error: {error_msg}. "
            "Please check that Docker is running and the container is accessible."
        ),
        "script_execution_error": (
            "Script execution error: {error_msg}. "
            "Please check your script syntax and try again."
        ),
        "unexpected_error": (
            "An unexpected error occurred during script execution: {error_type}. "
            "Details: {error_msg}. Please try again or contact support if the issue persists."
        )
    }

    @classmethod
    def get_error_message(cls, error_type: str, **kwargs) -> str:
        """Get formatted error message for specific error type.

        Args:
            error_type: Type of error (timeout, docker_command_failed, etc.)
            **kwargs: Variables for message formatting

        Returns:
            Formatted error message
        """
        template = cls.SCRIPT_EXECUTION_ERROR_MESSAGES.get(error_type, cls.SCRIPT_EXECUTION_ERROR_MESSAGES["unexpected_error"])
        return template.format(**kwargs)


class ScriptExecutionError(Exception):
    """Custom exception for script execution errors."""
    pass


class DockerError(Exception):
    """Custom exception for Docker-related errors."""
    pass


class CodeAgent(BaseAgent):
    """A code execution agent that can run scripts in Docker containers."""

    def __init__(self, container_name: str = None, sample: str = None, store_fact: str = None):
        """Initialize the code agent.

        Args:
            container_name: Name of the Docker container to execute scripts in.
                           If None, will use configuration default.
            sample: Optional sample execution result from previous successful run.
                   Will be used as reference for code generation.
            store_fact: Optional fact name for storing execution result summary.
        """
        super().__init__()

        # Use provided container name or get from configuration
        if container_name is None:
            docker_config = get_docker_config()
            container_name = docker_config.container_name

        self.container_name = container_name
        self.sample = sample
        self.store_fact = store_fact

    async def _setup_agent(self) -> None:
        """Setup the code agent with the execute_script tool."""
        azure_config = get_azure_openai_config()

        # Choose instructions based on whether we have a sample
        if self.sample:
            instructions = CodeAgentPromptTemplate.AGENT_INSTRUCTIONS_WITH_SAMPLE.format(
                sample=self.sample
            )
            logger.info("Code agent initialized with sample reference")
        else:
            instructions = CodeAgentPromptTemplate.AGENT_INSTRUCTIONS

        self._agent = Agent(
            name="CodeAgent",
            instructions=instructions,
            model=OpenAIChatCompletionsModel(
                model=azure_config.model,
                openai_client=self._client,
            ),
            tools=[self._create_execute_script_tool()]
        )
        self._runner = Runner()
        logger.info(f"Code agent initialized successfully with model: {azure_config.model}")

    def _script_execution_error_handler(self, context: RunContextWrapper[Any], error: Exception) -> str:
        """Custom error handler for script execution failures.

        Args:
            context: The run context wrapper
            error: The exception that occurred

        Returns:
            User-friendly error message for the LLM
        """
        error_type = type(error).__name__
        error_msg = str(error)

        logger.error(f"Script execution tool failed with {error_type}: {error_msg}")

        # Handle specific error types with appropriate messages
        if isinstance(error, subprocess.TimeoutExpired):
            return CodeAgentPromptTemplate.get_error_message("timeout")
        elif isinstance(error, subprocess.CalledProcessError):
            return CodeAgentPromptTemplate.get_error_message(
                "docker_command_failed",
                returncode=error.returncode,
                error_details=error.stderr if hasattr(error, 'stderr') else 'No details available'
            )
        elif isinstance(error, FileNotFoundError):
            return CodeAgentPromptTemplate.get_error_message("file_system_error")
        elif isinstance(error, DockerError):
            return CodeAgentPromptTemplate.get_error_message("docker_error", error_msg=error_msg)
        elif isinstance(error, ScriptExecutionError):
            return CodeAgentPromptTemplate.get_error_message("script_execution_error", error_msg=error_msg)
        else:
            return CodeAgentPromptTemplate.get_error_message(
                "unexpected_error",
                error_type=error_type,
                error_msg=error_msg
            )

    def _create_execute_script_tool(self):
        """Create the execute script tool with proper access to self."""

        @function_tool(failure_error_function=self._script_execution_error_handler)
        def execute_script(script_content: str,
                          language: str = "bash",
                          timeout: int = 30) -> str:
            """Execute a script in the Docker container.

            Args:
                script_content: The content of the script to execute
                language: The programming language (bash, python, javascript, etc.)
                timeout: Maximum execution time in seconds (default: 30, max: 300)

            Returns:
                The output from script execution

            Raises:
                ScriptExecutionError: When script execution fails
                DockerError: When Docker operations fail
                subprocess.TimeoutExpired: When execution times out
            """
            # Input validation
            if not script_content or not script_content.strip():
                raise ScriptExecutionError("Script content cannot be empty")

            if timeout <= 0 or timeout > 300:
                raise ScriptExecutionError("Timeout must be between 1 and 300 seconds")

            # Check if container is running before attempting execution
            if not self._check_container_running():
                raise DockerError(f"Container '{self.container_name}' is not running or not accessible")

            # Log the script content for debugging
            logger.info(f"Executing {language} script with content: {script_content[:200]}{'...' if len(script_content) > 200 else ''}")

            try:
                # Map language to appropriate file extension and command
                language_config = {
                    "python": {"ext": ".py", "cmd": "python3"},
                    "bash": {"ext": ".sh", "cmd": "bash"},
                    "javascript": {"ext": ".js", "cmd": "node"},
                    "js": {"ext": ".js", "cmd": "node"},
                    "shell": {"ext": ".sh", "cmd": "bash"},
                    "sh": {"ext": ".sh", "cmd": "bash"}
                }

                if language.lower() not in language_config:
                    raise ScriptExecutionError(
                        f"Unsupported language '{language}'. "
                        f"Supported languages: {', '.join(language_config.keys())}"
                    )

                config = language_config[language.lower()]

                # Create a temporary file for the script
                try:
                    with tempfile.NamedTemporaryFile(mode='w', suffix=config["ext"], delete=False, newline='\n') as temp_file:
                        # Ensure Unix line endings by replacing any existing line endings
                        normalized_content = script_content.replace('\r\n', '\n').replace('\r', '\n')
                        temp_file.write(normalized_content)
                        temp_file_path = temp_file.name
                except (OSError, IOError) as e:
                    raise ScriptExecutionError(f"Failed to create temporary script file: {e}")

                try:
                    # Copy the script to the container
                    script_name = f"temp_script{config['ext']}"
                    container_script_path = f"/workspace/{script_name}"

                    # Copy file to container
                    copy_cmd = [
                        "docker", "cp",
                        temp_file_path,
                        f"{self.container_name}:{container_script_path}"
                    ]

                    logger.info(f"Copying script to container: {' '.join(copy_cmd)}")
                    try:
                        copy_result = subprocess.run(copy_cmd, capture_output=True, text=True, timeout=10)
                    except subprocess.TimeoutExpired:
                        raise DockerError("Timeout while copying script to container")
                    except FileNotFoundError:
                        raise DockerError("Docker command not found. Please ensure Docker is installed and in PATH")

                    if copy_result.returncode != 0:
                        error_msg = copy_result.stderr.strip() if copy_result.stderr else "Unknown error"
                        raise DockerError(f"Failed to copy script to container: {error_msg}")

                    # Debug: Check file permissions after copy
                    debug_ls_cmd = [
                        "docker", "exec",
                        self.container_name,
                        "ls", "-la", container_script_path
                    ]

                    logger.info(f"Debugging file permissions after copy: {' '.join(debug_ls_cmd)}")
                    try:
                        debug_result = subprocess.run(debug_ls_cmd, capture_output=True, text=True, timeout=5)
                        if debug_result.returncode == 0:
                            logger.info(f"File permissions after copy: {debug_result.stdout.strip()}")
                        else:
                            logger.warning(f"Failed to check file permissions: {debug_result.stderr.strip()}")
                    except Exception as e:
                        logger.warning(f"Debug command failed: {e}")

                    # Todo: Need to refine the script execution in a simpler way. Directly execute the script in the container
                    # Set ownership and execute permissions on the script file
                    # First change ownership to vscode user, then set execute permissions
                    chown_cmd = [
                        "docker", "exec",
                        self.container_name,  # Run as root (no --user specified)
                        "chown", "vscode:vscode", container_script_path
                    ]

                    chmod_cmd = [
                        "docker", "exec",
                        self.container_name,  # Run as root for reliable permission setting
                        "chmod", "+x", container_script_path
                    ]

                    logger.info(f"Setting ownership: {' '.join(chown_cmd)}")
                    try:
                        # Change ownership first
                        chown_result = subprocess.run(chown_cmd, capture_output=True, text=True, timeout=5)
                        if chown_result.returncode != 0:
                            error_msg = chown_result.stderr.strip() if chown_result.stderr else "Unknown error"
                            logger.error(f"Chown failed - stdout: {chown_result.stdout}, stderr: {chown_result.stderr}")
                            raise DockerError(f"Failed to set file ownership: {error_msg}")
                        else:
                            logger.info("File ownership changed successfully")

                        # Then set execute permissions
                        logger.info(f"Setting execute permissions: {' '.join(chmod_cmd)}")
                        chmod_result = subprocess.run(chmod_cmd, capture_output=True, text=True, timeout=5)
                        if chmod_result.returncode != 0:
                            error_msg = chmod_result.stderr.strip() if chmod_result.stderr else "Unknown error"
                            logger.error(f"Chmod failed - stdout: {chmod_result.stdout}, stderr: {chmod_result.stderr}")
                            raise DockerError(f"Failed to set execute permissions: {error_msg}")
                        else:
                            logger.info("Execute permissions set successfully")

                    except subprocess.TimeoutExpired:
                        raise DockerError("Timeout while setting script permissions")

                    # Debug: Check final file permissions
                    logger.info(f"Final file permissions check: {' '.join(debug_ls_cmd)}")
                    try:
                        final_debug_result = subprocess.run(debug_ls_cmd, capture_output=True, text=True, timeout=5)
                        if final_debug_result.returncode == 0:
                            logger.info(f"Final file permissions: {final_debug_result.stdout.strip()}")
                        else:
                            logger.warning(f"Failed to check final permissions: {final_debug_result.stderr.strip()}")
                    except Exception as e:
                        logger.warning(f"Final debug command failed: {e}")

                    # Execute the script in the container with proper user context
                    exec_cmd = [
                        "docker", "exec",
                        "--user", "vscode",               # Run as vscode user
                        "--env", "HOME=/home/vscode",     # Set proper HOME directory
                        "--env", "USER=vscode",           # Set USER environment
                        "-w", "/workspace",               # Working directory
                        self.container_name,
                        config["cmd"], script_name
                    ]

                    logger.info(f"Executing script in container: {' '.join(exec_cmd)}")
                    try:
                        exec_result = subprocess.run(exec_cmd, capture_output=True, text=True, timeout=timeout)
                    except subprocess.TimeoutExpired:
                        raise subprocess.TimeoutExpired(cmd=exec_cmd, timeout=timeout)
                    except FileNotFoundError:
                        raise DockerError("Docker command not found during script execution")

                    # Clean up the script file in the container (best effort)
                    cleanup_cmd = [
                        "docker", "exec",
                        "--user", "vscode",  # Cleanup also as vscode user
                        self.container_name,
                        "rm", "-f", container_script_path
                    ]
                    try:
                        subprocess.run(cleanup_cmd, capture_output=True, timeout=5)
                    except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                        logger.warning(f"Failed to cleanup script file {container_script_path} in container")

                    # Format the output including the generated script for learning purposes
                    output_lines = []
                    output_lines.append("=== Generated Script ===")
                    output_lines.append(f"Language: {language}")
                    output_lines.append("")
                    output_lines.append("```" + language)
                    output_lines.append(script_content.strip())
                    output_lines.append("```")
                    output_lines.append("")
                    output_lines.append("=== Execution Results ===")
                    output_lines.append(f"Exit Code: {exec_result.returncode}")
                    output_lines.append("")

                    if exec_result.stdout:
                        output_lines.append("=== STDOUT ===")
                        output_lines.append(exec_result.stdout.strip())
                        output_lines.append("")

                    if exec_result.stderr:
                        output_lines.append("=== STDERR ===")
                        output_lines.append(exec_result.stderr.strip())
                        output_lines.append("")

                    if exec_result.returncode == 0:
                        output_lines.append("✓ Script executed successfully")
                    else:
                        output_lines.append("✗ Script execution failed")
                        # For non-zero exit codes, we still return the output but note the failure
                        logger.warning(f"Script execution completed with non-zero exit code: {exec_result.returncode}")

                    return "\n".join(output_lines)

                finally:
                    # Clean up local temporary file
                    try:
                        os.unlink(temp_file_path)
                    except OSError as e:
                        logger.warning(f"Failed to cleanup temporary file {temp_file_path}: {e}")

            except subprocess.TimeoutExpired as e:
                # Re-raise timeout errors to be handled by the error handler
                raise e
            except (DockerError, ScriptExecutionError):
                # Re-raise our custom errors to be handled by the error handler
                raise
            except Exception as e:
                # Wrap unexpected errors in ScriptExecutionError
                logger.error(f"Unexpected error during script execution: {e}")
                raise ScriptExecutionError(f"Unexpected error: {str(e)}")

        return execute_script

    def _check_container_running(self) -> bool:
        """Check if the Docker container is running (internal method).

        Returns:
            True if container is running, False otherwise
        """
        try:
            result = subprocess.run(
                ["docker", "inspect", "-f", "{{.State.Running}}", self.container_name],
                capture_output=True, text=True, timeout=5
            )
            return result.returncode == 0 and result.stdout.strip() == "true"
        except (subprocess.TimeoutExpired, subprocess.CalledProcessError, FileNotFoundError):
            return False

    async def _summarize_as_fact(self, execution_result: str) -> str:
        """Use LLM to summarize execution result as a concise fact (max 50 words).

        Args:
            execution_result: The full execution result from code execution

        Returns:
            Summarized fact string (max 50 words)

        Raises:
            ValueError: If summarization fails or exceeds word limit
        """
        # Create a temporary agent for fact summarization
        azure_config = get_azure_openai_config()

        summarization_prompt = f"""You are a fact extraction assistant. Your task is to extract a single, clear fact from the execution result below.

REQUIREMENTS:
1. Extract ONLY the most important result or finding
2. Keep it under 50 words - be extremely concise
3. Focus on concrete values, numbers, or outcomes
4. Do NOT include explanations, context, or multiple facts
5. Return ONLY the fact itself, nothing else
6. Strip any output prefixes like "Script output:", "Output:", "Result:", etc. - just give the raw value

Execution Result:
{execution_result}

Extract the single most important fact (max 50 words):"""

        summarization_agent = Agent(
            name="FactSummarizer",
            instructions="Extract the most important fact from execution results in under 50 words.",
            model=OpenAIChatCompletionsModel(
                model=azure_config.model,
                openai_client=self._client,
            )
        )

        runner = Runner()
        result = await runner.run(summarization_agent, input=summarization_prompt)

        if not result or not hasattr(result, 'final_output'):
            raise ValueError("Failed to generate fact summary")

        summary = result.final_output.strip()

        # Validate word count
        word_count = len(summary.split())
        if word_count > 50:
            # Try to truncate to 50 words
            words = summary.split()[:50]
            summary = ' '.join(words)
            logger.warning(f"Fact summary exceeded 50 words ({word_count}), truncated to: {summary}")

        return summary

    async def execute_task(self, user_input: str) -> AgentExecutionResult:
        """Execute a task using the code agent.

        Args:
            user_input: The user's request/task description

        Returns:
            AgentExecutionResult with execution details

        Raises:
            ValueError: If user_input is empty
            RuntimeError: If agent initialization fails
            Exception: For other unexpected errors
        """
        CommonValidators.validate_non_empty_string(user_input, "user input")

        start_time = time.time()
        try:
            await self._ensure_initialized()

            if self._agent is None or self._runner is None:
                raise RuntimeError(CommonErrorMessages.INITIALIZATION_ERROR)

            logger.info(f"Executing task: {CommonUtilities.truncate_text(user_input)}")
            result = await self._runner.run(self._agent, input=user_input)

            if not result or not hasattr(result, 'final_output'):
                raise RuntimeError(CommonErrorMessages.INVALID_RESULT_ERROR)

            response = result.final_output.strip()
            execution_time = time.time() - start_time
            logger.info("Task execution completed successfully")

            # Store fact if requested
            if self.store_fact and response:
                try:
                    fact_summary = await self._summarize_as_fact(response)
                    fact_store = FactStore()
                    fact_store.store_fact(self.store_fact, fact_summary)
                except Exception as e:
                    logger.warning(f"Failed to store fact '{self.store_fact}': {e}")

            return AgentExecutionResult.success_result(
                result=response,
                action="code_agent",
                execution_time=execution_time
            )

        except ValueError:
            # Re-raise validation errors
            execution_time = time.time() - start_time
            raise
        except Exception as e:
            execution_time = time.time() - start_time
            error_message = self._get_common_error_message(e)
            logger.error(f"Code agent execution failed: {error_message}")

            return AgentExecutionResult.error_result(
                error=error_message,
                action="code_agent",
                execution_time=execution_time
            )

    def check_container_status(self) -> bool:
        """Check if the Docker container is running.

        Returns:
            True if container is running, False otherwise
        """
        return self._check_container_running()

    def get_container_info(self) -> Dict[str, Any]:
        """Get detailed information about the Docker container.

        Returns:
            Dictionary with container information
        """
        try:
            # Get container status
            status_result = subprocess.run(
                ["docker", "inspect", self.container_name],
                capture_output=True, text=True, timeout=10
            )

            if status_result.returncode != 0:
                return {
                    "running": False,
                    "exists": False,
                    "error": "Container not found or Docker not accessible"
                }

            import json
            container_info = json.loads(status_result.stdout)[0]
            state = container_info.get("State", {})

            return {
                "running": state.get("Running", False),
                "exists": True,
                "status": state.get("Status", "unknown"),
                "started_at": state.get("StartedAt", "unknown"),
                "image": container_info.get("Config", {}).get("Image", "unknown"),
                "name": self.container_name
            }

        except Exception as e:
            logger.error(f"Error getting container info: {e}")
            return {
                "running": False,
                "exists": False,
                "error": str(e)
            }

    async def cleanup(self):
        """Cleanup resources"""
        await super().cleanup()
