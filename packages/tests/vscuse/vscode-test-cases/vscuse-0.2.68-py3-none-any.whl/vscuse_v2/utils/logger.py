import logging
import os
import sys

from colorama import Fore, Style, init

init()


def _get_logging_config():
    """Get logging configuration from config manager, with fallback to environment variables."""

    def _clean_file_path(file_path):
        """Clean and validate file path, return None if empty/whitespace."""
        if file_path and file_path.strip():
            return file_path.strip()
        return None

    try:
        # Try to get logging config from config manager
        # Only use it if config is already initialized to avoid recursion/premature loading
        import vscuse_v2.config.config_manager as cm
        if getattr(cm, '_global_config', None) is None:
             raise Exception("Config not initialized")

        from vscuse_v2.config.config_manager import get_logging_config
        logging_config = get_logging_config()

        return {
            'level': logging_config.level,
            'format': logging_config.format,
            'file': _clean_file_path(logging_config.file)
        }
    except Exception:
        # Fallback to environment variables if config manager fails
        verbose = os.getenv('VERBOSE', 'False').lower() == 'true'
        level = 'DEBUG' if verbose else 'INFO'
        log_file = os.getenv('LOG_FILE', None)

        return {
            'level': level,
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            'file': _clean_file_path(log_file)
        }


def set_log_level_globally(level: str):
    """Set log level for all loggers globally.

    Args:
        level: Log level string ('DEBUG', 'INFO', 'WARNING', 'ERROR')
    """
    level_obj = getattr(logging, level.upper(), logging.INFO)

    # Set for all existing loggers
    for logger_name in logging.root.manager.loggerDict:
        logger = logging.getLogger(logger_name)
        logger.setLevel(level_obj)

    # Also update the root logger
    logging.getLogger().setLevel(level_obj)

    # Always suppress OpenAI debug logs when main log level is DEBUG
    if level.upper() == 'DEBUG':
        openai_loggers = [
            'openai._base_client',
            'openai._client',
            'openai.agents',
        ]
        for logger_name in openai_loggers:
            logging.getLogger(logger_name).setLevel(logging.INFO)


class ColorFormatter(logging.Formatter):
    """Custom formatter with colors"""
    COLORS = {
        'DEBUG': Fore.BLUE,
        'INFO': Fore.GREEN,
        'WARNING': Fore.YELLOW,
        'ERROR': Fore.RED,
        'CRITICAL': Fore.RED + Style.BRIGHT,
    }

    def format(self, record):
        original_msg = record.msg
        original_levelname = record.levelname

        color = self.COLORS.get(record.levelname, '')

        record.levelname = f"{color}{record.levelname}{Style.RESET_ALL}"
        record.msg = f"{Fore.CYAN}{original_msg}{Style.RESET_ALL}"

        formatted_msg = super().format(record)

        record.msg = original_msg
        record.levelname = original_levelname

        return formatted_msg


def setup_logger(name: str) -> logging.Logger:
    """Setup a logger with configuration from config.yaml or environment fallback."""
    logger = logging.getLogger(name)
    logger.propagate = False

    if not logger.handlers:
        # Get logging configuration
        logging_config = _get_logging_config()

        # Create console handler with color formatter
        console_handler = logging.StreamHandler(sys.stdout)
        color_formatter = ColorFormatter(
            logging_config['format'],
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(color_formatter)
        logger.addHandler(console_handler)

        # Create file handler if log file is configured
        if logging_config.get('file'):
            # Expand user path (~) and ensure log directory exists
            log_file = os.path.expanduser(logging_config['file'])
            log_dir = os.path.dirname(log_file)

            if log_dir:  # Only create directory if there is a directory part
                os.makedirs(log_dir, exist_ok=True)

            # Use rotating file handler to prevent log files from growing too large
            from logging.handlers import RotatingFileHandler
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=100*1024*1024,  # 100MB max file size
                backupCount=5  # Keep 5 backup files
            )
            # Use plain formatter for file (no colors)
            file_formatter = logging.Formatter(
                logging_config['format'],
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)

        # Set log level from config
        level_obj = getattr(logging, logging_config['level'].upper(), logging.INFO)
        logger.setLevel(level_obj)

        # Always suppress OpenAI debug logs when main log level is DEBUG
        if logging_config['level'].upper() == 'DEBUG':
            openai_loggers = [
                'openai._base_client',
                'openai._client',
                'openai.agents',
            ]
            for logger_name in openai_loggers:
                logging.getLogger(logger_name).setLevel(logging.INFO)

    return logger
