#!/usr/bin/env python3
"""
ID Generator Utility

Centralized utility for generating unique IDs for plans and steps.
Follows the format: {prefix}_{8_hex_chars}
This matches the frontend's idGenerator.ts implementation.
"""

import uuid


def generate_plan_id() -> str:
    """
    Generate a unique plan ID in the format: plan_xxxxxxxx

    Returns:
        str: Plan ID (e.g., "plan_a1b2c3d4")
    """
    return f"plan_{uuid.uuid4().hex[:8]}"


def generate_step_id() -> str:
    """
    Generate a unique step ID in the format: step_xxxxxxxx

    Returns:
        str: Step ID (e.g., "step_a1b2c3d4")
    """
    return f"step_{uuid.uuid4().hex[:8]}"


def generate_uuid_hex8() -> str:
    """
    Generate an 8-character hex string from UUID4.
    Useful for creating custom prefixed IDs.

    Returns:
        str: 8-character hex string (e.g., "a1b2c3d4")
    """
    return uuid.uuid4().hex[:8]
