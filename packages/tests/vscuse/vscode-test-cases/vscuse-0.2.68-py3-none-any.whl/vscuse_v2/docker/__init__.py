"""
Docker module for VscUse v2

Provides Docker client and container management functionality with
centralized configuration management.
"""

from .docker_client import DockerClient, DockerServiceError
from .docker_manager import (
    check_docker_image,
    check_docker_running,
    check_vscode_image,
    is_container_running,
    pull_vscode_image,
    split_docker_repository_and_tag,
    start_vscode_container,
    stop_vscode_container,
    wait_for_container_health,
)

__all__ = [
    # Docker client
    "DockerClient",
    "DockerServiceError",
    # Docker manager functions
    "check_docker_running",
    "check_docker_image",
    "check_vscode_image",
    "is_container_running",
    "pull_vscode_image",
    "split_docker_repository_and_tag",
    "start_vscode_container",
    "stop_vscode_container",
    "wait_for_container_health",
]
