"""
Database module for recording sessions.

This module provides database operations specifically for managing recording sessions.
Uses SQLite for local storage with SQLAlchemy ORM.
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy import JSON, Column, DateTime, Integer, String, Text, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from vscuse_v2.config.config_manager import get_server_config
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)

# Database configuration from config manager
def _get_database_config():
    """Get database configuration from config manager."""
    server_config = get_server_config()
    database_path = Path(server_config.database_path)

    # Ensure parent directory exists
    database_path.parent.mkdir(parents=True, exist_ok=True)

    return database_path

DATABASE_PATH = _get_database_config()
DATABASE_URL = f"sqlite:///{DATABASE_PATH}"

# SQLAlchemy setup
engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Recording(Base):
    """Recording database model."""

    __tablename__ = "recording"

    # Use session_id as primary key (recording_id)
    recording_id = Column(String, primary_key=True, index=True)

    # Session metadata
    status = Column(String, default="idle")  # idle, recording, stopped
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    duration = Column(Integer, default=0)  # duration in seconds

    # Recording results
    total_interactions = Column(Integer, default=0)
    output_file = Column(String, nullable=True)
    screenshot_dir = Column(String, nullable=True)


class PlanMetadata(Base):
    """Plan metadata database model - aligned with PlanMetadata schema."""

    __tablename__ = "plan"

    # Basic identification
    plan_id = Column(String, primary_key=True, index=True)

    # Plan metadata (flattened from PlanMetadata)
    name = Column(String, nullable=False)
    description = Column(JSON, nullable=True)  # Changed to JSON to support structured description (PlanDescription)
    version = Column(String, default="1.1")

    # Source information
    generated_at = Column(DateTime, default=datetime.utcnow)

    # Execution configuration (JSON fields)
    execution_context = Column(JSON, nullable=True)  # ExecutionContext as JSON

    # NEW: Execution order management
    execution_order = Column(JSON, nullable=True)  # List of step IDs in execution order

    # Plan characteristics
    total_steps = Column(Integer, default=0)

    # Categorization
    tags = Column(JSON, nullable=True)  # List of tags as JSON

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Step(Base):
    """Step database model - aligned with Step schema."""

    __tablename__ = "step"

    # Basic identification
    step_id = Column(String, primary_key=True, index=True)
    plan_id = Column(String, index=True, nullable=False)

    # Step core information
    agent = Column(String, default="code")  # interaction, file, code, assertion
    tool = Column(String, nullable=False)  # Tool name to execute
    description = Column(Text, nullable=False)

    # Tool parameters (comprehensive JSON storage)
    parameters = Column(JSON, nullable=True, default=dict)  # All tool parameters as JSON

    # Content references
    content_refs = Column(JSON, nullable=True, default=list)  # List of ContentReference objects

    # Execution metadata
    timeout = Column(Integer, default=30)  # seconds
    retry_count = Column(Integer, default=0)
    continue_on_error = Column(String, default="false")  # stored as string: "true"/"false"

    # Dependencies and conditions (JSON arrays - default to empty lists)
    depends_on = Column(JSON, nullable=True, default=list)  # List of step IDs
    preconditions = Column(JSON, nullable=True, default=list)  # List of conditions
    postconditions = Column(JSON, nullable=True, default=list)  # List of expected outcomes

    # Natural language support
    tags = Column(JSON, nullable=True, default=list)  # List of tags

    # Screenshot reference
    screenshot = Column(String, nullable=True, default=None)  # Screenshot path for step execution

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)


class FileIndex(Base):
    """File index database model - maps plan IDs to local file paths."""

    __tablename__ = "file_index"

    # Plan ID as primary key (one-to-one mapping with plans)
    plan_id = Column(String, primary_key=True, index=True)

    # Local file path where the plan is stored
    file_path = Column(String, nullable=False)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AgentDatabase:
    """Database manager for agent operations including recording sessions."""

    def __init__(self):
        """Initialize database connection."""
        self.engine = engine
        self.SessionLocal = SessionLocal
        # Create tables if they don't exist
        Base.metadata.create_all(bind=self.engine)

    def get_session(self):
        """Get database session."""
        return self.SessionLocal()

    def create_recording(
        self,
        recording_id: str,
        status: str = "idle",
        start_time: Optional[datetime] = None
    ) -> Recording:
        """Create a new recording session."""
        with self.get_session() as db:
            recording = Recording(
                recording_id=recording_id,
                status=status,
                start_time=start_time or datetime.utcnow()
            )
            db.add(recording)
            db.commit()
            db.refresh(recording)
            return recording

    def get_recording(self, recording_id: str) -> Optional[Recording]:
        """Get a recording session by ID."""
        with self.get_session() as db:
            return db.query(Recording).filter(
                Recording.recording_id == recording_id
            ).first()

    def update_recording(
        self,
        recording_id: str,
        status: Optional[str] = None,
        end_time: Optional[datetime] = None,
        duration: Optional[int] = None,
        total_interactions: Optional[int] = None,
        output_file: Optional[str] = None,
        screenshot_dir: Optional[str] = None
    ) -> Optional[Recording]:
        """Update a recording session."""
        with self.get_session() as db:
            recording = db.query(Recording).filter(
                Recording.recording_id == recording_id
            ).first()

            if not recording:
                return None

            # Update fields if provided
            if status is not None:
                recording.status = status
            if end_time is not None:
                recording.end_time = end_time
            if duration is not None:
                recording.duration = duration
            if total_interactions is not None:
                recording.total_interactions = total_interactions
            if output_file is not None:
                recording.output_file = output_file
            if screenshot_dir is not None:
                recording.screenshot_dir = screenshot_dir

            db.commit()
            db.refresh(recording)
            return recording

    def delete_recording(self, recording_id: str) -> bool:
        """Delete a recording session."""
        with self.get_session() as db:
            recording = db.query(Recording).filter(
                Recording.recording_id == recording_id
            ).first()

            if not recording:
                return False

            db.delete(recording)
            db.commit()
            return True

    def list_recordings(
        self,
        status: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[Recording]:
        """List recording sessions with optional filtering."""
        with self.get_session() as db:
            query = db.query(Recording)

            if status:
                query = query.filter(Recording.status == status)

            query = query.order_by(Recording.start_time.desc())

            if limit:
                query = query.limit(limit)

            return query.all()

    def get_recording_stats(self) -> Dict:
        """Get recording statistics."""
        with self.get_session() as db:
            total = db.query(Recording).count()
            active = db.query(Recording).filter(
                Recording.status == "recording"
            ).count()
            stopped = db.query(Recording).filter(
                Recording.status == "stopped"
            ).count()

            return {
                "total_recordings": total,
                "active_recordings": active,
                "stopped_recordings": stopped,
                "idle_recordings": total - active - stopped
            }

    def create_plan_metadata(
        self,
        plan_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        **kwargs
    ) -> PlanMetadata:
        """Create a new plan with enhanced schema support."""
        with self.get_session() as db:
            plan = PlanMetadata(
                plan_id=plan_id,
                name=name or f"Plan {plan_id}",
                description=description,
                **kwargs
            )
            db.add(plan)
            db.commit()
            db.refresh(plan)
            return plan

    def get_plan_metadata(self, plan_id: str) -> Optional[PlanMetadata]:
        """Get a plan by its ID."""
        with self.get_session() as db:
            return db.query(PlanMetadata).filter(PlanMetadata.plan_id == plan_id).first()

    def create_step(
        self,
        step_id: str,
        plan_id: str,
        description: str,
        tool: str,
        agent: str = "code",
        parameters: Optional[Dict[str, Any]] = None,
        screenshot: Optional[str] = None,
        **kwargs
    ) -> Step:
        """Create a new step. execution_order in plan_metadata determines sequencing."""
        with self.get_session() as db:
            step = Step(
                step_id=step_id,
                plan_id=plan_id,
                description=description,
                tool=tool,
                agent=agent,
                parameters=parameters,
                screenshot=screenshot,
                **kwargs
            )
            db.add(step)
            db.commit()
            db.refresh(step)
            return step

    def get_steps_by_plan_metadata(self, plan_id: str) -> List[Step]:
        """Get all steps for a plan. No ordering applied since execution_order in plan_metadata determines sequence."""
        with self.get_session() as db:
            return db.query(Step).filter(
                Step.plan_id == plan_id
            ).all()

    def get_steps_by_plan_metadata_without_screenshots(self, plan_id: str) -> List[Step]:
        """Get all steps for a plan excluding screenshot data for efficient listing. Returns Step objects with deferred screenshot."""
        with self.get_session() as db:
            # Use SQLAlchemy's built-in defer() to exclude screenshot column from loading
            from sqlalchemy.orm import defer

            return db.query(Step).options(defer(Step.screenshot)).filter(Step.plan_id == plan_id).all()

    def update_plan_metadata(self, plan_id: str, **kwargs) -> Optional[PlanMetadata]:
        """Update a plan with new values."""
        with self.get_session() as db:
            plan = db.query(PlanMetadata).filter(PlanMetadata.plan_id == plan_id).first()
            if not plan:
                return None

            for key, value in kwargs.items():
                if hasattr(plan, key):
                    setattr(plan, key, value)

            plan.updated_at = datetime.utcnow()
            db.commit()
            db.refresh(plan)
            return plan

    def update_step(self, step_id: str, **kwargs) -> Optional[Step]:
        """Update a step with new values."""
        with self.get_session() as db:
            step = db.query(Step).filter(Step.step_id == step_id).first()
            if not step:
                logger.warning(f"Step {step_id} not found in database")
                return None

            for key, value in kwargs.items():
                # Handle parameters field
                if key == 'parameters' and value is not None:
                    setattr(step, 'parameters', value)
                elif hasattr(step, key):
                    setattr(step, key, value)
                else:
                    logger.warning(f"Step model does not have attribute: {key}")

            db.commit()
            db.refresh(step)

            logger.info(f"Successfully updated step {step_id} in database")
            return step

    def upsert_file_index(self, plan_id: str, file_path: str) -> FileIndex:
        """Create or update the file index entry for a plan."""
        with self.get_session() as db:
            file_index = db.query(FileIndex).filter(FileIndex.plan_id == plan_id).first()
            if file_index:
                file_index.file_path = file_path
                file_index.updated_at = datetime.utcnow()
            else:
                file_index = FileIndex(plan_id=plan_id, file_path=file_path)
                db.add(file_index)
            db.commit()
            db.refresh(file_index)
            return file_index

    def get_file_index(self, plan_id: str) -> Optional[FileIndex]:
        """Get a file index entry by plan ID."""
        with self.get_session() as db:
            return db.query(FileIndex).filter(FileIndex.plan_id == plan_id).first()

    def list_all_file_indexes(self) -> List[FileIndex]:
        """Get all file index entries."""
        with self.get_session() as db:
            return db.query(FileIndex).all()


    def delete_file_index(self, plan_id: str) -> bool:
        """Delete a file index entry."""
        with self.get_session() as db:
            file_index = db.query(FileIndex).filter(FileIndex.plan_id == plan_id).first()
            if not file_index:
                return False

            db.delete(file_index)
            db.commit()
            return True

    def clear_all_file_indexes(self) -> int:
        """Clear all file index entries. Returns the number of entries deleted."""
        with self.get_session() as db:
            count = db.query(FileIndex).count()
            db.query(FileIndex).delete()
            db.commit()
            return count


# Global database instance
_db_instance = None


def get_database() -> AgentDatabase:
    """Get the global database instance."""
    global _db_instance
    if _db_instance is None:
        _db_instance = AgentDatabase()
    return _db_instance


def init_database():
    """Initialize the database (create tables if needed)."""
    database = get_database()
    return database


# Convenience functions
def create_recording(recording_id: str, **kwargs) -> Recording:
    """Create a new recording."""
    db = get_database()
    return db.create_recording(recording_id, **kwargs)


def get_recording(recording_id: str) -> Optional[Recording]:
    """Get a recording by ID."""
    db = get_database()
    return db.get_recording(recording_id)


def update_recording(recording_id: str, **kwargs) -> Optional[Recording]:
    """Update a recording."""
    db = get_database()
    return db.update_recording(recording_id, **kwargs)


def list_recordings(**kwargs) -> List[Recording]:
    """List recordings."""
    db = get_database()
    return db.list_recordings(**kwargs)
