#!/usr/bin/env python3
"""
Plans API Router

Provides endpoints for managing test plans in the database.
"""

import base64
import json
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from vscuse_v2.config.config_manager import get_execution_config
from vscuse_v2.core.ocr_text import (
    OcrConfigError,
    encode_ocr_precondition,
    extract_ocr_text,
    get_image_viewport,
    is_ocr_precondition,
    parse_ocr_precondition,
)
from vscuse_v2.core.validator import Validator, parse_condition
from vscuse_v2.server.database import PlanMetadata, Step, get_database
from vscuse_v2.utils.id_generator import generate_step_id
from vscuse_v2.utils.logger import setup_logger
from vscuse_v2.utils.plan_format import convert_from_export_format, convert_to_export_format

router = APIRouter()
logger = setup_logger(__name__)


class ExecutablePlanCreateRequest(BaseModel):
    """Request model for creating a new plan"""
    plan_metadata: Dict
    steps: List[Dict]


class ExecutablePlanUpdateRequest(BaseModel):
    """Request model for updating a plan"""
    steps: Optional[List[Dict]] = None
    plan_metadata: Optional[Dict] = None


class ExecutablePlanImportRequest(BaseModel):
    """Request model for importing a plan (with screenshots section)"""
    plan_metadata: Dict
    steps: List[Dict]
    screenshots: Optional[Dict[str, str]] = None


def _update_preconditions_for_screenshot(screenshot: str, preconditions: List[str]) -> List[str]:
    """
    Update precondition hash values based on a new screenshot.

    Args:
        screenshot: Screenshot data URI
        preconditions: List of existing precondition strings

    Returns:
        List of updated precondition strings with new hash values
    """
    if not screenshot or not preconditions:
        return preconditions

    # Only process data URIs
    if not screenshot.startswith('data:'):
        logger.warning("Screenshot is not a data URI, cannot update preconditions")
        return preconditions

    try:
        # Extract base64 data from data URI
        header, encoded = screenshot.split(',', 1)
        image_data = base64.b64decode(encoded)

        # Create temporary file for screenshot
        with tempfile.NamedTemporaryFile(mode='wb', suffix='.png', delete=False) as temp_file:
            temp_file.write(image_data)
            temp_screenshot_path = Path(temp_file.name)

        try:
            validator = Validator()
            updated_preconditions = []

            for precondition in preconditions:
                # OCR precondition: regenerate expected text from the new screenshot.
                if is_ocr_precondition(precondition):
                    try:
                        full_text = extract_ocr_text(temp_screenshot_path)
                        old_payload = parse_ocr_precondition(precondition) or {}
                        viewport = get_image_viewport(temp_screenshot_path)
                        target = old_payload.get("target")
                        updated_preconditions.append(
                            encode_ocr_precondition(full_text, viewport=viewport, target=target)
                        )
                        logger.debug("Regenerated OCR precondition for updated screenshot")
                    except OcrConfigError as e:
                        logger.warning(f"OCR unavailable, keeping existing OCR precondition: {e}")
                        updated_preconditions.append(precondition)
                    except Exception as e:
                        logger.warning(f"Failed to regenerate OCR precondition: {e}")
                        updated_preconditions.append(precondition)
                    continue

                # Parse the precondition to extract parameters
                parsed = parse_condition(precondition, "precondition")

                if not parsed.success:
                    logger.warning(f"Failed to parse precondition: {precondition} - {parsed.error}")
                    updated_preconditions.append(precondition)
                    continue

                # Extract parameters
                x, y = parsed.coordinates
                size = parsed.size if parsed.size is not None else 0
                tolerance = parsed.tolerance
                hash_type = parsed.hash_type.value

                # Generate new hash from the new screenshot at the same coordinates
                new_condition = validator.generate_condition(
                    screenshot_path=temp_screenshot_path,
                    x=x,
                    y=y,
                    hash_type=hash_type,
                    size=size,
                    tolerance=tolerance
                )

                if new_condition:
                    logger.debug(f"Updated precondition: {precondition} -> {new_condition}")
                    updated_preconditions.append(new_condition)
                else:
                    logger.warning(f"Failed to generate new hash for precondition: {precondition}")
                    updated_preconditions.append(precondition)

            return updated_preconditions

        finally:
            # Clean up temporary file
            try:
                temp_screenshot_path.unlink()
            except Exception as e:
                logger.warning(f"Failed to delete temporary screenshot file: {e}")

    except Exception as e:
        logger.error(f"Failed to update preconditions: {e}")
        return preconditions


@router.get("/{plan_id}")
async def get_executable_plan(plan_id: str):
    """
    Get an executable plan by ID.

    Args:
        plan_id: The ID of the plan to retrieve

    Returns:
        Simple JSON with plan_metadata and steps

    Raises:
        HTTPException: If the plan is not found
    """
    db = get_database()
    plan = db.get_plan_metadata(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan {plan_id} not found")

    # Return simple JSON structure
    return {
        "plan_metadata": plan,
        "steps": db.get_steps_by_plan_metadata(plan_id)
    }


@router.get("/")
async def list_executable_plans():
    """
    List all available executable plans.

    Returns:
        A list of executable plans with simple JSON structure (screenshots excluded for performance)
    """
    db = get_database()
    with db.get_session() as session:
        plans = session.query(PlanMetadata).all()

    # Return simple list of executable plans using database-level filtering
    result = []
    for plan in plans:
        steps = db.get_steps_by_plan_metadata_without_screenshots(plan.plan_id)
        result.append({
            "plan_metadata": plan,
            "steps": steps
        })

    return result


@router.post("/")
async def create_executable_plan(create_data: ExecutablePlanCreateRequest):
    """
    Create a new executable plan.

    Args:
        create_data: The plan data to create

    Returns:
        The created plan data

    Raises:
        HTTPException: If the plan already exists or creation fails
    """
    logger.info("Creating new plan")
    logger.debug(f"Create data: {create_data}")

    db = get_database()

    # Extract plan metadata
    plan_metadata = create_data.plan_metadata
    plan_id = plan_metadata.get('plan_id')

    if not plan_id:
        raise HTTPException(status_code=400, detail="plan_id is required in plan_metadata")

    # Check if plan already exists
    existing_plan = db.get_plan_metadata(plan_id)
    if existing_plan:
        raise HTTPException(status_code=409, detail=f"Plan {plan_id} already exists")

    try:
        # Get default execution context from configuration
        execution_config = get_execution_config()
        default_execution_context = {
            'delay_between_steps': execution_config.delay_between_steps,
            'stop_on_error': execution_config.stop_on_error,
            'precondition_wait_timeout': execution_config.precondition_wait_timeout,
            'precondition_retry_interval': execution_config.precondition_retry_interval,
            'step_retry_timeout': execution_config.step_retry_timeout
        }

        # Process execution_order to update step references (will be updated after step creation)
        original_execution_order = plan_metadata.get('execution_order', [])

        # Create plan metadata (let database set generated_at automatically)
        created_plan_metadata = db.create_plan_metadata(
            plan_id=plan_id,
            name=plan_metadata.get('name', 'Untitled Plan'),
            description=plan_metadata.get('description', ''),
            version=plan_metadata.get('version', '1.0'),
            execution_context=plan_metadata.get('execution_context', default_execution_context),
            execution_order=[],  # Will be updated after step creation with new step IDs
            total_steps=plan_metadata.get('total_steps', 0),
            tags=plan_metadata.get('tags', [])
        )

        if not created_plan_metadata:
            raise HTTPException(status_code=500, detail="Failed to create plan metadata")

        logger.info(f"Successfully created plan metadata for {plan_id}")

        # Create steps if provided
        created_steps = []
        step_id_mapping = {}  # Map old step_ids to new step_ids for execution_order update
        logger.info(f"Processing {len(create_data.steps)} steps for plan {plan_id}")

        if create_data.steps:
            for step_data in create_data.steps:
                original_step_id = step_data.get('step_id')
                if not original_step_id:
                    logger.warning(f"Skipping step without step_id: {step_data}")
                    continue

                # Generate new step ID to avoid conflicts
                new_step_id = generate_step_id()
                step_id_mapping[original_step_id] = new_step_id

                logger.info(f"Creating step {new_step_id} (original: {original_step_id})")

                try:
                    # Extract required fields for step creation
                    description = step_data.get('description', '')
                    tool = step_data.get('tool', '')
                    agent = step_data.get('agent', 'code')

                    logger.debug(f"Step {new_step_id} - description: {description}, tool: {tool}, agent: {agent}")

                    # Extract optional fields (exclude fields that are already passed as arguments or handled by database defaults)
                    optional_fields = {k: v for k, v in step_data.items()
                                     if k not in ['step_id', 'plan_id', 'description', 'tool', 'agent', 'created_at', 'depends_on']}

                    # logger.debug(f"Step {new_step_id} - optional_fields: {optional_fields}")

                    # Create the new step
                    created_step = db.create_step(
                        step_id=new_step_id,
                        plan_id=plan_id,
                        description=description,
                        tool=tool,
                        agent=agent,
                        **optional_fields
                    )

                    if created_step:
                        created_steps.append(created_step)
                        logger.info(f"Successfully created step {new_step_id}")
                    else:
                        logger.error(f"Failed to create step {new_step_id}")

                except Exception as e:
                    logger.error(f"Failed to create step {new_step_id}: {e}")
                    # Continue processing other steps rather than failing the entire request
                    continue

        logger.info(f"Successfully created plan {plan_id} with {len(created_steps)} steps")

        # Update execution_order with new step IDs
        if original_execution_order and step_id_mapping:
            updated_execution_order = []
            for old_step_id in original_execution_order:
                if old_step_id in step_id_mapping:
                    updated_execution_order.append(step_id_mapping[old_step_id])
                else:
                    logger.warning(f"Step ID {old_step_id} in execution_order not found in step_id_mapping")

            # Update the plan metadata with the new execution order
            if updated_execution_order:
                updated_plan_metadata = db.update_plan_metadata(
                    plan_id,
                    execution_order=updated_execution_order
                )
                if updated_plan_metadata:
                    created_plan_metadata = updated_plan_metadata
                    logger.info(f"Updated execution_order with new step IDs: {updated_execution_order}")
                else:
                    logger.warning("Failed to update execution_order with new step IDs")

        # Return the created plan - fetch steps from database to ensure consistency
        final_steps = db.get_steps_by_plan_metadata(plan_id)
        logger.info(f"Fetched {len(final_steps)} steps from database for plan {plan_id}")

        return {
            "plan_metadata": created_plan_metadata,
            "steps": final_steps
        }

    except Exception as e:
        logger.error(f"Failed to create plan {plan_id}: {e}")
        # Clean up any partially created data
        try:
            with db.get_session() as session:
                # Delete any steps that were created
                session.query(Step).filter(Step.plan_id == plan_id).delete()
                # Delete the plan metadata if it was created
                session.query(PlanMetadata).filter(PlanMetadata.plan_id == plan_id).delete()
                session.commit()
        except Exception as cleanup_error:
            logger.error(f"Failed to cleanup after creation failure: {cleanup_error}")
        raise HTTPException(status_code=500, detail=f"Failed to create plan: {str(e)}")


@router.put("/{plan_id}")
async def upsert_executable_plan(plan_id: str, update_data: ExecutablePlanUpdateRequest):
    """
    Create or update a test plan by ID (upsert operation).

    If the plan exists, it will be updated.
    If the plan doesn't exist, it will be created with the provided ID.

    Args:
        plan_id: The ID of the plan to create or update
        update_data: The data to create/update

    Returns:
        The created or updated plan data directly from database

    Raises:
        HTTPException: If the operation fails
    """
    logger.info(f"Upserting plan {plan_id}")

    db = get_database()

    # Check if plan exists
    plan_metadata = db.get_plan_metadata(plan_id)
    plan_exists = plan_metadata is not None

    if plan_exists:
        logger.info(f"Plan {plan_id} exists - updating")
    else:
        logger.info(f"Plan {plan_id} doesn't exist - creating")

    # Validate that at least one field is provided
    if not any(getattr(update_data, field) is not None for field in update_data.__class__.model_fields.keys()):
        raise HTTPException(status_code=400, detail="At least one field must be provided for upsert")

    # For creation, we need plan_metadata
    if not plan_exists and not update_data.plan_metadata:
        raise HTTPException(status_code=400, detail="plan_metadata is required when creating a new plan")

    # IMPORTANT: If steps are provided and not empty, execution_order must be provided from frontend
    if update_data.steps is not None and len(update_data.steps) > 0:
        if (not update_data.plan_metadata or
            'execution_order' not in update_data.plan_metadata or
            not update_data.plan_metadata['execution_order']):
            raise HTTPException(
                status_code=400,
                detail="When steps are provided, execution_order must be provided in plan_metadata"
            )
        logger.info("Steps manipulation detected - execution_order provided from frontend")

    # Handle plan creation if it doesn't exist
    if not plan_exists:
        try:
            # Get default execution context from configuration
            execution_config = get_execution_config()
            default_execution_context = {
                'delay_between_steps': execution_config.delay_between_steps,
                'stop_on_error': execution_config.stop_on_error,
                'precondition_wait_timeout': execution_config.precondition_wait_timeout,
                'precondition_retry_interval': execution_config.precondition_retry_interval
            }

            # Create plan metadata
            plan_metadata_dict = update_data.plan_metadata
            created_plan_metadata = db.create_plan_metadata(
                plan_id=plan_id,
                name=plan_metadata_dict.get('name', 'Untitled Plan'),
                description=plan_metadata_dict.get('description', ''),
                version=plan_metadata_dict.get('version', '1.0'),
                execution_context=plan_metadata_dict.get('execution_context', default_execution_context),
                execution_order=plan_metadata_dict.get('execution_order', []),
                total_steps=plan_metadata_dict.get('total_steps', 0),
                tags=plan_metadata_dict.get('tags', [])
            )

            if not created_plan_metadata:
                raise HTTPException(status_code=500, detail="Failed to create plan metadata")

            plan_metadata = created_plan_metadata
            logger.info(f"Successfully created plan metadata for {plan_id}")

        except Exception as e:
            logger.error(f"Failed to create plan {plan_id}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to create plan: {str(e)}")

    # Handle plan_metadata updates (for both new and existing plans)
    update_dict = {}
    if update_data.plan_metadata is not None:
        plan_metadata_dict = update_data.plan_metadata
        if 'name' in plan_metadata_dict:
            update_dict['name'] = plan_metadata_dict['name']
        if 'description' in plan_metadata_dict:
            update_dict['description'] = plan_metadata_dict['description']
        if 'tags' in plan_metadata_dict:
            update_dict['tags'] = plan_metadata_dict['tags']
        if 'execution_order' in plan_metadata_dict:
            update_dict['execution_order'] = plan_metadata_dict['execution_order']
        if 'total_steps' in plan_metadata_dict:
            update_dict['total_steps'] = plan_metadata_dict['total_steps']

    # Perform plan metadata update if there are changes
    updated_plan_metadata = plan_metadata
    if update_dict:
        updated_plan_metadata = db.update_plan_metadata(plan_id, **update_dict)
        if not updated_plan_metadata:
            raise HTTPException(status_code=500, detail="Failed to update plan metadata")

    # Handle steps update if provided
    if update_data.steps is not None:
        logger.info(f"Upserting steps for plan {plan_id}")

        # Get current steps
        current_steps = db.get_steps_by_plan_metadata(plan_id)
        current_step_ids = {step.step_id for step in current_steps}

        # Get new step IDs
        new_step_ids = {step.get('step_id') for step in update_data.steps if step.get('step_id')}

        # Delete steps that are no longer in the update
        steps_to_delete = current_step_ids - new_step_ids
        if steps_to_delete:
            logger.info(f"Deleting steps: {steps_to_delete}")
            with db.get_session() as session:
                session.query(Step).filter(
                    Step.plan_id == plan_id,
                    Step.step_id.in_(list(steps_to_delete))
                ).delete(synchronize_session=False)
                session.commit()

        # Update or create remaining steps
        for step_data in update_data.steps:
            step_id = step_data.get('step_id')
            if not step_id:
                continue

            # Check if step exists
            existing_step = next((s for s in current_steps if s.step_id == step_id), None)

            if existing_step:
                # Automatic Precondition Update Feature:
                # When a step's recording screenshot is updated (e.g., replacing with "before execution" screenshot),
                # automatically regenerate precondition hash values to match the new screenshot.
                # This maintains consistency between preconditions and the recording screenshot.
                # Precondition format: "hash_type:x:y:size:tolerance:hash_value"
                # Example: "dhash:1008:23:0:10:1b19215569694541"

                # Check if we should update preconditions
                has_screenshot = 'screenshot' in step_data and step_data.get('screenshot')
                has_preconditions = step_data.get('preconditions') and len(step_data.get('preconditions', [])) > 0

                # Use existing step's preconditions if not provided in update
                if has_screenshot and not has_preconditions and existing_step.preconditions:
                    step_data['preconditions'] = existing_step.preconditions
                    has_preconditions = True
                    logger.debug(f"Using existing preconditions for step {step_id} ({len(existing_step.preconditions)} conditions)")

                if has_screenshot and has_preconditions:
                    old_screenshot = existing_step.screenshot
                    new_screenshot = step_data['screenshot']

                    # Only update preconditions if screenshot actually changed
                    if old_screenshot != new_screenshot:
                        logger.info(f"Screenshot changed for step {step_id}, updating {len(step_data['preconditions'])} preconditions")
                        try:
                            updated_preconditions = _update_preconditions_for_screenshot(
                                new_screenshot,
                                step_data['preconditions']
                            )
                            step_data['preconditions'] = updated_preconditions
                            logger.info(f"Successfully updated {len(updated_preconditions)} preconditions for step {step_id}")
                        except Exception as e:
                            logger.warning(f"Failed to update preconditions for step {step_id}: {e}")
                            # Continue with original preconditions if update fails
                    else:
                        logger.debug(f"Screenshot unchanged for step {step_id}, skipping precondition update")
                else:
                    if has_screenshot and not has_preconditions:
                        logger.debug(f"Step {step_id} has screenshot but no preconditions to update")

                # Update existing step - exclude fields that shouldn't be updated
                step_update = {k: v for k, v in step_data.items()
                             if k not in ['step_id', 'created_at']}  # Don't update created_at

                db.update_step(step_id, **step_update)
                logger.info(f"Successfully updated step {step_id} in database")
            else:
                # Create new step
                logger.info(f"Creating new step {step_id}")
                try:
                    # Extract required fields for step creation
                    description = step_data.get('description', '')
                    tool = step_data.get('tool', '')
                    agent = step_data.get('agent', 'code')

                    # Extract optional fields
                    optional_fields = {k: v for k, v in step_data.items()
                                     if k not in ['step_id', 'created_at', 'description', 'tool', 'agent']}

                    # Create the new step
                    db.create_step(
                        step_id=step_id,
                        plan_id=plan_id,
                        description=description,
                        tool=tool,
                        agent=agent,
                        **optional_fields
                    )
                    logger.info(f"Successfully created new step {step_id} in database")
                except Exception as e:
                    logger.error(f"Failed to create new step {step_id}: {e}")
                    # Continue processing other steps rather than failing the entire request
                    continue

        # After step updates, refresh the execution order and total steps
        updated_steps = db.get_steps_by_plan_metadata(plan_id)
        new_total_steps = len(updated_steps)

        # Only update execution_order if we actually have steps to process
        if new_total_steps > 0:
            # Since we validated that execution_order is provided when steps are updated,
            # we can use it directly
            new_execution_order = update_data.plan_metadata['execution_order']
            logger.info(f"Using frontend-provided execution order: {new_execution_order}")
        else:
            # No regular steps, but execution_order might contain group references
            # Use the execution_order from frontend if provided, otherwise keep existing
            if update_data.plan_metadata and 'execution_order' in update_data.plan_metadata:
                new_execution_order = update_data.plan_metadata['execution_order']
                logger.info(f"No regular steps but using frontend-provided execution order: {new_execution_order}")
            else:
                # Keep existing execution_order if no update is provided
                new_execution_order = updated_plan_metadata.execution_order
                logger.info(f"No regular steps and no execution_order update - keeping existing: {new_execution_order}")

        # Always update execution order and total steps to ensure they're current
        execution_update = {
            'execution_order': new_execution_order,
            'total_steps': new_total_steps
        }
        updated_plan_metadata = db.update_plan_metadata(plan_id, **execution_update)
        if not updated_plan_metadata:
            logger.warning("Failed to update execution order and total steps")
        else:
            logger.info(f"Updated execution order: {new_execution_order}")
            logger.info(f"Updated total steps: {new_total_steps}")

    operation = "created" if not plan_exists else "updated"
    logger.info(f"Successfully {operation} plan {plan_id}")

    # Get updated steps for both response and file sync
    steps = db.get_steps_by_plan_metadata(plan_id)

    # Check if plan has a file mapping and sync to file if it exists
    # OR auto-create file for plans without file mapping if project path is configured
    try:
        file_index = db.get_file_index(plan_id)
        if file_index and file_index.file_path:
            logger.info(f"Plan {plan_id} has file mapping: {file_index.file_path}")

            # Export plan to get it in the proper format with separated screenshots
            # convert_to_export_format now returns normalized data with consistent ordering
            result = convert_to_export_format(updated_plan_metadata, steps)

            # Write to file (result already has datetime serialized and consistent ordering)
            file_path = Path(file_index.file_path)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)

            logger.info(f"Successfully synced plan {plan_id} to file: {file_index.file_path}")
        else:
            # Auto-create file for plans without file mapping if project path is configured
            # This handles both new plans and plans transitioned from 'empty_plan'
            import os
            project_path_str = os.environ.get("_PROJECT_PATH")
            if project_path_str:
                project_dir = Path(project_path_str).resolve()
                if project_dir.exists() and project_dir.is_dir():
                    # Create file in project root with sanitized plan name
                    plan_name = updated_plan_metadata.name or "untitled_plan"
                    safe_name = ''.join(c if c.isalnum() or c in ('_', '-') else '_' for c in plan_name)
                    file_path = project_dir / f"{safe_name}.json"

                    # Ensure unique filename
                    counter = 1
                    while file_path.exists():
                        file_path = project_dir / f"{safe_name}_{counter}.json"
                        counter += 1

                    # Export and write plan (already normalized with consistent ordering)
                    result = convert_to_export_format(updated_plan_metadata, steps)

                    with open(file_path, 'w', encoding='utf-8') as f:
                        json.dump(result, f, indent=2, ensure_ascii=False)

                    # Create file index
                    db.upsert_file_index(plan_id, str(file_path.absolute()))
                    logger.info(f"Auto-created file for plan {plan_id}: {file_path}")
    except Exception as e:
        # Log but don't fail the request if file sync fails
        logger.warning(f"Failed to sync plan {plan_id} to file: {e}")

    # Return updated executable plan
    return {
        "plan_metadata": updated_plan_metadata,
        "steps": steps
    }


@router.delete("/{plan_id}")
async def delete_executable_plan(plan_id: str):
    """
    Delete a test plan by ID.

    Args:
        plan_id: The ID of the plan to delete

    Returns:
        Confirmation message

    Raises:
        HTTPException: If the plan is not found
    """
    db = get_database()

    # Check if plan exists
    plan = db.get_plan_metadata(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan {plan_id} not found")

    # Delete the plan and its steps
    with db.get_session() as session:
        # Delete all steps associated with this plan
        session.query(Step).filter(Step.plan_id == plan_id).delete()

        # Delete the plan itself
        session.query(PlanMetadata).filter(PlanMetadata.plan_id == plan_id).delete()

        session.commit()

    return {
        "status": "success",
        "message": f"Plan {plan_id} and its steps have been deleted successfully"
    }


@router.post("/import")
async def import_plan(import_data: ExecutablePlanImportRequest):
    """
    Import a plan from exported JSON format, preserving original step IDs and content.
    Screenshots are converted back to embedded data URIs in steps.

    Args:
        import_data: The exported plan data with separated screenshots

    Returns:
        The created plan data with original step IDs preserved

    Raises:
        HTTPException: If the plan already exists or import fails
    """
    logger.info("Importing plan from exported format - preserving original step IDs")
    logger.debug(f"Import data keys: {list(import_data.model_dump().keys())}")

    db = get_database()

    # Extract plan metadata
    plan_metadata = import_data.plan_metadata
    plan_id = plan_metadata.get('plan_id')

    if not plan_id:
        raise HTTPException(status_code=400, detail="plan_id is required in plan_metadata")

    # Check if plan already exists
    existing_plan = db.get_plan_metadata(plan_id)
    if existing_plan:
        raise HTTPException(status_code=409, detail=f"Plan {plan_id} already exists")

    # Process the import data to restore embedded screenshots using shared utility
    import_plan_data = {
        "plan_metadata": import_data.plan_metadata,
        "steps": import_data.steps,
        "screenshots": import_data.screenshots
    }
    processed_plan_data = convert_from_export_format(import_plan_data)

    try:
        # Get default execution context from configuration
        execution_config = get_execution_config()
        default_execution_context = {
            'delay_between_steps': execution_config.delay_between_steps,
            'stop_on_error': execution_config.stop_on_error,
            'precondition_wait_timeout': execution_config.precondition_wait_timeout,
            'precondition_retry_interval': execution_config.precondition_retry_interval,
            'step_retry_timeout': execution_config.step_retry_timeout
        }

        # Create plan metadata with all original data
        created_plan_metadata = db.create_plan_metadata(
            plan_id=plan_id,
            name=plan_metadata.get('name', 'Untitled Plan'),
            description=plan_metadata.get('description', ''),
            version=plan_metadata.get('version', '1.0'),
            execution_context=plan_metadata.get('execution_context', default_execution_context),
            execution_order=plan_metadata.get('execution_order', []),  # Use original execution order
            total_steps=plan_metadata.get('total_steps', 0),
            tags=plan_metadata.get('tags', [])
        )

        if not created_plan_metadata:
            raise HTTPException(status_code=500, detail="Failed to create plan metadata")

        logger.info(f"Successfully created plan metadata for {plan_id}")

        # Create steps with original step IDs (no ID regeneration)
        created_steps = []
        logger.info(f"Processing {len(processed_plan_data['steps'])} steps for plan {plan_id}")

        if processed_plan_data['steps']:
            for step_data in processed_plan_data['steps']:
                original_step_id = step_data.get('step_id')
                if not original_step_id:
                    logger.warning(f"Skipping step without step_id: {step_data}")
                    continue

                logger.info(f"Creating step with original ID: {original_step_id}")

                try:
                    # Extract required fields for step creation
                    description = step_data.get('description', '')
                    tool = step_data.get('tool', '')
                    agent = step_data.get('agent', 'code')

                    logger.debug(f"Step {original_step_id} - description: {description}, tool: {tool}, agent: {agent}")

                    # Extract optional fields (exclude fields that are handled by database or not needed)
                    optional_fields = {k: v for k, v in step_data.items()
                                     if k not in ['step_id', 'plan_id', 'description', 'tool', 'agent', 'created_at']}

                    # Create the step with original step ID
                    created_step = db.create_step(
                        step_id=original_step_id,  # Use original step ID
                        plan_id=plan_id,
                        description=description,
                        tool=tool,
                        agent=agent,
                        **optional_fields
                    )

                    if created_step:
                        created_steps.append(created_step)
                        logger.info(f"Successfully created step {original_step_id}")
                    else:
                        logger.error(f"Failed to create step {original_step_id}")

                except Exception as e:
                    logger.error(f"Failed to create step {original_step_id}: {e}")
                    # Continue processing other steps rather than failing the entire request
                    continue

        logger.info(f"Successfully imported plan {plan_id} with {len(created_steps)} steps using original step IDs")

        # Return the imported plan - fetch steps from database to ensure consistency
        final_steps = db.get_steps_by_plan_metadata(plan_id)
        logger.info(f"Fetched {len(final_steps)} steps from database for plan {plan_id}")

        return {
            "plan_metadata": created_plan_metadata,
            "steps": final_steps
        }

    except Exception as e:
        logger.error(f"Failed to import plan {plan_id}: {e}")
        # Clean up any partially created data
        try:
            with db.get_session() as session:
                # Delete any steps that were created
                session.query(Step).filter(Step.plan_id == plan_id).delete()
                # Delete the plan metadata if it was created
                session.query(PlanMetadata).filter(PlanMetadata.plan_id == plan_id).delete()
                session.commit()
        except Exception as cleanup_error:
            logger.error(f"Failed to cleanup after import failure: {cleanup_error}")
        raise HTTPException(status_code=500, detail=f"Failed to import plan: {str(e)}")


@router.get("/{plan_id}/export")
async def export_plan(plan_id: str):
    """
    Export a plan and its steps as JSON for external use.
    Screenshots are separated into a dedicated section for better readability,
    with steps containing references to screenshot keys.

    Args:
        plan_id: Plan ID to export
    """
    db = get_database()

    # Get plan metadata
    plan = db.get_plan_metadata(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan {plan_id} not found")

    # Get steps for this plan
    steps = db.get_steps_by_plan_metadata(plan_id)

    # Use shared utility to process the plan for export
    result = convert_to_export_format(plan, steps)

    logger.info(f"Exported plan {plan_id} using shared utility")
    return result
