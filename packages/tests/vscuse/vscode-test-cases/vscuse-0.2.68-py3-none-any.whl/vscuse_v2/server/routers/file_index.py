#!/usr/bin/env python3
"""
File Index API Router

Provides endpoints for managing mappings between plan IDs and local file paths.
This enables synchronization of executable plans with local JSON files.
"""


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from vscuse_v2.server.database import get_database
from vscuse_v2.utils.logger import setup_logger

router = APIRouter()
logger = setup_logger(__name__)


class FileIndexCreateRequest(BaseModel):
    """Request model for creating or updating a file index entry"""
    plan_id: str
    file_path: str


class FileIndexResponse(BaseModel):
    """Response model for file index operations"""
    plan_id: str
    file_path: str


@router.get("/list")
async def list_all_file_indexes():
    """
    Get all file path mappings.

    Returns:
        List of FileIndexResponse with plan_id and file_path for all mappings
    """
    db = get_database()
    file_indexes = db.list_all_file_indexes()

    return [
        FileIndexResponse(
            plan_id=file_index.plan_id,
            file_path=file_index.file_path
        )
        for file_index in file_indexes
    ]


@router.get("/load-from-file")
async def load_plan_from_file(file_path: str):
    """
    Load an executable plan from a JSON file and update the file index.

    Args:
        file_path: Full path to the JSON file

    Returns:
        ExecutablePlan object loaded from the file

    Raises:
        HTTPException: If file doesn't exist, is invalid, or cannot be parsed
    """
    import json
    from pathlib import Path

    file_path_obj = Path(file_path)

    # Validate file exists
    if not file_path_obj.exists():
        raise HTTPException(
            status_code=404,
            detail=f"File does not exist: {file_path}"
        )

    if not file_path_obj.is_file():
        raise HTTPException(
            status_code=400,
            detail=f"Path is not a file: {file_path}"
        )

    if file_path_obj.suffix.lower() != '.json':
        raise HTTPException(
            status_code=400,
            detail=f"File is not a JSON file: {file_path}"
        )

    try:
        # Read and parse JSON file
        with open(file_path_obj, 'r', encoding='utf-8') as f:
            plan_data = json.load(f)

        # Validate it has the required structure
        if not isinstance(plan_data, dict):
            raise HTTPException(
                status_code=400,
                detail="Invalid plan file: root must be an object"
            )

        if 'plan_metadata' not in plan_data:
            raise HTTPException(
                status_code=400,
                detail="Invalid plan file: missing plan_metadata"
            )

        # Process the import data (handle screenshots if present)
        from vscuse_v2.config.config_manager import get_execution_config
        from vscuse_v2.server.database import Step
        from vscuse_v2.utils.plan_format import convert_from_export_format

        processed_data = convert_from_export_format(plan_data)
        plan_metadata = processed_data['plan_metadata']
        plan_id = plan_metadata.get('plan_id')

        if not plan_id:
            raise HTTPException(
                status_code=400,
                detail="Invalid plan file: missing plan_id in plan_metadata"
            )

        # Get default execution context
        execution_config = get_execution_config()
        default_execution_context = {
            'delay_between_steps': execution_config.delay_between_steps,
            'stop_on_error': execution_config.stop_on_error,
            'precondition_wait_timeout': execution_config.precondition_wait_timeout,
            'precondition_retry_interval': execution_config.precondition_retry_interval,
            'step_retry_timeout': execution_config.step_retry_timeout
        }

        # Import plan to database (lazy loading - only on user request)
        db = get_database()
        existing_plan = db.get_plan_metadata(plan_id)

        if existing_plan:
            # Plan already exists in database - update it
            logger.info(f"Plan {plan_id} already exists in database, updating it")

            # Update plan metadata
            db.update_plan_metadata(
                plan_id=plan_id,
                name=plan_metadata.get('name', 'Untitled Plan'),
                description=plan_metadata.get('description', ''),
                version=plan_metadata.get('version', '1.0'),
                execution_context=plan_metadata.get('execution_context', default_execution_context),
                execution_order=plan_metadata.get('execution_order', []),
                total_steps=plan_metadata.get('total_steps', 0),
                tags=plan_metadata.get('tags', [])
            )

            # Clean up existing steps
            with db.get_session() as session:
                session.query(Step).filter(Step.plan_id == plan_id).delete()
                session.commit()
        else:
            # Create new plan in database
            logger.info(f"Creating new plan {plan_id} in database")

            created_plan = db.create_plan_metadata(
                plan_id=plan_id,
                name=plan_metadata.get('name', 'Untitled Plan'),
                description=plan_metadata.get('description', ''),
                version=plan_metadata.get('version', '1.0'),
                execution_context=plan_metadata.get('execution_context', default_execution_context),
                execution_order=plan_metadata.get('execution_order', []),
                total_steps=plan_metadata.get('total_steps', 0),
                tags=plan_metadata.get('tags', [])
            )

            if not created_plan:
                raise HTTPException(
                    status_code=500,
                    detail="Failed to create plan metadata in database"
                )

        # Create steps with original IDs from file
        for step_data in processed_data['steps']:
            original_step_id = step_data.get('step_id')
            if not original_step_id:
                logger.warning(f"Skipping step without step_id in plan {plan_id}")
                continue

            try:
                db.create_step(
                    step_id=original_step_id,
                    plan_id=plan_id,
                    description=step_data.get('description', ''),
                    tool=step_data.get('tool', ''),
                    agent=step_data.get('agent', 'code'),
                    **{k: v for k, v in step_data.items()
                       if k not in ['step_id', 'plan_id', 'description', 'tool', 'agent', 'created_at']}
                )
            except Exception as e:
                logger.error(f"Failed to create step {original_step_id}: {e}")
                continue

        # Upsert file index with absolute path
        absolute_path = str(file_path_obj.absolute())
        existing_index = db.get_file_index(plan_id)
        db.upsert_file_index(plan_id, absolute_path)

        action = "updated" if existing_index else "created"
        logger.info(f"File index {action} for plan {plan_id}")

        logger.info(f"Successfully imported plan {plan_id} from file: {file_path}")

        # Return the loaded plan from database
        plan_metadata_from_db = db.get_plan_metadata(plan_id)
        steps_from_db = db.get_steps_by_plan_metadata(plan_id)

        return {
            "plan_metadata": plan_metadata_from_db,
            "steps": steps_from_db
        }

    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid JSON file: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error loading plan from file {file_path}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load plan: {str(e)}"
        )


@router.get("/{plan_id}")
async def get_file_index(plan_id: str) -> FileIndexResponse:
    """
    Get the file path associated with a plan ID.

    Args:
        plan_id: The ID of the plan

    Returns:
        FileIndexResponse with plan_id and file_path

    Raises:
        HTTPException: If the mapping is not found
    """
    db = get_database()
    file_index = db.get_file_index(plan_id)

    if not file_index:
        raise HTTPException(
            status_code=404,
            detail=f"No file path mapping found for plan {plan_id}"
        )

    return FileIndexResponse(
        plan_id=file_index.plan_id,
        file_path=file_index.file_path
    )


@router.delete("/{plan_id}")
async def delete_file_index(plan_id: str):
    """
    Delete the file path mapping for a plan.

    Args:
        plan_id: The ID of the plan

    Returns:
        Success message

    Raises:
        HTTPException: If the mapping is not found or deletion fails
    """
    db = get_database()

    success = db.delete_file_index(plan_id)

    if not success:
        raise HTTPException(
            status_code=404,
            detail=f"No file path mapping found for plan {plan_id}"
        )

    logger.info(f"Deleted file path mapping for plan {plan_id}")
    return {
        "status": "success",
        "message": f"File path mapping for plan {plan_id} deleted successfully"
    }
