#!/usr/bin/env python3
"""
Container Management Router

Handles container operations like restart, status check, etc.
"""

import asyncio

from fastapi import APIRouter, HTTPException

from vscuse_v2.config.config_manager import get_docker_config
from vscuse_v2.docker.docker_manager import (
    is_container_running,
    start_vscode_container,
    stop_vscode_container,
    wait_for_container_health,
)
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)
router = APIRouter()


@router.post("/restart")
async def restart_container():
    """Restart the container."""
    try:
        # Get configuration
        docker_config = get_docker_config()
        container_name = docker_config.container_name
        image_name = docker_config.image_name

        logger.info(f"Restarting container: {container_name}")

        # Step 1: Stop the existing container
        if is_container_running(container_name):
            logger.info("Stopping existing container...")
            stop_success = stop_vscode_container(container_name)
            if not stop_success:
                logger.warning("Failed to stop container, but continuing...")
        else:
            logger.info("Container not running, skipping stop step")

        # Wait a moment for cleanup
        await asyncio.sleep(2)

        # Step 2: Start the container again
        logger.info("Starting container...")

        # Get directory configurations
        workspace_dir = docker_config.workspace_dir
        app_dir = docker_config.app_dir
        extensions_dir = docker_config.extensions_dir

        # Get port configurations
        novnc_port = str(docker_config.novnc_port)
        api_port = str(docker_config.api_port)

        start_success = start_vscode_container(
            image_name=image_name,
            container_name=container_name,
            workspace_dir=workspace_dir,
            app_dir=app_dir,
            extensions_dir=extensions_dir,
            ports={"novnc": novnc_port, "docker_api": api_port}
        )

        if not start_success:
            raise HTTPException(
                status_code=500,
                detail="Failed to start container after restart"
            )

        # Step 3: Wait for container to be healthy
        logger.info("Waiting for container to become healthy...")
        timeout = docker_config.timeout
        health_success = wait_for_container_health(container_name, timeout=timeout)

        if not health_success:
            logger.warning("Container health check failed, but container was started")

        logger.info("Container restart completed successfully")

        return {
            "status": "success",
            "message": "Container restarted successfully",
            "container_name": container_name,
            "container_healthy": health_success
        }

    except Exception as e:
        logger.error(f"Container restart failed: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Container restart failed: {str(e)}"
        )


@router.get("/status")
async def get_container_status():
    """Get current container status."""
    try:
        # Get configuration
        docker_config = get_docker_config()
        container_name = docker_config.container_name

        # Check if container is running
        is_running = is_container_running(container_name)

        # Try to check health if running
        is_healthy = False
        if is_running:
            timeout = docker_config.timeout
            is_healthy = wait_for_container_health(container_name, timeout=timeout)

        return {
            "status": "success",
            "data": {
                "container_name": container_name,
                "is_running": is_running,
                "is_healthy": is_healthy,
                "status_text": (
                    "healthy" if is_healthy else
                    "running" if is_running else
                    "stopped"
                )
            }
        }

    except Exception as e:
        logger.error(f"Failed to get container status: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get container status: {str(e)}"
        )


@router.post("/stop")
async def stop_container():
    """Stop the container."""
    try:
        # Get configuration
        docker_config = get_docker_config()
        container_name = docker_config.container_name

        logger.info(f"Stopping container: {container_name}")

        if not is_container_running(container_name):
            return {
                "status": "success",
                "message": "Container is already stopped",
                "container_name": container_name
            }

        stop_success = stop_vscode_container(container_name)

        if not stop_success:
            raise HTTPException(
                status_code=500,
                detail="Failed to stop container"
            )

        logger.info("Container stopped successfully")

        return {
            "status": "success",
            "message": "Container stopped successfully",
            "container_name": container_name
        }

    except Exception as e:
        logger.error(f"Failed to stop container: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to stop container: {str(e)}"
        )
