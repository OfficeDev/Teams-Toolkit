#!/usr/bin/env python3
"""
VSC-Use Server API
"""

import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from vscuse_v2 import __version__
from vscuse_v2.config.config_manager import get_server_config
from vscuse_v2.server.routers import container, executable_plans, execution, file_index, project_path, recording, screenshots
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


def clear_file_index_table():
    """Clear all file index entries from the database."""
    from vscuse_v2.server.database import get_database
    try:
        db = get_database()
        count = db.clear_all_file_indexes()
        logger.info(f"Cleared file index table ({count} entries)")
    except Exception as e:
        logger.warning(f"Failed to clear file index table: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Lifecycle manager for the FastAPI application.
    Handles initialization and cleanup of application resources.
    """
    try:
        logger.info("Initializing VSC-Use Server...")

        # Setup workspace directory
        workspace_dir = os.environ.get("_WORKSPACE_DIR")
        if workspace_dir:
            Path(workspace_dir).mkdir(parents=True, exist_ok=True)
            logger.info(f"Workspace directory: {workspace_dir}")

        # Application startup complete
        logger.info("VSC-Use Server initialization complete")

    except Exception as e:
        logger.error(f"Failed to initialize application: {str(e)}")
        raise

    yield  # Application runs here

    # Shutdown
    try:
        logger.info("Cleaning up application resources...")
        await cleanup()
        logger.info("Application shutdown complete")
    except Exception as e:
        logger.error(f"Error during shutdown: {str(e)}")


async def cleanup() -> None:
    """Cleanup resources on application shutdown"""
    logger.info("Cleaning up resources...")

    # Clear file index table on shutdown
    clear_file_index_table()

    logger.info("Cleanup complete.")


# CORS middleware configuration
def get_cors_origins():
    """Get CORS origins from configuration"""
    server_config = get_server_config()

    return [
        f"http://localhost:{server_config.api_port}",  # VSCUse API port
        f"http://127.0.0.1:{server_config.api_port}",
        f"http://localhost:{server_config.ui_port}",  # UI frontend port
        f"http://127.0.0.1:{server_config.ui_port}",
    ]


# Create FastAPI application with lifespan
server_config = get_server_config()
app = FastAPI(
    lifespan=lifespan,
    debug=server_config.debug if server_config else True,
    title="VSC-Use Server API",
    version=__version__,
    description="VSC-Use Server API for test plan management and recording automation.",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(
    recording.router,
    prefix="/api/recording",
    tags=["recording"],
    responses={404: {"description": "Not found"}},
)

# Include plans router
app.include_router(
    executable_plans.router,
    prefix="/api/executable_plans",
    tags=["executable_plans"],
    responses={404: {"description": "Not found"}},
)

# Include execution router
app.include_router(
    execution.router,
    prefix="/api/execution",
    tags=["execution"],
    responses={404: {"description": "Not found"}},
)

# Include container router
app.include_router(
    container.router,
    prefix="/api/container",
    tags=["container"],
    responses={404: {"description": "Not found"}},
)

# Include screenshots router
app.include_router(
    screenshots.router,
    prefix="/api/screenshots",
    tags=["screenshots"],
    responses={404: {"description": "Not found"}},
)

# Include file_index router
app.include_router(
    file_index.router,
    prefix="/api/file_index",
    tags=["file_index"],
    responses={404: {"description": "Not found"}},
)

# Include project_path router
app.include_router(
    project_path.router,
    prefix="/api/project_path",
    tags=["project_path"],
    responses={404: {"description": "Not found"}},
)

# API Routes - Define BEFORE static file mount to ensure they take precedence
@app.get("/health")
async def health_check():
    """Service health check endpoint"""
    return {
        "status": True,
        "message": "VSC-Use Server is healthy",
        "service": "vsc-use-server",
        "version": __version__,
    }


@app.get("/version")
async def get_version():
    """Get API version"""
    return {
        "status": True,
        "message": "Version retrieved successfully",
        "data": {"version": __version__, "service": "vsc-use-server"},
    }


# Mount static file directories - MUST be after API routes to avoid catching API calls
# Check if UI build directory exists
ui_build_path = Path(__file__).resolve().parents[2] / "ui" / "public"
if ui_build_path.exists():
    logger.info(f"Mounting UI static files from: {ui_build_path}")
    app.mount("/", StaticFiles(directory=str(ui_build_path), html=True), name="ui")
else:
    logger.warning(f"UI build directory not found: {ui_build_path}")


# Error handlers
@app.exception_handler(500)
async def internal_error_handler(request: Request, exc: Exception):
    logger.error(f"Internal error: {str(exc)}")
    return {
        "status": False,
        "message": "Internal server error",
        "detail": str(exc),
    }


def create_app() -> FastAPI:
    """
    Factory function to create and configure the FastAPI application.
    Useful for testing and different deployment scenarios.
    """
    return app
