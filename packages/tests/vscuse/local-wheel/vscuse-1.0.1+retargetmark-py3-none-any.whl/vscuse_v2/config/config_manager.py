#!/usr/bin/env python3
"""
Configuration Manager for VSC-Use

Provides centralized configuration management with layered overrides:
1. User Config File (highest priority)
2. Environment Variables
3. Default Values (lowest priority)

Supports:
- Deep merging of nested configurations
- Environment variable substitution with ${VAR} syntax
- Dot notation access (e.g., config.get("azure_openai.endpoint"))
- Partial user config files (only specify what you want to change)
- Configuration validation
"""

import os
import re
from pathlib import Path
from typing import Any, Dict, Optional, Union

import yaml
from pydantic import BaseModel, ConfigDict

from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)


class ConfigurationError(Exception):
    """Exception raised for configuration-related errors."""
    pass


class AzureOpenAIConfig(BaseModel):
    """Azure OpenAI configuration section."""
    endpoint: str = "${AZURE_OPENAI_ENDPOINT}"
    api_key: str = "${AZURE_OPENAI_API_KEY}"
    api_version: str = "2025-04-01-preview"
    model: str = "gpt-5.4"
    timeout: int = 60
    use_azure_credential: bool = False


class AzureVisionConfig(BaseModel):
    """Azure Computer Vision configuration section."""
    endpoint: str = "${AZURE_VISION_ENDPOINT}"
    api_key: str = "${AZURE_VISION_KEY}"


class AzureServicePrincipalConfig(BaseModel):
    """Azure Service Principal configuration section."""
    client_id: str = "${AZURE_CLIENT_ID}"
    client_secret: str = "${AZURE_CLIENT_SECRET}"
    tenant_id: str = "${AZURE_TENANT_ID}"
    subscription_id: str = "${AZURE_SUBSCRIPTION_ID}"
    enabled: bool = False


class M365Config(BaseModel):
    """M365 Account configuration section."""
    account_name: str = "${M365_ACCOUNT_NAME}"
    account_password: str = "${M365_ACCOUNT_PASSWORD}"
    tenant_id: str = "${M365_TENANT_ID}"
    enabled: bool = False


class CicdConfig(BaseModel):
    """CI/CD configuration section."""
    enabled: bool = True


class DockerConfig(BaseModel):
    """Docker configuration section."""
    server_url: str = "http://localhost:6081"
    container_name: str = "vscuse-container"
    image_name: str = "${VSCUSE_VSCODE_IMAGE:ghcr.io/microsoft/vscuse-base:latest}"
    timeout: int = 30
    vscode_insiders: bool = False

    # Ports configuration
    api_port: int = 6081
    novnc_port: int = 6080

    # Directories
    workspace_dir: str = "~/.vscuse/workspace"
    app_dir: str = "~/.vscuse/app/data"
    extensions_dir: str = "~/.vscuse/extensions"

    # Custom environment variables to pass to Docker container
    # Dict of environment variable name -> value pairs
    environment: Dict[str, str] = {}


class ServerConfig(BaseModel):
    """Server configuration section."""
    api_port: int = 6082
    ui_port: int = 6083
    database_path: str = "~/.vscuse/app/db/agent.db"
    debug: bool = True


class ExecutionConfig(BaseModel):
    """Execution configuration section."""
    delay_between_steps: float = 0.5
    stop_on_error: bool = True
    precondition_wait_timeout: float = 60
    precondition_retry_interval: float = 2
    step_retry_timeout: float = 0.0


class FileOperationsConfig(BaseModel):
    """File operations configuration section."""
    work_dir: str = "~/.vscuse/workspace"
    mcp_client_timeout: int = 180


class LoggingConfig(BaseModel):
    """Logging configuration section."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(levelname)s - %(message)s"
    file: Optional[str] = None  # Path to log file, None for console only

    # Docker logging configuration
    print_docker_logs: bool = False
    docker_log_tail: int = 100


class VSCUseConfig(BaseModel):
    """Main configuration model with all sections."""
    model_config = ConfigDict(extra='allow')  # Allow extra fields for extensibility

    azure_openai: AzureOpenAIConfig = AzureOpenAIConfig()
    azure_vision: AzureVisionConfig = AzureVisionConfig()
    azure_service_principal: AzureServicePrincipalConfig = AzureServicePrincipalConfig()
    m365: M365Config = M365Config()
    cicd: CicdConfig = CicdConfig()
    docker: DockerConfig = DockerConfig()
    server: ServerConfig = ServerConfig()
    execution: ExecutionConfig = ExecutionConfig()
    file_operations: FileOperationsConfig = FileOperationsConfig()
    logging: LoggingConfig = LoggingConfig()


class ConfigManager:
    """
    Centralized configuration manager with layered overrides.
    """

    def __init__(self, user_config_path: Optional[Union[str, Path]] = None):
        """
        Initialize configuration manager.

        Args:
            user_config_path: Path to user configuration file. If None, will look in standard locations.
        """
        self._defaults = self._create_default_config()
        self._user_config_path = self._resolve_config_path(user_config_path)
        self._user_config = self._load_user_config()
        self._final_config = self._merge_and_process_config()

        logger.info(f"Configuration initialized from: {self._user_config_path.resolve() if self._user_config_path else 'defaults only'}")

    def _create_default_config(self) -> VSCUseConfig:
        """Create default configuration."""
        return VSCUseConfig()

    def _resolve_config_path(self, user_config_path: Optional[Union[str, Path]]) -> Optional[Path]:
        """
        Resolve configuration file path.

        Args:
            user_config_path: User-provided path or None

        Returns:
            Resolved path or None if no config file found
        """
        if user_config_path:
            path = Path(user_config_path).expanduser()
            if path.exists():
                return path
            else:
                logger.warning(f"Specified config file not found: {path}")
                return None

        # Look in standard locations
        standard_locations = [
            Path("./config.yaml"),
            Path("./vscuse-config.yaml"),
            Path.home() / ".vscuse" / "config.yaml",
            Path.home() / ".config" / "vscuse" / "config.yaml",
        ]

        for location in standard_locations:
            if location.exists():
                logger.info(f"Found config file at: {location}")
                return location

        logger.info("No user config file found, using defaults only")
        return None

    def _load_user_config(self) -> Dict[str, Any]:
        """
        Load user configuration from file.

        Returns:
            User configuration dictionary or empty dict if no file
        """
        if not self._user_config_path:
            return {}

        try:
            with open(self._user_config_path, 'r', encoding='utf-8') as f:
                user_config = yaml.safe_load(f) or {}

            logger.info(f"Loaded user configuration from {self._user_config_path.resolve()}: {len(user_config)} top-level sections")
            return user_config

        except Exception as e:
            logger.error(f"Error loading user config from {self._user_config_path}: {e}")
            raise ConfigurationError(f"Failed to load configuration file: {e}")

    def _merge_and_process_config(self) -> VSCUseConfig:
        """
        Merge user config with defaults and process environment variables.

        Returns:
            Final processed configuration
        """
        # Convert default config to dict for merging
        defaults_dict = self._defaults.model_dump()

        # Deep merge user config with defaults
        merged_dict = self._deep_merge(defaults_dict, self._user_config)

        # Substitute environment variables
        processed_dict = self._substitute_env_vars(merged_dict)

        # Create final config object with validation
        try:
            final_config = VSCUseConfig.model_validate(processed_dict)
            logger.debug("Configuration validation successful")

            # Store final config temporarily for path expansion
            self._final_config = final_config

            # Expand paths after validation
            self.expand_paths()

            return self._final_config
        except Exception as e:
            logger.error(f"Configuration validation failed: {e}")
            raise ConfigurationError(f"Invalid configuration: {e}")

    def _deep_merge(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deep merge two dictionaries.

        Args:
            base: Base dictionary (defaults)
            override: Override dictionary (user config)

        Returns:
            Merged dictionary
        """
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value

        return result

    def _substitute_env_vars(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively substitute environment variables in configuration.

        Supports ${VAR_NAME} syntax with optional default values: ${VAR_NAME:default_value}

        Args:
            config: Configuration dictionary

        Returns:
            Dictionary with environment variables substituted
        """
        if isinstance(config, dict):
            return {key: self._substitute_env_vars(value) for key, value in config.items()}
        elif isinstance(config, list):
            return [self._substitute_env_vars(item) for item in config]
        elif isinstance(config, str):
            return self._substitute_env_var_string(config)
        else:
            return config

    def _substitute_env_var_string(self, value: str) -> str:
        """
        Substitute environment variables in a string.

        Syntax:
        - ${VAR_NAME} - Use env var, leave as-is if not set (shows warning)
        - ${VAR_NAME:default} - Use env var, or use provided default if not set

        Args:
            value: String that may contain ${VAR} or ${VAR:default} patterns

        Returns:
            String with environment variables substituted
        """
        # Pattern to match ${VAR} or ${VAR:default}
        pattern = r'\$\{([^}:]+)(?::([^}]*))?\}'

        def replace_env_var(match):
            var_name = match.group(1)
            default_value = match.group(2) if match.group(2) is not None else ""

            env_value = os.environ.get(var_name)
            if env_value is not None:
                return env_value
            elif default_value:
                return default_value
            else:
                logger.warning(f"Environment variable {var_name} not found and no default provided")
                return match.group(0)  # Return original ${VAR} if not found

        return re.sub(pattern, replace_env_var, value)

    def get(self, key_path: str, default: Any = None) -> Any:
        """
        Get configuration value using dot notation.

        Args:
            key_path: Dot-separated path to config value (e.g., "azure_openai.endpoint")
            default: Default value if path not found

        Returns:
            Configuration value or default
        """
        try:
            obj = self._final_config
            for key in key_path.split('.'):
                if hasattr(obj, key):
                    obj = getattr(obj, key)
                else:
                    return default
            return obj
        except Exception:
            return default

    def get_section(self, section_name: str) -> Optional[BaseModel]:
        """
        Get entire configuration section.

        Args:
            section_name: Name of the configuration section

        Returns:
            Configuration section object or None
        """
        return getattr(self._final_config, section_name, None)

    def validate(self) -> None:
        """
        Validate critical configuration values.

        Raises:
            ConfigurationError: If validation fails
        """
        # Check required environment variables
        required_vars = [
            ("azure_openai.endpoint", "Azure OpenAI endpoint"),
            ("azure_openai.api_key", "Azure OpenAI API key"),
        ]

        errors = []
        for key_path, description in required_vars:
            value = self.get(key_path)
            if not value or (isinstance(value, str) and value.startswith("${")):
                errors.append(f"Missing required configuration: {description} ({key_path})")

        # Check port conflicts
        ports_to_check = [
            ("docker.api_port", "Docker API port"),
            ("docker.novnc_port", "Docker noVNC port"),
            ("server.api_port", "Server API port"),
            ("server.ui_port", "Server UI port"),
        ]

        used_ports = {}
        for key_path, description in ports_to_check:
            port = self.get(key_path)
            if port in used_ports:
                errors.append(f"Port conflict: {description} ({port}) conflicts with {used_ports[port]}")
            else:
                used_ports[port] = description

        if errors:
            raise ConfigurationError("Configuration validation failed:\n" + "\n".join(f"  - {error}" for error in errors))

        logger.info("Configuration validation passed")

    def expand_paths(self) -> None:
        """
        Expand user home directories in path configurations.
        """
        path_configs = [
            "docker.workspace_dir",
            "docker.app_dir",
            "docker.extensions_dir",
            "server.database_path",
            "file_operations.work_dir"
        ]

        for path_config in path_configs:
            current_value = self.get(path_config)
            if current_value and isinstance(current_value, str):
                expanded = str(Path(current_value).expanduser())
                # Update the config object
                section_name, field_name = path_config.split('.')
                section = getattr(self._final_config, section_name)
                setattr(section, field_name, expanded)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.

        Returns:
            Configuration as dictionary
        """
        return self._final_config.model_dump()

    def print_config(self, hide_secrets: bool = True) -> None:
        """
        Print current configuration (for debugging).

        Args:
            hide_secrets: Whether to hide sensitive values
        """
        config_dict = self.to_dict()

        if hide_secrets:
            config_dict = self._hide_secrets(config_dict)

        import json
        print(json.dumps(config_dict, indent=2, default=str))

    def _hide_secrets(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Hide sensitive values in configuration for printing."""
        if isinstance(config, dict):
            result = {}
            for key, value in config.items():
                if any(secret_key in key.lower() for secret_key in ['key', 'secret', 'password', 'token']):
                    result[key] = "***hidden***" if value else value
                else:
                    result[key] = self._hide_secrets(value)
            return result
        elif isinstance(config, list):
            return [self._hide_secrets(item) for item in config]
        else:
            return config


# Global configuration instance
_global_config: Optional[ConfigManager] = None


def get_config(user_config_path: Optional[Union[str, Path]] = None) -> ConfigManager:
    """
    Get global configuration instance (singleton pattern).

    Args:
        user_config_path: Path to user configuration file (only used on first call)

    Returns:
        Global ConfigManager instance
    """
    global _global_config

    if _global_config is None:
        _global_config = ConfigManager(user_config_path)
        _global_config.expand_paths()
        # Note: Validation is not automatic to allow for partial configs during development
        # Call config.validate() explicitly when needed

    return _global_config


def reset_config() -> None:
    """Reset global configuration (mainly for testing)."""
    global _global_config
    _global_config = None


# Convenience functions for common config access patterns
def get_azure_openai_config() -> AzureOpenAIConfig:
    """Get Azure OpenAI configuration section."""
    return get_config().get_section("azure_openai")


def get_azure_vision_config() -> AzureVisionConfig:
    """Get Azure Computer Vision configuration section."""
    return get_config().get_section("azure_vision")


def get_azure_service_principal_config() -> AzureServicePrincipalConfig:
    """Get Azure Service Principal configuration section."""
    return get_config().get_section("azure_service_principal")


def get_m365_config() -> M365Config:
    """Get M365 configuration section."""
    return get_config().get_section("m365")


def get_cicd_config() -> CicdConfig:
    """Get CI/CD configuration section."""
    return get_config().get_section("cicd")


def get_docker_config() -> DockerConfig:
    """Get Docker configuration section."""
    return get_config().get_section("docker")


def get_server_config() -> ServerConfig:
    """Get Server configuration section."""
    return get_config().get_section("server")


def get_execution_config() -> ExecutionConfig:
    """Get Execution configuration section."""
    return get_config().get_section("execution")


def get_logging_config() -> LoggingConfig:
    """Get Logging configuration section."""
    return get_config().get_section("logging")


# Export public interface
__all__ = [
    "ConfigManager",
    "get_config",
    "reset_config",
    "get_azure_openai_config",
    "get_azure_vision_config",
    "get_azure_service_principal_config",
    "get_m365_config",
    "get_cicd_config",
    "get_docker_config",
    "get_server_config",
    "get_execution_config",
    "get_logging_config",
    "ConfigurationError",
    "VSCUseConfig"
]
