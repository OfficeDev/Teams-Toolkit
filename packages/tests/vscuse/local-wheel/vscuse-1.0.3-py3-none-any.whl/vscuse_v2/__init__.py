"""
Vsc Use - A CLI tool for UI automation testing
"""
from pathlib import Path

__version__ = "1.0.3"

def load_env_vars():
    try:
        from dotenv import load_dotenv

        project_root = Path(__file__).parent.parent
        env_path = project_root / '.env'

        load_dotenv(dotenv_path=env_path, override=True)
        return True
    except ImportError:
        # Silent fallback - use system environment variables
        return False

load_env_vars()
