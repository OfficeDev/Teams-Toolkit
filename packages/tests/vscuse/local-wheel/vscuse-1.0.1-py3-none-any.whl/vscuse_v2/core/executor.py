#!/usr/bin/env python3
"""
Plan Executor

Executes executable plans using agent-based execution.
"""

import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import imagehash
from PIL import Image

from vscuse_v2.config import get_docker_config, get_execution_config
from vscuse_v2.config.config_manager import ExecutionConfig
from vscuse_v2.docker.docker_client import DockerClient
from vscuse_v2.utils.image_tool import detect_loading_stability
from vscuse_v2.utils.logger import setup_logger

from .agent_router import AgentRouter
from .condition_agent import ConditionAgent, is_valid_screenshot_data
from .fact_store import FactStore
from .models import PlanExecutionResult, StepExecutionResult
from .reporter import Reporter
from .resolver import Resolver
from .schema import AgentType, ExecutablePlan, Step
from .tag_processor import TagProcessor
from .validator import parse_condition, validate_postconditions, validate_preconditions

logger = setup_logger(__name__)


class Executor:
    """Plan executor for executing steps using different agents."""

    def __init__(self, docker_server_url: str = None,
                 delay: float = None,
                 precondition_wait_timeout: float = None,
                 precondition_retry_interval: float = None,
                 generate_report: bool = True,
                 report_output_dir: str = "test_report"):

        # Load configuration
        docker_config = get_docker_config()
        execution_config = get_execution_config()

        # Set configuration with provided values or defaults
        self.docker_server_url = docker_server_url or docker_config.server_url
        self.delay = delay or execution_config.delay_between_steps
        self.precondition_wait_timeout = precondition_wait_timeout or execution_config.precondition_wait_timeout
        self.precondition_retry_interval = precondition_retry_interval or execution_config.precondition_retry_interval
        self.stop_on_error = execution_config.stop_on_error
        self.step_retry_timeout = execution_config.step_retry_timeout
        self.generate_report = generate_report
        self.report_output_dir = report_output_dir

        # Initialize components
        self._docker_client = DockerClient(docker_server_url=docker_server_url)
        self.reporter = Reporter(report_output_dir) if generate_report else None
        self.resolver = Resolver()
        self.tag_processor = TagProcessor()
        self.agent_router = AgentRouter(docker_server_url=self.docker_server_url)

        # Execution state
        self.execution_log = []
        self.step_results = {}
        # Human-readable reason for the most recent precondition failure
        # (LLM decision + explanation), surfaced in the step error / report.
        self._last_precondition_detail: Optional[str] = None
        # Per-step markers recording whether the new lenient OCR-retargeted precondition
        # mechanism was exercised on the step currently executing, surfaced in the report
        # so the team can count adoption of the new feature.
        self._used_new_precondition: bool = False
        self._ocr_retargeted: bool = False
        self._ocr_retarget_detail: Optional[str] = None
        # Corrected (x, y) produced by the AI precondition judge for the current step,
        # applied to the coordinate action just before it runs. None = no re-target.
        self._retarget_xy: Optional[Tuple[int, int]] = None
        # Description of the previous successfully executed step (context for the AI
        # precondition judge). None until at least one step has succeeded.
        self._prev_step_description: Optional[str] = None
        self.current_plan = None
        self.current_plan_path = None

    async def execute_step(self, step: Step) -> StepExecutionResult:
        """Execute a step using the appropriate agent with retry logic based on timeout."""
        # Determine retry timeout: check for step_retry_timeout tag first, then use executor's default
        tag_retry_timeout = self.tag_processor.get_step_retry_timeout(step)
        retry_timeout = tag_retry_timeout if tag_retry_timeout is not None else self.step_retry_timeout

        last_result = None
        attempt = 0
        start_time = time.time()

        while True:
            attempt += 1
            elapsed = time.time() - start_time

            if attempt > 1:
                logger.info(f"[RETRY] Attempt {attempt} for step {step.step_id} (elapsed: {elapsed:.1f}s / timeout: {retry_timeout}s)")

            result = await self._execute_step_once(step)
            last_result = result

            if result.success:
                if attempt > 1:
                    logger.info(f"[RETRY SUCCESS] Step {step.step_id} succeeded on attempt {attempt} after {elapsed:.1f}s")
                return result

            # Check if we've exceeded the retry timeout
            elapsed = time.time() - start_time
            if elapsed >= retry_timeout:
                logger.error(f"[RETRY TIMEOUT] Step {step.step_id} failed after {attempt} attempts and {elapsed:.1f}s (timeout: {retry_timeout}s)")
                break

            # Calculate remaining time and decide if we should retry
            remaining = retry_timeout - elapsed
            if remaining > 0:
                # Brief delay between retries (but don't exceed timeout)
                delay = min(1.0, remaining)
                logger.warning(f"[RETRY] Step {step.step_id} failed, retrying in {delay:.1f}s... (remaining timeout: {remaining:.1f}s)")
                await asyncio.sleep(delay)
            else:
                break

        return last_result

    async def _execute_step_once(self, step: Step) -> StepExecutionResult:
        """Execute a step once (internal method used by retry logic)."""
        logger.info("=" * 60)
        logger.info(f"[EXECUTING] Step {step.step_id}: {step.description}")
        logger.info("=" * 60)

        start_time = time.time()
        before_screenshot = None
        after_screenshot = None
        # Reset the new-precondition usage markers for this step.
        self._used_new_precondition = False
        self._ocr_retargeted = False
        self._ocr_retarget_detail = None
        self._retarget_xy = None

        try:
            # Resolve environment variables in step parameters and description
            resolved_step = self.resolver.resolve_step_variables(step)

            # Use the resolved step for the rest of the execution
            step = resolved_step

            # Apply strict precondition tolerance for steps containing sensitive data
            if getattr(step, '_contains_sensitive', False) and step.preconditions:
                logger.info(f"Step {step.step_id} contains sensitive data, applying strict precondition checks...")
                step.preconditions = [self._adjust_precondition_tolerance(pc, 3) for pc in step.preconditions]

            # Check for delay tag and wait if specified
            delay_seconds = self.tag_processor.get_delay_seconds(step)
            if delay_seconds is not None:
                logger.info(f"Delay tag found for step {step.step_id}, waiting {delay_seconds} seconds...")
                await asyncio.sleep(delay_seconds)

            # Check for force_run tag to skip preconditions and postconditions
            force_run = self.tag_processor.should_force_run(step)
            if force_run:
                logger.info(f"Force run enabled for step {step.step_id}, skipping precondition and postcondition checks")
                logger.info(f"Waiting for stable screenshot for force run step {step.step_id}...")
                await self._wait_for_stable_screenshot(max_wait=60.0)

            # Check for precondition_wait_timeout tag and override step timeout if specified
            tag_timeout = self.tag_processor.get_precondition_wait_timeout(step)
            if tag_timeout is not None:
                logger.info(f"Precondition wait timeout tag found for step {step.step_id}, using {tag_timeout} seconds")
                step.precondition_wait_timeout = tag_timeout

            # Check preconditions (skip if force_run is enabled)
            if not force_run and not await self._check_preconditions(step):
                # Precondition failure: create error result with screenshot for debugging
                timeout = step.precondition_wait_timeout or self.precondition_wait_timeout
                # Take screenshot on precondition failure for debugging
                before_screenshot = self._docker_client.take_screenshot()
                execution_time = time.time() - start_time

                # Get retry information for better error message
                tag_retry_timeout = self.tag_processor.get_step_retry_timeout(step)
                retry_timeout = tag_retry_timeout if tag_retry_timeout is not None else self.step_retry_timeout
                retry_info = f" (will retry for up to {retry_timeout}s)" if retry_timeout > 0 else ""

                detail = getattr(self, "_last_precondition_detail", None)
                if detail and len(detail) > 800:
                    detail = detail[:800] + "..."
                detail_suffix = f" - {detail}" if detail else ""
                result = StepExecutionResult.from_step(
                    step, success=False,
                    error=f"Preconditions failed after {timeout}s timeout{retry_info}{detail_suffix}",
                    action="precondition_check_failed",
                    execution_time=execution_time
                )
                result.before_screenshot = before_screenshot
                result.after_screenshot = None
            else:
                # Normal execution path: preconditions passed, proceed with agent execution
                # Take before screenshot
                before_screenshot = self._docker_client.take_screenshot()
                logger.debug(f"Before screenshot taken for step {step.step_id}: {before_screenshot}")

                # Check for store_fact tag
                store_fact = self.tag_processor.get_store_fact(step)

                # Apply an AI-judge coordinate correction produced during the
                # precondition check (re-targets the click to the intended element).
                if self._retarget_xy is not None and step.parameters is not None:
                    nx, ny = self._retarget_xy
                    updated_params = step.parameters.model_copy(update={"x": nx, "y": ny})
                    step = step.model_copy(update={"parameters": updated_params})

                agent_result = await self.agent_router.execute_step_with_agent(step, store_fact=store_fact)

                # Take after screenshot
                after_screenshot = self._docker_client.take_screenshot()
                logger.debug(f"After screenshot taken for step {step.step_id}: {after_screenshot}")

                execution_time = time.time() - start_time

                # Check postconditions (skip for interaction agent or if force_run is enabled)
                postcondition_success = True
                final_error = agent_result.error

                if (agent_result.success and step.postconditions and
                    step.agent != AgentType.INTERACTION and not force_run):
                    if not self._check_postconditions(step):
                        postcondition_success = False
                        final_error = "Postcondition validation failed"

                # Create result with screenshots
                result = StepExecutionResult.from_step(
                    step,
                    success=agent_result.success and postcondition_success,
                    error=final_error,
                    result=agent_result.result,
                    action=agent_result.action,
                    execution_time=execution_time
                )

        except EnvironmentError as e:
            logger.error(f"Environment variable resolution failed for step {step.step_id}: {e}")
            execution_time = time.time() - start_time
            result = StepExecutionResult.from_step(
                step, success=False,
                error=str(e),
                action="env_var_resolution_failed",
                execution_time=execution_time
            )

        except asyncio.CancelledError:
            logger.info(f"Step {step.step_id} execution was cancelled")
            execution_time = time.time() - start_time
            result = StepExecutionResult.from_step(
                step, success=False,
                error="Step execution cancelled by user",
                action="cancelled",
                execution_time=execution_time
            )
            # Don't re-raise, return the cancelled result

        except Exception as e:
            execution_time = time.time() - start_time
            result = StepExecutionResult.from_step(
                step, success=False,
                error=f"Execution failed: {str(e)}",
                execution_time=execution_time
            )

        finally:
            # Apply sensitive data masking to the execution result
            result = self.resolver.apply_sensitive_data_masking(result, step)

        # Add screenshots to result
        result.before_screenshot = before_screenshot
        result.after_screenshot = after_screenshot

        # Record whether the new lenient OCR-retargeted precondition mechanism was used.
        result.new_precondition_applied = self._used_new_precondition
        result.ocr_retargeted = self._ocr_retargeted
        result.ocr_retarget_detail = self._ocr_retarget_detail

        self.step_results[step.step_id] = result
        status = "SUCCESS" if result.success else "FAILED"
        status_prefix = "[SUCCESS]" if result.success else "[FAILED]"
        logger.info(f"{status_prefix} Step {step.step_id} {status} ({execution_time:.2f}s)")
        logger.info("=" * 60)
        return result

    def _adjust_precondition_tolerance(self, precondition: str, max_tolerance: int) -> str:
        """
        Adjust precondition tolerance to be at most max_tolerance.

        Precondition format: hash_type:x:y:size:tolerance:hash_value

        Args:
            precondition: Precondition string to adjust
            max_tolerance: Maximum allowed tolerance value

        Returns:
            Adjusted precondition string
        """
        # OCR/text preconditions carry no spot tolerance; leave them untouched.
        if precondition.startswith("ocr:"):
            return precondition
        parts = precondition.split(':')
        if len(parts) == 6:
            try:
                current_tolerance = int(parts[4])
                if current_tolerance > max_tolerance:
                    parts[4] = str(max_tolerance)
                    logger.debug(f"Adjusted tolerance from {current_tolerance} to {max_tolerance}")
            except ValueError:
                logger.warning(f"Invalid tolerance value in precondition: {parts[4]}")
        return ':'.join(parts)

    async def _check_preconditions(self, step: Step) -> bool:
        """Check whether the current UI state is ready for this step.

        Default mechanism (AI precondition judge): feed the recorded screenshot, the
        live screenshot, the previous step's description and this step's plan to the
        vision model. It decides EXECUTE / WAIT / SKIP / ABORT and -- for coordinate
        actions -- may return a corrected click point when the recorded coordinate has
        drifted off the intended target. The correction is stored in
        ``self._retarget_xy`` and applied to the click just before it runs.

        A step tagged ``precondition:old`` keeps the legacy perceptual-hash mechanism.
        """
        self._last_precondition_detail = None

        # Legacy opt-out: `precondition:old` forces the perceptual-hash mechanism.
        if self.tag_processor.should_use_legacy_precondition(step):
            hash_conditions = [
                c for c in (step.preconditions or []) if not c.startswith("ocr:")
            ]
            if hash_conditions:
                return await self._wait_for_conditions(hash_conditions, step, "preconditions")
            logger.warning(
                f"Step {step.step_id} is tagged precondition:old but has no legacy hash "
                "conditions; skipping precondition check (allowing execution)."
            )
            return True

        # New default: AI vision precondition judge. Needs the recorded screenshot to
        # compare against; without one there is nothing to judge, so allow execution.
        if not step.screenshot or not is_valid_screenshot_data(step.screenshot):
            if step.preconditions:
                logger.info(
                    f"Step {step.step_id} has no usable recorded screenshot; "
                    "skipping AI precondition check (allowing execution)."
                )
            return True

        return await self._wait_for_ai_precondition(step)

    def _is_coordinate_tool(self, step: Step) -> bool:
        """True when the step acts on a single (x, y) point that can be re-targeted."""
        params = step.parameters
        if params is None:
            return False
        x = getattr(params, "x", None)
        y = getattr(params, "y", None)
        return x is not None and y is not None

    async def _wait_for_ai_precondition(self, step: Step) -> bool:
        """AI precondition judge with retry-until-stable/timeout.

        Loops: wait for a stable screenshot, ask the ConditionAgent to judge the live
        UI against the recording. EXECUTE -> allow (recording any coordinate
        correction); WAIT -> retry until timeout; ABORT -> fail immediately. SKIP ->
        fail immediately UNLESS the step set an explicit ``precondition_wait_timeout``
        (> 0), in which case the absent target is treated as not-ready-yet and polled
        until that budget is spent (respecting the author's declared wait). Never
        fail-open: a judge error is treated as WAIT and retried until the timeout.
        """
        self._used_new_precondition = True

        # Respect an explicit per-step precondition_wait_timeout tag/field: when the
        # plan author set one (> 0), it declares how long this step's target may take
        # to appear, and -- see the SKIP handling below -- makes a "target absent"
        # verdict non-terminal until that budget is spent. Untagged steps keep the
        # global default and their fast-fail-on-SKIP behavior.
        explicit_timeout = step.precondition_wait_timeout
        has_explicit_wait_timeout = explicit_timeout is not None and explicit_timeout > 0
        wait_timeout = explicit_timeout if has_explicit_wait_timeout else self.precondition_wait_timeout
        retry_interval = step.precondition_retry_interval or self.precondition_retry_interval

        start_time = asyncio.get_event_loop().time()
        last_detail = None
        attempts = 0

        while True:
            attempts += 1
            elapsed = asyncio.get_event_loop().time() - start_time
            remaining = wait_timeout - elapsed
            if remaining <= 0:
                self._last_precondition_detail = last_detail or "AI precondition timed out"
                logger.warning(
                    f"AI precondition timeout for step {step.step_id} after "
                    f"{attempts} attempts ({elapsed:.2f}s)"
                )
                return False

            # Wait for the screen to settle, then judge that stable screenshot.
            stable_screenshot = await self._wait_for_stable_screenshot(
                max_wait=min(max(remaining, 1.0), 10.0)
            )

            try:
                decision, explanation, target_x, target_y = await ConditionAgent.check_step_compatibility(
                    step=step,
                    current_screenshot_path=str(stable_screenshot),
                    prev_description=self._prev_step_description,
                    precondition_intent=self.tag_processor.get_precondition_intent(step),
                )
            except Exception as e:  # noqa: BLE001 - never fail-open on judge error
                logger.error(f"AI precondition analysis failed for step {step.step_id}: {e}")
                elapsed = asyncio.get_event_loop().time() - start_time
                remaining = wait_timeout - elapsed
                if remaining <= 0:
                    self._last_precondition_detail = (
                        last_detail or f"AI precondition analysis error: {e}"
                    )
                    return False
                await asyncio.sleep(min(retry_interval, remaining))
                continue

            last_detail = f"AI(condition_agent) {decision}: {explanation}"
            logger.info(f"AI precondition for step {step.step_id}: {decision} - {explanation}")

            if decision == "EXECUTE":
                if target_x is not None and target_y is not None and self._is_coordinate_tool(step):
                    ox = getattr(step.parameters, "x", None)
                    oy = getattr(step.parameters, "y", None)
                    self._retarget_xy = (target_x, target_y)
                    self._ocr_retargeted = True
                    detail = explanation if len(explanation) <= 160 else explanation[:160] + "..."
                    self._ocr_retarget_detail = f"({ox},{oy}) -> ({target_x},{target_y}): {detail}"
                    logger.info(
                        f"AI re-targeted click for step {step.step_id}: "
                        f"({ox},{oy}) -> ({target_x},{target_y})"
                    )
                return True

            if decision == "ABORT":
                # ABORT is always terminal: a fatal / wrong-application / crashed
                # state will not recover by waiting, even under an explicit budget.
                self._last_precondition_detail = last_detail
                logger.warning(
                    f"AI precondition ABORT for step {step.step_id}: {explanation}"
                )
                return False

            if decision == "SKIP" and not has_explicit_wait_timeout:
                # No explicit precondition_wait_timeout: preserve the historical
                # fast-fail-on-SKIP behavior for the vast majority of steps.
                self._last_precondition_detail = last_detail
                logger.warning(
                    f"AI precondition SKIP for step {step.step_id}: {explanation}"
                )
                return False

            if decision == "SKIP":
                # Explicit precondition_wait_timeout:N is the author declaring the
                # target may take up to N seconds to appear (e.g. a sign-in / consent
                # dialog that only opens after provisioning or a debug launch). Honor
                # that budget: treat "target absent" as not-ready-YET and keep polling
                # instead of giving up. Only ABORT (a visibly fatal state) fast-fails.
                logger.info(
                    f"AI precondition SKIP for step {step.step_id} but explicit "
                    f"precondition_wait_timeout={wait_timeout}s is set; treating as "
                    f"not-ready-yet and continuing to wait: {explanation}"
                )

            # WAIT (or SKIP under an explicit wait budget, or anything else): retry
            # until the (possibly author-specified) timeout is exhausted.
            elapsed = asyncio.get_event_loop().time() - start_time
            remaining = wait_timeout - elapsed
            if remaining <= 0:
                self._last_precondition_detail = last_detail
                logger.warning(
                    f"AI precondition wait timed out for step {step.step_id} "
                    f"after {attempts} attempts ({elapsed:.2f}s)"
                )
                return False
            await asyncio.sleep(min(retry_interval, remaining))

    def _screenshot_phash(self, screenshot_path: str) -> Optional[imagehash.ImageHash]:
        """Compute a perceptual hash of a screenshot for change detection."""
        try:
            with Image.open(screenshot_path) as img:
                return imagehash.phash(img)
        except Exception as e:  # noqa: BLE001 - best-effort dedup
            logger.debug(f"Failed to compute screenshot phash: {e}")
            return None

    def _check_postconditions(self, step: Step) -> bool:
        """Check if postconditions are met."""
        if not step.postconditions:
            return True

        screenshot_path = Path(self._docker_client.take_screenshot())
        logger.debug(f"Postcondition screenshot taken: {screenshot_path}")
        results = validate_postconditions(step.postconditions, screenshot_path)
        failures = [r for r in results if not r.success]

        if failures:
            logger.warning(f"Step {step.step_id}: {len(failures)} postcondition failures")
            return False
        return True

    async def _wait_for_stable_screenshot(self, max_wait: float = 10.0) -> str:
        """Wait for screenshot to stabilize before proceeding.

        Ensures the page/application is not loading or waiting for responses
        by detecting when the UI content has stopped changing significantly.

        Args:
            max_wait: Maximum time to wait for stability (seconds, capped at 10s)

        Returns:
            str: Path to the stable screenshot
        """
        stability_checks = 3    # Need 3 consecutive stable screenshots
        check_interval = 1.5   # Check every 1.5 seconds

        start_time = time.time()
        stable_count = 0
        previous_screenshot_path = None

        logger.debug(f"Waiting for UI stability - detecting loading/response states (max {max_wait}s)")

        while time.time() - start_time < max_wait:
            try:
                # Take screenshot
                screenshot_path = self._docker_client.take_screenshot()

                # Compare with previous screenshot
                if previous_screenshot_path is not None:
                    stability_ratio = detect_loading_stability(previous_screenshot_path, screenshot_path)

                    # More appropriate threshold for loading detection (90% instead of 99.9%)
                    # This ignores cursor blinks but catches loading spinners, content changes, etc.
                    if stability_ratio >= 0.95:
                        stable_count += 1
                        logger.debug(f"UI stable - no loading detected ({stable_count}/{stability_checks}, stability: {stability_ratio:.3f})")

                        if stable_count >= stability_checks:
                            elapsed = time.time() - start_time
                            logger.debug(f"UI stabilized - ready for interaction after {elapsed:.2f}s")
                            return screenshot_path
                    else:
                        # Significant UI changes detected - likely loading/processing
                        stable_count = 0
                        logger.debug(f"UI changing - loading/processing detected (stability: {stability_ratio:.3f})")

                previous_screenshot_path = screenshot_path
                await asyncio.sleep(check_interval)

            except Exception as e:
                logger.warning(f"Error during stability check: {str(e)}")
                # Fallback to basic screenshot if comparison fails
                return self._docker_client.take_screenshot()

        # Timeout reached - assume UI is stable enough
        elapsed = time.time() - start_time
        logger.debug(f"UI stability timeout after {elapsed:.2f}s - proceeding with last capture")
        return self._docker_client.take_screenshot()

    async def _wait_for_conditions(self, conditions: List[str], step: Step, condition_type: str) -> bool:
        """Wait for conditions to be met with retry mechanism."""
        if not conditions:
            return True

        wait_timeout = self.precondition_wait_timeout
        retry_interval = self.precondition_retry_interval

        if step and step.precondition_wait_timeout is not None:
            wait_timeout = step.precondition_wait_timeout
        if step and step.precondition_retry_interval is not None:
            retry_interval = step.precondition_retry_interval

        last_llm_detail = None
        start_time = asyncio.get_event_loop().time()
        attempts = 0

        while True:
            attempts += 1
            elapsed = asyncio.get_event_loop().time() - start_time

            # Extract hover coordinates from conditions if available
            hover_x, hover_y = None, None
            for condition in conditions:
                parsed = parse_condition(condition, "precondition")
                if parsed.success and parsed.coordinates is not None:
                    hover_x, hover_y = parsed.coordinates
                    condition_format = parsed.condition_format.value if parsed.condition_format else "unknown"
                    logger.debug(f"Get hover coordinates from {condition_format} condition: ({hover_x}, {hover_y})")
                    break  # Use the first valid condition with coordinates found

            # Apply hover pattern if coordinates are available
            if hover_x is not None and hover_y is not None:
                import random

                # Generate random hover coordinates within 1024x768 resolution
                random_hover_x = random.randint(50, 974)  # Leave 50px margin from edges
                random_hover_y = random.randint(50, 718)  # Leave 50px margin from edges

                logger.debug(f"Attempt {attempts}: hovering at random coordinates ({random_hover_x}, {random_hover_y})")

                # Always hover at random coordinates first to reset UI state
                random_hover_data = {"x": random_hover_x, "y": random_hover_y}
                self._docker_client.hover(random_hover_data)
                await asyncio.sleep(0.1)

                # On odd attempts (1, 3, 5...), also hover to the actual target
                if attempts % 2 != 0:
                    logger.debug(f"Odd attempt {attempts}: hovering to target ({hover_x}, {hover_y})")
                    interaction_data = {"x": hover_x, "y": hover_y}
                    self._docker_client.hover(interaction_data)
                    # Wait for UI to settle after hover action to ensure consistent screenshot validation
                    # This prevents hash calculation inconsistencies caused by hover effects and animations
                    await asyncio.sleep(0.3)
                else:
                    logger.debug(f"Even attempt {attempts}: skipping target hover")

            # Validate conditions
            screenshot_path = Path(self._docker_client.take_screenshot())
            logger.debug(f"Precondition screenshot taken: {screenshot_path}")
            result = validate_preconditions(conditions, screenshot_path)

            if result.success:
                logger.debug(f"{condition_type.title()} met after {attempts} attempts ({elapsed:.2f}s) - {result.reason}")
                return True

            # If automated validation failed and we're near timeout, try LLM-based condition analysis
            if elapsed >= wait_timeout * 0.9:  # Use LLM when 90% of timeout is reached
                logger.info(f"Automated {condition_type} validation failed after {elapsed:.2f}s, trying LLM analysis...")

                try:
                    # Use condition agent to analyze compatibility via visual comparison
                    decision, explanation = await ConditionAgent.check_step_compatibility(
                        step=step,
                        current_screenshot_path=str(screenshot_path)
                    )

                    logger.info(f"LLM condition analysis result: {decision} - {explanation}")
                    last_llm_detail = f"AI(condition_agent) {decision}: {explanation}"

                    if decision == "EXECUTE":
                        logger.info(f"LLM recommends proceeding despite failed {condition_type} - {explanation}")
                        return True
                    elif decision == "ABORT":
                        logger.error(f"LLM recommends aborting due to serious UI issues - {explanation}")
                        self._last_precondition_detail = last_llm_detail
                        return False
                    elif decision == "SKIP":
                        logger.warning(f"LLM recommends skipping due to incompatible UI state - {explanation}")
                        self._last_precondition_detail = last_llm_detail
                        return False
                    # For "WAIT" or unknown decisions, continue with normal retry logic
                    else:
                        logger.info(f"LLM recommends waiting for UI to stabilize - {explanation}")

                except Exception as llm_error:
                    logger.error(f"LLM condition analysis failed: {llm_error}")
                    # Continue with normal timeout behavior on LLM failure

            if elapsed >= wait_timeout:
                logger.warning(f"{condition_type.title()} timeout after {attempts} attempts ({elapsed:.2f}s) - {result.reason}")
                self._last_precondition_detail = last_llm_detail or (
                    f"automated {condition_type} validation failed: {result.reason}"
                )
                return False

            await asyncio.sleep(retry_interval)

    async def execute_plan(self, plan: ExecutablePlan,
                          start_index: int = 0,
                          end_index: Optional[int] = None) -> PlanExecutionResult:
        """Execute a complete executable plan using execution_order for step sequencing."""
        # Validate all variables before starting execution (env, secret, var)
        validation = self.resolver.validate_variables(plan)
        if not validation['valid']:
            error_details = []

            if validation.get('missing_env_vars'):
                error_details.append(f"Missing required environment variables: {', '.join(validation['missing_env_vars'])}")

            if validation.get('rule_violations'):
                error_details.append(f"Validation rule violations: {'; '.join(validation['rule_violations'])}")

            error_msg = ". ".join(error_details) + ". Please fix these issues before executing the plan."
            logger.error(error_msg)

            execution_result = PlanExecutionResult.from_plan(plan, 0, 0, 0)
            execution_result.exception = error_msg
            execution_result.end_time = datetime.now().isoformat()
            return execution_result
        else:
            logger.info("✅ All variable validations passed (env, secret, var)")

        # Reset fact store at the start of plan execution
        fact_store = FactStore()
        fact_store.reset_facts()
        logger.debug("Fact store reset for new plan execution")

        execution_order = plan.plan_metadata.execution_order
        if not execution_order:
            error_msg = "No execution_order specified in plan metadata. Execution order is required for proper step sequencing."
            logger.error(error_msg)
            execution_result = PlanExecutionResult.from_plan(plan, 0, 0, 0)
            execution_result.exception = error_msg
            execution_result.end_time = datetime.now().isoformat()
            return execution_result

        total_items = len(execution_order)
        end_index = min(end_index or total_items, total_items)
        start_index = max(0, start_index)

        # Create a lookup dictionary for steps by step_id for efficient access
        step_lookup = {step.step_id: step for step in plan.steps}

        # Expand group references in execution_order and collect group steps into step_lookup
        expanded_execution_order = await self._expand_group_references(execution_order, step_lookup)
        execution_order = expanded_execution_order

        # Update total items and end_index based on expanded execution order
        total_items = len(execution_order)
        end_index = min(end_index or total_items, total_items)

        # Update configuration from plan metadata if available
        self._update_config_from_plan(plan)

        # Initialize execution result
        execution_result = PlanExecutionResult.from_plan(plan, start_index, end_index, total_items)

        logger.info(f"Executing plan: {plan.plan_metadata.name}")
        logger.info(f"Range: {start_index} to {end_index} ({end_index - start_index} items)")
        logger.info(f"Execution order: {execution_order[start_index:end_index]}")
        logger.info("=" * 60)

        self.current_plan = plan

        try:
            # Execute steps according to execution_order
            for i in range(start_index, end_index):
                step_id = execution_order[i]
                step = step_lookup.get(step_id)

                if not step:
                    error_msg = f"Step {step_id} in execution_order not found in plan steps"
                    logger.error(error_msg)
                    execution_result.error_count += 1
                    execution_result.errors.append({
                        "item_index": i,
                        "step_id": step_id,
                        "error": error_msg
                    })
                    if self.stop_on_error:
                        logger.info(f"Stopping execution due to missing step {step_id}")
                        break
                    continue

                execution_result.executed_count += 1

                try:
                    # Store original step description before execution (may be modified by variable resolution)
                    original_description = step.description
                    step_execution_result = await self.execute_step(step)
                    # Restore original description in execution result
                    step_execution_result.description = original_description
                    execution_result.step_execution_results.append(step_execution_result)

                    # Check if step execution was cancelled
                    if step_execution_result.action == "cancelled":
                        logger.info(f"Plan execution cancelled during step {step.step_id}")
                        break

                    # Update counters and handle errors
                    if step_execution_result.success:
                        execution_result.success_count += 1
                        # Remember this step's description as context for the AI
                        # precondition judge on the next step.
                        self._prev_step_description = original_description
                    else:
                        execution_result.error_count += 1
                        execution_result.errors.append({
                            "item_index": i,
                            "step_id": step.step_id,
                            "error": step_execution_result.error
                        })

                        if self.stop_on_error:
                            logger.info(f"Stopping execution due to error in step {step.step_id}")
                            break

                except asyncio.CancelledError:
                    logger.info(f"Plan execution cancelled during step {step.step_id}")
                    # Don't re-raise, let plan complete gracefully
                    break

                # Delay between steps
                if i < end_index - 1 and self.delay > 0:
                    await asyncio.sleep(self.delay)

        except KeyboardInterrupt:
            logger.info("Execution interrupted by user")
            execution_result.interrupted = True
        except asyncio.CancelledError:
            logger.info(f"Plan {plan.plan_id} execution was cancelled")
            execution_result.interrupted = True
        except Exception as e:
            logger.error(f"Execution failed: {e}")
            execution_result.exception = str(e)

        execution_result.end_time = datetime.now().isoformat()

        # Capture runtime variables from resolver
        execution_result.runtime_variables = self.resolver.get_runtime_variables()

        self._log_execution_summary(execution_result)

        # Generate test report if enabled
        if self.reporter and self.current_plan:
            self._generate_report(execution_result)

        self.execution_log.append(execution_result)
        return execution_result

    async def _expand_group_references(self, execution_order: List[str], step_lookup: Optional[Dict[str, Step]] = None) -> List[str]:
        """Expand group plan references in execution_order.

        Items starting with 'plan_' are treated as group references and expanded
        to their constituent steps. Group steps are also added to step_lookup
        so they can be found during execution.
        """
        expanded_order = []

        for item in execution_order:
            if item.startswith('plan_'):
                # This is a group reference, load and expand it
                try:
                    group_plan = await self._load_group_plan(item)
                    if group_plan and group_plan.plan_metadata.execution_order:
                        # Add group steps to step_lookup so executor can find them
                        if step_lookup is not None:
                            for step in group_plan.steps:
                                step_lookup[step.step_id] = step

                        # Recursively expand in case group plans reference other groups
                        group_expanded = await self._expand_group_references(
                            group_plan.plan_metadata.execution_order, step_lookup
                        )
                        expanded_order.extend(group_expanded)
                        logger.info(f"Expanded group '{item}' to {len(group_expanded)} steps")
                    else:
                        logger.warning(f"Group plan '{item}' has no execution_order, skipping")
                except Exception as e:
                    logger.error(f"Failed to expand group reference '{item}': {e}")
                    # Continue with other items even if one group fails
                    continue
            else:
                # Regular step reference, add as-is
                expanded_order.append(item)

        return expanded_order

    async def _load_group_plan(self, group_reference: str) -> Optional[ExecutablePlan]:
        """Load a group plan from the plans directory.

        Args:
            group_reference: Group reference like 'plan_login_flow'

        Returns:
            ExecutablePlan if found and has "group" tag, None otherwise
        """
        # Convert plan_xyz to plan_xyz.json filename
        plan_filename = f"{group_reference}.json"

        # Look for the plan file in the plans directory
        # Use relative path from current working directory
        plan_path = Path("plans") / plan_filename

        if not plan_path.exists():
            logger.error(f"Group plan file not found: {plan_path}")
            return None

        try:
            logger.debug(f"Loading group plan from: {plan_path}")
            with open(plan_path, 'r', encoding='utf-8') as f:
                plan_data = json.load(f)

            plan = ExecutablePlan.parse_obj(plan_data)

            # Validate that this plan has the "group" tag
            if "group" not in plan.plan_metadata.tags:
                logger.error(f"Plan {group_reference} does not have 'group' tag - not a valid group plan")
                return None

            return plan
        except Exception as e:
            logger.error(f"Failed to load group plan from {plan_path}: {e}")
            return None

    def _update_config_from_plan(self, plan: ExecutablePlan):
        """Update configuration from plan metadata."""
        # Only override if the plan explicitly sets these values (not just schema defaults)
        # We can detect this by checking if the values are different from the ExecutionConfig defaults
        execution_defaults = ExecutionConfig()
        exec_context = plan.plan_metadata.execution_context

        if exec_context.precondition_wait_timeout != execution_defaults.precondition_wait_timeout:
            self.precondition_wait_timeout = exec_context.precondition_wait_timeout

        if exec_context.precondition_retry_interval != execution_defaults.precondition_retry_interval:
            self.precondition_retry_interval = exec_context.precondition_retry_interval

        if exec_context.delay_between_steps != execution_defaults.delay_between_steps:
            self.delay = exec_context.delay_between_steps

        if exec_context.stop_on_error != execution_defaults.stop_on_error:
            self.stop_on_error = exec_context.stop_on_error

        if exec_context.step_retry_timeout != execution_defaults.step_retry_timeout:
            self.step_retry_timeout = exec_context.step_retry_timeout

    def _generate_report(self, execution_result: PlanExecutionResult):
        """Generate test report if reporting is enabled."""
        try:
            report_path = self.reporter.generate_report(
                plan=self.current_plan,
                execution_result=execution_result,
                plan_path=self.current_plan_path
            )
            logger.info(f"✅ Test report generated: {report_path}")
            # Convert Windows path to proper file URL format
            file_url = report_path.absolute().as_uri()
            logger.info(f"🌐 Open in browser: {file_url}")
        except Exception as e:
            logger.error(f"Failed to generate test report: {e}")
            logger.debug("Report generation error details:", exc_info=True)

    def _log_execution_summary(self, result: PlanExecutionResult) -> None:
        """Log execution summary."""
        logger.info("=" * 60)
        logger.info("[SUMMARY] EXECUTION SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Plan: {result.plan_id}")
        logger.info(f"Items executed: {result.executed_count}")
        logger.info(f"Successful: {result.success_count}")
        logger.info(f"Errors: {result.error_count}")

        if result.executed_count > 0:
            success_rate = result.success_count / result.executed_count * 100
            logger.info(f"Success rate: {success_rate:.1f}%")
        logger.info("=" * 60)

    def load_plan(self, plan_path: Path) -> ExecutablePlan:
        """Load plan from JSON file."""
        with open(plan_path, 'r', encoding='utf-8') as f:
            plan_data = json.load(f)
        return ExecutablePlan.parse_obj(plan_data)

    async def execute_from_file(self, plan_path: Path, **kwargs) -> PlanExecutionResult:
        """Load and execute a plan from file."""
        plan = self.load_plan(plan_path)
        return await self.execute_plan(plan, **kwargs)

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        # Currently no cleanup needed, but this allows for future resource management
        pass
