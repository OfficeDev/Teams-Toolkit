#!/usr/bin/env python3
"""
Condition Agent for UI State Comparison using OpenAI Agents SDK

This agent compares the current screenshot with the recorded screenshot to decide
whether an automation step can run, and -- for coordinate actions -- whether the
recorded click point still lands on the intended target. When the layout has
drifted so that the recorded coordinate is wrong but the target is still present
and reachable, the agent returns a corrected click point in the CURRENT
screenshot's pixel frame so the executor can re-target the click directly (no OCR).
"""

import base64
import io
import time
from typing import Optional, Tuple

import imagehash
from agents import Agent, OpenAIChatCompletionsModel, Runner, set_tracing_disabled
from openai import AsyncAzureOpenAI
from PIL import Image, ImageDraw
from pydantic import BaseModel

from vscuse_v2.config import get_azure_openai_config
from vscuse_v2.core.schema import Step
from vscuse_v2.utils import AzureOpenAIClientFactory
from vscuse_v2.utils.logger import setup_logger

logger = setup_logger(__name__)

# Screens whose perceptual hash differs by no more than this are treated as a
# match: the recorded coordinate is still valid, so we EXECUTE without an LLM call.
NEAR_IDENTICAL_PHASH_DISTANCE = 6


class ConditionAnalysisResult(BaseModel):
    """Structured result for condition analysis.

    ``coordinate_correct`` / ``target_x`` / ``target_y`` are only meaningful for
    coordinate (click/hover) steps. When the recorded crosshair no longer lands on
    the intended target but the target is present and reachable, the model returns
    ``decision=EXECUTE``, ``coordinate_correct=false`` and the corrected
    ``target_x`` / ``target_y`` (center of the intended target) in the CURRENT
    screenshot's pixel coordinates.
    """
    decision: str  # One of: EXECUTE, WAIT, SKIP, ABORT
    explanation: str
    coordinate_correct: bool = True
    target_x: Optional[int] = None
    target_y: Optional[int] = None


def is_valid_screenshot_data(screenshot: Optional[str]) -> bool:
    """Validate if screenshot data is a valid base64 data URI or file path.

    Args:
        screenshot: Screenshot data string to validate

    Returns:
        True if screenshot appears to be valid data, False otherwise
    """
    if not screenshot:
        return False

    # Check if it's a data URI with actual base64 content
    if screenshot.startswith('data:'):
        # Data URI should be at least: "data:image/jpeg;base64," + some data
        if len(screenshot) < 50:
            return False
        if ';base64,' not in screenshot:
            return False
        try:
            _, base64_data = screenshot.split(',', 1)
            return len(base64_data) > 100  # Minimum base64 content
        except ValueError:
            return False

    # Check if it's a file path that exists
    import os
    if os.path.isfile(screenshot):
        return True

    return False


class ConditionPromptTemplate:
    """Template for generating condition analysis prompts."""

    AGENT_INSTRUCTIONS = """
You are a UI automation precondition analyzer. You are given the RECORDED screenshot (captured when a step was authored) and the CURRENT screenshot (the live UI where the step is about to run). You decide whether the step can run now, and -- for coordinate actions -- whether the recorded click point is still correct.

Judge LENIENTLY. Your only two requirements are:
1. STABILITY: the relevant region is not actively loading, animating, or mid-transition.
2. GOAL-REACHABILITY: the element this step needs to act on is present and reachable so the step's goal can be achieved now.

If both hold, choose EXECUTE -- even if there are harmless differences from the recording: tooltips, hover popups, background walkthrough pages, cosmetic changes, unrelated overlays that do not cover or intercept the target, or extra menu items. Do NOT WAIT or SKIP just because an overlay/tooltip is visible or the screenshots differ; only react to it if it actually blocks or hides the target.

Coordinate re-targeting (click/hover steps): a red crosshair marks the recorded click point on BOTH screenshots.
- If the crosshair lands ON the intended target in the CURRENT screenshot -> EXECUTE with coordinate_correct=true.
- If the intended target is present and reachable but the crosshair is OFF it (the layout drifted / the element moved) -> EXECUTE with coordinate_correct=false, and set target_x / target_y to the CENTER of the intended target in the CURRENT screenshot's pixel coordinates (origin top-left, x increases right, y increases down). Do not guess wildly; only re-target when you can clearly identify the intended element.
- If the intended target is genuinely absent, or the crosshair region shows a materially different/incompatible workflow -> SKIP.

Decision priority (prefer EXECUTE when stable and reachable):
- ABORT: wrong application, crash, or fatal error needing manual intervention.
- SKIP: the target is absent, or the current panel/page is a materially different, incompatible state, and re-targeting cannot recover it.
- WAIT: the target region is still loading/unstable and is expected to settle shortly. Do NOT WAIT for harmless overlays or for states that will not change on their own.
- EXECUTE: the target is present and reachable and the region is stable (optionally with a coordinate correction).

Awaited / asynchronous targets (IMPORTANT -- do not give up too early): some steps act on UI that only appears a while AFTER a preceding action starts an asynchronous process -- e.g. a sign-in / password / consent dialog that opens after a debug session is launched, after provisioning/publish, or after a login is initiated; or a panel that appears only once a long build/provision finishes. Recognize this when the RECORDED screenshot shows such an auth / sign-in / consent / loading / provisioning target AND either the PREVIOUS STEP or the CURRENT screenshot shows that kind of async action was just started and is still in progress (e.g. a launch/debug/provision/publish/sign-in was triggered, or the current screen shows provisioning/loading/progress such as 'Provision: [n/m] ...', a spinner, or a build running). In that case, if the target is simply NOT PRESENT YET on an otherwise stable screen and there is NO visible failure, choose WAIT -- the caller re-checks within a bounded timeout and will still fail if the target never appears, so waiting is safe and correct. Choose SKIP or ABORT ONLY when the CURRENT screen shows positive evidence the target will NOT arrive on its own: an error page, an exception or stack trace, a failed or stopped debug session, a failed provisioning/deployment message, a rejected/blocked sign-in, or a clearly different, incompatible workflow. The mere ABSENCE of the awaited dialog on a stable screen is NOT such evidence -- prefer WAIT there.

Dynamic app / agent names: the app-under-test is named `vscuse_app_<5 random chars><env>` (e.g. `vscuse_app_dxMFCdev`, `vscuse_app_uTuNTlocal`, and it may appear as just `vscuse_app_<5 random chars>` when the suffix is not shown). The 5-character segment is randomized on every run and the trailing environment segment reflects the current run (`local` for a Local Debug run, `dev` for a Remote Debug run). When a recorded name and a current name both look like `vscuse_app_<5 random chars><env>` and differ ONLY in that random segment and/or the environment suffix, treat them as the SAME logical app/agent; do NOT, on that basis alone, decide the wrong agent/app is selected or that the UI state is incompatible. Keep evaluating the rest of the UI normally.

Be practical and focused on whether this automation step can succeed now, not on perfect pixel matching.
"""

    CONDITION_ANALYSIS_PROMPT = """
Decide whether the automation step below can be executed against the CURRENT screenshot.

**RECORDED SCREENSHOT** (when the step was authored): the UI state when the step was recorded successfully.
**CURRENT SCREENSHOT** (live UI): where we want to execute the step now. Its size is {image_width} x {image_height} pixels (width x height).

**PREVIOUS STEP** (what just happened before this step):
{prev_description}
{author_hint}
**STEP TO EXECUTE:**
- Tool: {tool}
- Parameters: {parameters}
- Description (this step's goal/plan): {description}

{coordinate_info}

**ANALYSIS:**
1. Is this step's intended target present and reachable in the CURRENT screenshot so its goal can be achieved now?
2. For coordinate actions, does the red crosshair land on the intended target? If not, where is the intended target's center in the CURRENT screenshot (pixel coordinates)?
3. Is the target region stable (not loading/animating), and are any overlays/dialogs actually covering or intercepting the target -- or are they harmless and ignorable?

Return the structured output with 'decision' and 'explanation'. For coordinate actions also return 'coordinate_correct'; when it is false, return integer 'target_x' and 'target_y' for the intended target's center in the CURRENT screenshot.
"""

    @classmethod
    def format_analysis_prompt(
        cls,
        step: Step,
        has_coordinates: bool = False,
        prev_description: Optional[str] = None,
        image_width: Optional[int] = None,
        image_height: Optional[int] = None,
        precondition_intent: Optional[str] = None,
    ) -> str:
        """Format the condition analysis prompt with step details."""
        author_hint = (
            f"\n**AUTHOR PRECONDITION HINT** (the step author's intent about what this "
            f"step waits for -- trust it when deciding WAIT vs SKIP): {precondition_intent}\n"
            if precondition_intent else ""
        )
        coordinate_info = ""
        if has_coordinates and step.parameters and hasattr(step.parameters, 'x') and hasattr(step.parameters, 'y'):
            coordinate_info = (
                f"\n**RECORDED TARGET COORDINATES:** ({step.parameters.x}, {step.parameters.y})\n"
                "A red crosshair is drawn on BOTH screenshots at these coordinates to show the recorded "
                "interaction point. If it no longer lands on the intended target in the CURRENT screenshot "
                "but the target is present, return the corrected center of the intended target as "
                "target_x / target_y in the CURRENT screenshot's pixel coordinates."
            )

        return cls.CONDITION_ANALYSIS_PROMPT.format(
            tool=step.tool,
            parameters=step.parameters.model_dump(exclude_none=True) if step.parameters else {},
            description=step.description or "No description",
            prev_description=prev_description or "No previous step recorded (this may be the first step).",
            author_hint=author_hint,
            coordinate_info=coordinate_info,
            image_width=image_width if image_width is not None else "unknown",
            image_height=image_height if image_height is not None else "unknown",
        )


class ConditionAgent:
    """Agent for analyzing UI condition compatibility using vision comparison."""

    def __init__(self):
        """Initialize the condition analysis agent."""
        self._client: AsyncAzureOpenAI = None
        self._agent: Agent = None
        self._runner: Optional[Runner] = None
        self._use_azure_credential = False
        set_tracing_disabled(True)

    async def _initialize_client(self) -> None:
        """Initialize the Azure OpenAI client and agent."""
        if self._client is None:
            azure_config = get_azure_openai_config()

            self._client = await AzureOpenAIClientFactory.create_client(self._use_azure_credential)

            self._agent = Agent(
                name="ConditionAnalyzer",
                instructions=ConditionPromptTemplate.AGENT_INSTRUCTIONS,
                model=OpenAIChatCompletionsModel(
                    model=azure_config.model,
                    openai_client=self._client,
                ),
                output_type=ConditionAnalysisResult
            )

            self._runner = Runner()
            logger.info("Condition analysis agent initialized")

    def _convert_to_base64_with_crosshair(
        self,
        image_source: str,
        x: Optional[int] = None,
        y: Optional[int] = None,
        label: str = ""
    ) -> Tuple[str, int, int]:
        """Convert image source (data URI or file path) to base64, optionally drawing a crosshair.

        Returns:
            Tuple of (data URL, width, height). The image is NOT resized, so any
            coordinates the model returns are in this pixel frame.
        """
        try:
            if not is_valid_screenshot_data(image_source):
                raise ValueError(
                    f"Invalid {label} screenshot data: '{image_source[:50]}...' "
                    f"(length: {len(image_source)}). Expected data URI or valid file path."
                )

            if image_source.startswith('data:'):
                header, base64_data = image_source.split(',', 1)
                image_data = base64.b64decode(base64_data)
                image = Image.open(io.BytesIO(image_data))
            else:
                image = Image.open(image_source)

            with image:
                if image.mode != 'RGB':
                    image = image.convert('RGB')

                image_copy = image.copy()
                width, height = image_copy.size

                if x is not None and y is not None:
                    draw = ImageDraw.Draw(image_copy)
                    crosshair_size = 8
                    line_width = 2

                    # White outline for visibility
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='white', width=line_width + 2)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='white', width=line_width + 2)
                    # Red crosshair on top
                    draw.line([x - crosshair_size, y, x + crosshair_size, y],
                             fill='red', width=line_width)
                    draw.line([x, y - crosshair_size, x, y + crosshair_size],
                             fill='red', width=line_width)

                    logger.debug(f"Drew crosshair at ({x}, {y}) on {label} screenshot")

                buffer = io.BytesIO()
                image_copy.save(buffer, format="JPEG", quality=95)
                encoded_string = base64.b64encode(buffer.getvalue()).decode("utf-8")

                return f"data:image/jpeg;base64,{encoded_string}", width, height

        except FileNotFoundError:
            logger.error(f"Screenshot file not found: {image_source}")
            raise
        except Exception as e:
            logger.error(f"Error processing {label} screenshot: {e}")
            raise

    async def analyze_condition_compatibility(
        self,
        step: Step,
        current_screenshot_path: str,
        prev_description: Optional[str] = None,
        precondition_intent: Optional[str] = None,
    ) -> Tuple[str, str, Optional[int], Optional[int]]:
        """Analyze if the current UI state is compatible with executing the step.

        Args:
            step: Step object containing the recorded screenshot and parameters.
            current_screenshot_path: Path to the current screenshot.
            prev_description: Natural-language description of the previous successfully
                executed step (context for the judge). ``None`` for the first step.

        Returns:
            Tuple of (decision, explanation, target_x, target_y). ``decision`` is one of
            EXECUTE / WAIT / SKIP / ABORT. ``target_x`` / ``target_y`` are non-None only
            when the model asked to re-target a coordinate action to a corrected point
            (in the CURRENT screenshot pixel frame); otherwise they are None.
        """
        start_time = time.time()

        try:
            if not step.screenshot:
                logger.warning(f"Step {step.step_id} has no recorded screenshot, allowing execution without comparison")
                return "EXECUTE", "No recorded screenshot available - allowing execution based on step definition only", None, None

            if not is_valid_screenshot_data(step.screenshot):
                logger.warning(f"Step {step.step_id} has invalid screenshot data: '{step.screenshot[:50]}...', allowing execution without comparison")
                return "EXECUTE", f"Invalid recorded screenshot data (length: {len(step.screenshot)}) - allowing execution based on step definition only", None, None

            logger.info(f"Analyzing condition compatibility for step {step.step_id}")

            has_coordinates = (step.parameters and
                             hasattr(step.parameters, 'x') and hasattr(step.parameters, 'y') and
                             step.parameters.x is not None and step.parameters.y is not None)

            # Preliminary pHash comparison. Only used as a positive fast-path: when the
            # current screen is near-identical to the recording, the recorded coordinate
            # is still valid so we EXECUTE without an LLM call. A large difference is NOT
            # treated as a failure -- it is exactly the drift case where we want the LLM
            # to judge readiness and (if needed) re-target the click.
            try:
                if step.screenshot.startswith('data:'):
                    _, base64_data = step.screenshot.split(',', 1)
                    recorded_img = Image.open(io.BytesIO(base64.b64decode(base64_data)))
                else:
                    recorded_img = Image.open(step.screenshot)
                current_img = Image.open(current_screenshot_path)

                hamming_distance = imagehash.phash(recorded_img) - imagehash.phash(current_img)
                logger.debug(f"pHash comparison - Hamming distance: {hamming_distance}")

                if hamming_distance <= NEAR_IDENTICAL_PHASH_DISTANCE:
                    logger.info(
                        f"Screenshots near-identical (Hamming distance: {hamming_distance} "
                        f"<= {NEAR_IDENTICAL_PHASH_DISTANCE}); recorded coordinate valid, "
                        "executing without LLM analysis"
                    )
                    return "EXECUTE", (
                        f"Current screen matches the recording (pHash Hamming distance "
                        f"{hamming_distance}); recorded coordinate is still valid."
                    ), None, None
            except Exception as e:
                logger.warning(f"pHash comparison failed: {e}. Proceeding with LLM analysis.")

            await self._initialize_client()

            x_coord = step.parameters.x if has_coordinates else None
            y_coord = step.parameters.y if has_coordinates else None

            recorded_image, _, _ = self._convert_to_base64_with_crosshair(
                step.screenshot, x_coord, y_coord, "recorded"
            )
            current_image, cur_w, cur_h = self._convert_to_base64_with_crosshair(
                current_screenshot_path, x_coord, y_coord, "current"
            )

            prompt = ConditionPromptTemplate.format_analysis_prompt(
                step=step,
                has_coordinates=has_coordinates,
                prev_description=prev_description,
                image_width=cur_w,
                image_height=cur_h,
                precondition_intent=precondition_intent,
            )

            input_data = [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": prompt},
                        {"type": "input_text", "text": "**RECORDED SCREENSHOT** (when step was originally recorded):"},
                        {"type": "input_image", "image_url": recorded_image},
                        {"type": "input_text", "text": "**CURRENT SCREENSHOT** (current UI state):"},
                        {"type": "input_image", "image_url": current_image}
                    ]
                }
            ]

            api_start = time.time()
            result = await self._runner.run(self._agent, input=input_data)
            api_duration = time.time() - api_start

            target_x: Optional[int] = None
            target_y: Optional[int] = None
            try:
                analysis_result = result.final_output_as(ConditionAnalysisResult, raise_if_incorrect_type=True)
                decision = analysis_result.decision.upper()
                explanation = analysis_result.explanation
                if not analysis_result.coordinate_correct:
                    target_x = analysis_result.target_x
                    target_y = analysis_result.target_y
            except TypeError as e:
                logger.warning(f"Structured output validation failed: {str(e)}. Using fallback parsing.")
                response = str(result.final_output).strip()
                lines = response.split('\n', 1)
                decision = lines[0].strip().upper()
                explanation = lines[1].strip() if len(lines) > 1 else "No explanation provided"

            valid_decisions = ["EXECUTE", "WAIT", "SKIP", "ABORT"]
            if decision not in valid_decisions:
                logger.warning(f"Invalid decision '{decision}', defaulting to WAIT")
                explanation = f"Invalid decision format. Decision: {decision}"
                decision = "WAIT"

            # Only honor a coordinate correction for a valid EXECUTE on a coordinate step,
            # and only when the point is inside the current screenshot bounds.
            if not (decision == "EXECUTE" and has_coordinates and target_x is not None and target_y is not None):
                target_x = target_y = None
            else:
                try:
                    tx, ty = int(target_x), int(target_y)
                except (TypeError, ValueError):
                    logger.warning(f"Ignoring non-integer re-target ({target_x}, {target_y}) for step {step.step_id}")
                    target_x = target_y = None
                else:
                    if 0 <= tx < cur_w and 0 <= ty < cur_h:
                        target_x, target_y = tx, ty
                    else:
                        logger.warning(
                            f"Ignoring out-of-bounds re-target ({tx}, {ty}) for step {step.step_id} "
                            f"(image {cur_w}x{cur_h})"
                        )
                        target_x = target_y = None

            total_duration = time.time() - start_time
            usage = result.context_wrapper.usage
            retarget_note = f", retarget=({target_x},{target_y})" if target_x is not None else ""
            logger.info(
                f"Condition analysis for step {step.step_id}: {decision} ({total_duration:.2f}s, "
                f"API: {api_duration:.2f}s, tokens: {usage.input_tokens}/{usage.output_tokens}){retarget_note}"
            )
            logger.debug(f"Analysis explanation: {explanation}")

            return decision, explanation, target_x, target_y

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Failed to analyze conditions for step {step.step_id} after {duration:.2f}s: {e}")
            # Conservative on error: WAIT so the caller retries until timeout.
            return "WAIT", f"Condition analysis failed: {str(e)}", None, None

    @classmethod
    async def check_step_compatibility(
        cls,
        step: Step,
        current_screenshot_path: str,
        prev_description: Optional[str] = None,
        precondition_intent: Optional[str] = None,
    ) -> Tuple[str, str, Optional[int], Optional[int]]:
        """Convenience method to check step compatibility with the current UI state.

        Returns:
            Tuple of (decision, explanation, target_x, target_y).
        """
        agent = cls()
        return await agent.analyze_condition_compatibility(
            step, current_screenshot_path, prev_description, precondition_intent
        )
